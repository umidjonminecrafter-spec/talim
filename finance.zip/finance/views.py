from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema, OpenApiParameter
from django.db.models import Sum, Q, Count
from datetime import datetime
from .models import ExpenseCategory, Expenses, MonthlyIncome, Payment,Sale,DetailedExpense,ExpenseSubcategory
from .serializers import (ExpenseCategorySerializer, ExpensesSerializer,
                          MonthlyIncomeSerializer, PaymentSerializer, SaleSerializer, DetailedExpenseSerializer,
                          ExpenseSubcategorySerializer, BulkSalaryConfigSerializer, PayPeriodSerializer,
                          CRMLeadSerializer, WorklyAttendanceSerializer, WorklyConnectionTestSerializer,
                          WorklyIntegrationSerializer, WorklyIntegration, CallLogSerializer)
from datetime import timedelta
from accounts.models import Employee
from academics.groups import Course
from .models import Bonus, Fine, Salary
from .serializers import BonusSerializer, FineSerializer, SalarySerializer
from academics.teacher import TeacherSalaryRules, TeacherSalaryPayments, TeacherSalaryCalculations
from .serializers import TeacherSalaryRulesSerializer, TeacherSalaryPaymentsSerializer, \
    TeacherSalaryCalculationsSerializer,WorklyAttendance,CallLog
from rest_framework.views import APIView
from crm.models import (CRMSource, CRMPipelines, CRMLead, CRMActivity,
                        CRMLeadsHistory, CRMLostReason, CRMLeadLost, CRMLeadNotes)
from .serializers import (CRMSourceSerializer, CRMPipelinesSerializer, CRMLeadSerializer,
                         CRMActivitySerializer, ConversionFunnelSerializer)
from academics.models.student import (Student, StudentGroup, StudentGroupLeaves,
                                      LeaveReason)
from academics.models.group import Group, Course, GroupTeacher
from .serializers import (LeaveReasonSerializer, StudentGroupLeavesSerializer,
                          StudentLeavesReportSerializer)
@extend_schema(tags=["ExpenseCategory - Harajatlar kategoriyasini ko'rish "])
class ExpenseCategoryViewSet(viewsets.ModelViewSet):
    queryset = ExpenseCategory.objects.all()
    serializer_class = ExpenseCategorySerializer


@extend_schema(tags=["Expenses"])
class ExpensesViewSet(viewsets.ModelViewSet):
    queryset = Expenses.objects.select_related('category').all()
    serializer_class = ExpensesSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        search = self.request.query_params.get('search')

        if category:
            queryset = queryset.filter(category_id=category)
        if start_date:
            queryset = queryset.filter(expense_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(expense_date__lte=end_date)
        if search:
            queryset = queryset.filter(Q(comment__icontains=search) | Q(category__name__icontains=search))

        return queryset

    @extend_schema(
        parameters=[
            OpenApiParameter('year', int, description='Yil'),
            OpenApiParameter('month', int, description='Oy'),
        ]
    )
    @action(detail=False, methods=['get'])
    def monthly_summary(self, request):
        year = request.query_params.get('year', datetime.now().year)
        month = request.query_params.get('month', datetime.now().month)

        total = self.queryset.filter(
            expense_date__year=year,
            expense_date__month=month
        ).aggregate(total=Sum('amount'))['total'] or 0

        by_category = self.queryset.filter(
            expense_date__year=year,
            expense_date__month=month
        ).values('category__name').annotate(total=Sum('amount'))

        return Response({
            'year': year,
            'month': month,
            'total_expenses': total,
            'by_category': list(by_category)
        })


@extend_schema(tags=["MonthlyIncome"])
class MonthlyIncomeViewSet(viewsets.ModelViewSet):
    queryset = MonthlyIncome.objects.all()
    serializer_class = MonthlyIncomeSerializer

    @action(detail=True, methods=['get'])
    def net_profit(self, request, pk=None):
        income = self.get_object()
        expenses = Expenses.objects.filter(
            expense_date__year=income.month.year,
            expense_date__month=income.month.month
        ).aggregate(total=Sum('amount'))['total'] or 0

        return Response({
            'income': income.total_amount,
            'expenses': expenses,
            'net_profit': income.total_amount - expenses
        })


@extend_schema(tags=["Payment"])
class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer


@extend_schema(tags=["Sales"])
class SaleViewSet(viewsets.ModelViewSet):
    queryset = Sale.objects.all()
    serializer_class = SaleSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        date = self.request.query_params.get('date')
        month = self.request.query_params.get('month')
        debt = self.request.query_params.get('debt')
        course = self.request.query_params.get('course')

        if date:
            queryset = queryset.filter(sale_date__date=date)
        if month:
            queryset = queryset.filter(month=month)
        if debt == 'true':
            queryset = queryset.filter(debt_amount__gt=0)
        if course:
            queryset = queryset.filter(course__icontains=course)

        return queryset

    @extend_schema(
        parameters=[
            OpenApiParameter('start_month', str, description='Boshlanish oyi (YYYY-MM-DD)'),
            OpenApiParameter('end_month', str, description='Tugash oyi (YYYY-MM-DD)'),
        ]
    )
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        start = request.query_params.get('start_month')
        end = request.query_params.get('end_month')

        queryset = self.queryset
        if start and end:
            queryset = queryset.filter(month__range=[start, end])

        total_sales = queryset.aggregate(total=Sum('amount'))['total'] or 0
        total_debt = queryset.aggregate(total=Sum('debt_amount'))['total'] or 0
        total_paid = total_sales - total_debt

        monthly_data = queryset.values('month').annotate(
            total=Sum('amount'),
            debt=Sum('debt_amount')
        ).order_by('month')

        return Response({
            'total_sales': total_sales,
            'total_paid': total_paid,
            'total_debt': total_debt,
            'monthly_breakdown': list(monthly_data)
        })

    @action(detail=False, methods=['get'])
    def active_count(self, request):
        count = self.queryset.filter(created_at__gte=datetime.now() - timedelta(days=30)).count()
        return Response({'active_count': count, 'limit': 500})


from rest_framework.permissions import IsAuthenticated


@extend_schema(tags=["ExpenseSubcategory"])
class ExpenseSubcategoryViewSet(viewsets.ModelViewSet):
    queryset = ExpenseSubcategory.objects.select_related('category').all()
    serializer_class = ExpenseSubcategorySerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        type = self.request.query_params.get('type')

        if category:
            queryset = queryset.filter(category_id=category)
        if type:
            queryset = queryset.filter(type=type)

        return queryset


@extend_schema(tags=["DetailedExpense"])
class DetailedExpenseViewSet(viewsets.ModelViewSet):
    queryset = DetailedExpense.objects.select_related('subcategory', 'payment_type').all()
    serializer_class = DetailedExpenseSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        subcategory = self.request.query_params.get('subcategory')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        payment = self.request.query_params.get('payment')

        if subcategory:
            queryset = queryset.filter(subcategory_id=subcategory)
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)
        if payment:
            queryset = queryset.filter(payment_type_id=payment)

        return queryset

    @extend_schema(
        parameters=[
            OpenApiParameter('year', int),
            OpenApiParameter('month', int),
        ]
    )
    @action(detail=False, methods=['get'])
    def chart_data(self, request):
        year = request.query_params.get('year', datetime.now().year)
        month = request.query_params.get('month')

        queryset = self.queryset.filter(date__year=year)
        if month:
            queryset = queryset.filter(date__month=month)

        # Line chart - oylik
        monthly = queryset.values('date__month').annotate(total=Sum('amount')).order_by('date__month')

        # Pie chart - kategoriya bo'yicha
        by_category = queryset.values('subcategory__type').annotate(total=Sum('amount'))

        return Response({
            'line_chart': list(monthly),
            'pie_chart': list(by_category)
        })

    @action(detail=False, methods=['get'])
    def directors_summary(self, request):
        ceo = self.queryset.filter(comment__icontains='CEO').aggregate(total=Sum('amount'))['total'] or 0
        filial = self.queryset.filter(comment__icontains='filial').aggregate(total=Sum('amount'))['total'] or 0

        return Response({
            'ceo': ceo,
            'filial_directors': filial
        })


# ish haqi


@extend_schema(tags=["Bonus"])
class BonusViewSet(viewsets.ModelViewSet):
    queryset = Bonus.objects.select_related('employee', 'course').all()
    serializer_class = BonusSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        employee = self.request.query_params.get('employee')
        month = self.request.query_params.get('month')
        bonus_type = self.request.query_params.get('bonus_type')

        if employee:
            queryset = queryset.filter(employee_id=employee)
        if month:
            queryset = queryset.filter(month=month)
        if bonus_type:
            queryset = queryset.filter(bonus_type=bonus_type)

        return queryset


@extend_schema(tags=["Fine"])
class FineViewSet(viewsets.ModelViewSet):
    queryset = Fine.objects.select_related('employee').all()
    serializer_class = FineSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        employee = self.request.query_params.get('employee')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if employee:
            queryset = queryset.filter(employee_id=employee)
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)

        return queryset


@extend_schema(tags=["Salary"])
class SalaryViewSet(viewsets.ModelViewSet):
    queryset = Salary.objects.select_related('employee', 'payment_type').all()
    serializer_class = SalarySerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        employee = self.request.query_params.get('employee')
        month = self.request.query_params.get('month')
        is_paid = self.request.query_params.get('is_paid')

        if employee:
            queryset = queryset.filter(employee_id=employee)
        if month:
            queryset = queryset.filter(month=month)
        if is_paid:
            queryset = queryset.filter(is_paid=is_paid == 'true')

        return queryset

    @extend_schema(
        parameters=[
            OpenApiParameter('employee_id', int),
            OpenApiParameter('month', str),
        ]
    )
    @action(detail=False, methods=['post'])
    def calculate(self, request):
        employee_id = request.data.get('employee_id')
        month = request.data.get('month')

        try:
            employee = Employee.objects.get(id=employee_id)
            month_date = datetime.strptime(month, '%Y-%m-%d').date()

            bonuses = Bonus.objects.filter(employee=employee, month=month_date).aggregate(total=Sum('amount'))[
                          'total'] or 0
            fines = \
            Fine.objects.filter(employee=employee, date__year=month_date.year, date__month=month_date.month).aggregate(
                total=Sum('amount'))['total'] or 0

            salary, created = Salary.objects.get_or_create(
                employee=employee,
                month=month_date,
                defaults={
                    'base_amount': employee.base_salary,
                    'bonus_amount': bonuses,
                    'fine_amount': fines,
                }
            )

            if not created:
                salary.bonus_amount = bonuses
                salary.fine_amount = fines
                salary.save()

            return Response(SalarySerializer(salary).data)
        except Employee.DoesNotExist:
            return Response({'error': 'Xodim topilmadi'}, status=404)

    @action(detail=False, methods=['get'])
    def summary(self, request):
        month = request.query_params.get('month')

        queryset = self.queryset
        if month:
            queryset = queryset.filter(month=month)

        total_paid = queryset.filter(is_paid=True).aggregate(total=Sum('total_amount'))['total'] or 0
        total_unpaid = queryset.filter(is_paid=False).aggregate(total=Sum('total_amount'))['total'] or 0

        by_employee = queryset.values('employee__full_name').annotate(
            total=Sum('total_amount'),
            bonuses=Sum('bonus_amount'),
            fines=Sum('fine_amount')
        )

        return Response({
            'total_paid': total_paid,
            'total_unpaid': total_unpaid,
            'by_employee': list(by_employee)
        })




#  ustozni ish haqi
@extend_schema(tags=["TeacherSalaryRules"])
class TeacherSalaryRulesViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryRules.objects.select_related('teacher').all()
    serializer_class = TeacherSalaryRulesSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        teacher = self.request.query_params.get('teacher')
        is_active = self.request.query_params.get('is_active')

        if teacher:
            queryset = queryset.filter(teacher_id=teacher)
        if is_active == 'true':
            today = datetime.now().date()
            queryset = queryset.filter(effective_from__lte=today, effective_to__gte=today)

        return queryset

    @action(detail=False, methods=['post'])
    def bulk_create(self, request):
        """Barcha ustozlar uchun bir xil qoidalar yaratish"""
        percent = request.data.get('percent_per_student')
        fixed_bonus = request.data.get('fixed_bonus')
        effective_from = request.data.get('effective_from')
        effective_to = request.data.get('effective_to')

        if not all([percent, fixed_bonus, effective_from, effective_to]):
            return Response({'error': 'Barcha maydonlar majburiy'}, status=400)

        teachers = Employee.objects.filter(position__icontains='o\'qituvchi')
        created_count = 0

        for teacher in teachers:
            TeacherSalaryRules.objects.create(
                teacher=teacher,
                percent_per_student=percent,
                fixed_bonus=fixed_bonus,
                effective_from=effective_from,
                effective_to=effective_to
            )
            created_count += 1

        return Response({
            'message': f'{created_count} ta ustoz uchun qoidalar yaratildi',
            'percent_per_student': percent,
            'fixed_bonus': fixed_bonus
        })


@extend_schema(tags=["TeacherSalaryPayments"])
class TeacherSalaryPaymentsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryPayments.objects.select_related('teacher').all()
    serializer_class = TeacherSalaryPaymentsSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        teacher = self.request.query_params.get('teacher')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        payment_type = self.request.query_params.get('payment_type')

        if teacher:
            queryset = queryset.filter(teacher_id=teacher)
        if start_date:
            queryset = queryset.filter(payment_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(payment_date__lte=end_date)
        if payment_type:
            queryset = queryset.filter(payment_type=payment_type)

        return queryset

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """To'lovlar summasi"""
        teacher = request.query_params.get('teacher')
        month = request.query_params.get('month')

        queryset = self.queryset
        if teacher:
            queryset = queryset.filter(teacher_id=teacher)
        if month:
            queryset = queryset.filter(payment_date__month=month)

        total = queryset.aggregate(total=Sum('amount'))['total'] or 0
        by_type = queryset.values('payment_type').annotate(total=Sum('amount'))

        return Response({
            'total_paid': total,
            'by_payment_type': list(by_type)
        })


@extend_schema(tags=["TeacherSalaryCalculations"])
class TeacherSalaryCalculationsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryCalculations.objects.select_related('teacher', 'group').all()
    serializer_class = TeacherSalaryCalculationsSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        teacher = self.request.query_params.get('teacher')
        group = self.request.query_params.get('group')
        month = self.request.query_params.get('month')

        if teacher:
            queryset = queryset.filter(teacher_id=teacher)
        if group:
            queryset = queryset.filter(group_id=group)
        if month:
            queryset = queryset.filter(month=month)

        return queryset

    @action(detail=False, methods=['post'])
    def calculate(self, request):
        """Maoshni hisoblash"""
        teacher_id = request.data.get('teacher_id')
        group_id = request.data.get('group_id')
        month = request.data.get('month')
        student_count = request.data.get('student_count')

        if not all([teacher_id, group_id, month, student_count]):
            return Response({'error': 'Barcha maydonlar majburiy'}, status=400)

        try:
            teacher = Employee.objects.get(id=teacher_id)
            today = datetime.now().date()

            # Aktiv qoidani topish
            rule = TeacherSalaryRules.objects.filter(
                teacher=teacher,
                effective_from__lte=today,
                effective_to__gte=today
            ).first()

            if not rule:
                return Response({'error': 'Aktiv qoida topilmadi'}, status=404)

            # Hisoblash
            percent = rule.percent_per_student
            total = (student_count * percent) + rule.fixed_bonus

            calculation = TeacherSalaryCalculations.objects.create(
                teacher_id=teacher_id,
                group_id=group_id,
                month=month,
                student_count=student_count,
                percent=percent,
                total_amount=total,
                calculated_at=today
            )

            return Response(TeacherSalaryCalculationsSerializer(calculation).data)
        except Employee.DoesNotExist:
            return Response({'error': 'Ustoz topilmadi'}, status=404)

    @action(detail=False, methods=['get'])
    def monthly_report(self, request):
        """Oylik hisobot"""
        teacher = request.query_params.get('teacher')
        month = request.query_params.get('month')

        if not month:
            return Response({'error': 'month majburiy'}, status=400)

        queryset = self.queryset.filter(month=month)
        if teacher:
            queryset = queryset.filter(teacher_id=teacher)

        total_calculated = queryset.aggregate(total=Sum('total_amount'))['total'] or 0
        total_students = queryset.aggregate(total=Sum('student_count'))['total'] or 0

        by_teacher = queryset.values('teacher__full_name').annotate(
            total=Sum('total_amount'),
            students=Sum('student_count'),
            groups=Count('group')
        )

        # To'lovlar bilan solishtirish
        if teacher:
            paid = TeacherSalaryPayments.objects.filter(
                teacher_id=teacher,
                payment_date__month=month
            ).aggregate(total=Sum('amount'))['total'] or 0
        else:
            paid = TeacherSalaryPayments.objects.filter(
                payment_date__month=month
            ).aggregate(total=Sum('amount'))['total'] or 0

        return Response({
            'month': month,
            'total_calculated': total_calculated,
            'total_paid': paid,
            'debt': total_calculated - paid,
            'total_students': total_students,
            'by_teacher': list(by_teacher)
        })


@extend_schema(tags=["TeacherSalaryRules"])
class TeacherSalaryRulesViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryRules.objects.select_related('teacher').all()
    serializer_class = TeacherSalaryRulesSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        teacher = self.request.query_params.get('teacher')
        is_active = self.request.query_params.get('is_active')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if teacher:
            queryset = queryset.filter(teacher_id=teacher)
        if is_active == 'true':
            today = datetime.now().date()
            queryset = queryset.filter(effective_from__lte=today, effective_to__gte=today)
        if start_date:
            queryset = queryset.filter(effective_from__gte=start_date)
        if end_date:
            queryset = queryset.filter(effective_to__lte=end_date)

        return queryset

    @extend_schema(
        request=PayPeriodSerializer,
        responses={200: TeacherSalaryRulesSerializer(many=True)}
    )
    @action(detail=False, methods=['post'])
    def get_by_period(self, request):
        """Tanlangan davrdagi barcha qoidalarni olish"""
        serializer = PayPeriodSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        start = serializer.validated_data['start_date']
        end = serializer.validated_data['end_date']

        rules = self.queryset.filter(
            effective_from__lte=end,
            effective_to__gte=start
        )

        return Response({
            'period': {'start_date': start, 'end_date': end},
            'count': rules.count(),
            'rules': TeacherSalaryRulesSerializer(rules, many=True).data
        })

    @extend_schema(
        request=BulkSalaryConfigSerializer,
        responses={200: {'type': 'object'}}
    )
    @action(detail=False, methods=['post'])
    def configure_period(self, request):
        """Sana tanlab barcha sozlamalarni kiritish"""
        serializer = BulkSalaryConfigSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data
        start = data['start_date']
        end = data['end_date']
        percent = data['percent_per_student']
        fixed = data['fixed_bonus']

        if data['apply_to_all']:
            # Barcha ustozlar uchun
            teachers = Employee.objects.filter(position__icontains='o\'qituvchi')
            created = []

            for teacher in teachers:
                rule = TeacherSalaryRules.objects.create(
                    teacher=teacher,
                    percent_per_student=percent,
                    fixed_bonus=fixed,
                    effective_from=start,
                    effective_to=end
                )
                created.append(rule)

            return Response({
                'message': f'{len(created)} ta ustoz uchun sozlamalar yaratildi',
                'period': f'{start} - {end}',
                'percent_per_student': percent,
                'fixed_bonus': fixed,
                'created_count': len(created)
            })
        else:
            return Response({'error': 'apply_to_all=false qo\'llab-quvvatlanmaydi'}, status=400)

    @action(detail=False, methods=['get'])
    def active_periods(self, request):
        """Faol davrlarni ko'rish"""
        periods = self.queryset.values('effective_from', 'effective_to').distinct().order_by('-effective_from')

        result = []
        for period in periods:
            start = period['effective_from']
            end = period['effective_to']
            count = self.queryset.filter(effective_from=start, effective_to=end).count()

            result.append({
                'start_date': start,
                'end_date': end,
                'name': f"{start.strftime('%B %Y')} - {end.strftime('%B %Y')}",
                'teacher_count': count,
                'is_active': start <= datetime.now().date() <= end
            })

        return Response(result)

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, description='YYYY-MM-DD'),
            OpenApiParameter('end_date', str, description='YYYY-MM-DD'),
        ]
    )
    @action(detail=False, methods=['get'])
    def period_summary(self, request):
        """Davr bo'yicha hisoblash"""
        start = request.query_params.get('start_date')
        end = request.query_params.get('end_date')

        if not start or not end:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        # Qoidalar
        rules = self.queryset.filter(effective_from__lte=end, effective_to__gte=start)

        # Hisoblar
        calculations = TeacherSalaryCalculations.objects.filter(
            calculated_at__range=[start, end]
        )

        # To'lovlar
        payments = TeacherSalaryPayments.objects.filter(
            payment_date__range=[start, end]
        )

        total_calculated = calculations.aggregate(total=Sum('total_amount'))['total'] or 0
        total_paid = payments.aggregate(total=Sum('amount'))['total'] or 0

        return Response({
            'period': {'start': start, 'end': end},
            'active_rules': rules.count(),
            'total_calculated': total_calculated,
            'total_paid': total_paid,
            'debt': total_calculated - total_paid,
            'teachers_with_rules': rules.values('teacher').distinct().count()
        })




# qarzdorlar
@extend_schema(tags=["Debts - Qarzdorlar"])
class StudentDebtsViewSet(viewsets.ReadOnlyModelViewSet):
    """Talabalar qarzi"""
    queryset = Sale.objects.filter(debt_amount__gt=0)
    serializer_class = SaleSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        name = self.request.query_params.get('name')
        min_debt = self.request.query_params.get('min_debt')
        max_debt = self.request.query_params.get('max_debt')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        course = self.request.query_params.get('course')

        if name:
            queryset = queryset.filter(customer_name__icontains=name)
        if min_debt:
            queryset = queryset.filter(debt_amount__gte=min_debt)
        if max_debt:
            queryset = queryset.filter(debt_amount__lte=max_debt)
        if start_date:
            queryset = queryset.filter(sale_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(sale_date__lte=end_date)
        if course:
            queryset = queryset.filter(course__icontains=course)

        return queryset.order_by('-debt_amount')

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Talabalar qarzi jami"""
        queryset = self.get_queryset()

        total_debt = queryset.aggregate(total=Sum('debt_amount'))['total'] or 0
        debtors_count = queryset.count()
        total_amount = queryset.aggregate(total=Sum('amount'))['total'] or 0
        paid_amount = total_amount - total_debt

        by_course = queryset.values('course').annotate(
            total_debt=Sum('debt_amount'),
            count=Count('id')
        ).order_by('-total_debt')

        return Response({
            'total_debt': total_debt,
            'debtors_count': debtors_count,
            'total_amount': total_amount,
            'paid_amount': paid_amount,
            'by_course': list(by_course)
        })


@extend_schema(tags=["Debts - Qarzdorlar"])
class TeacherDebtsViewSet(viewsets.ViewSet):
    """Ustozlar qarzi"""

    def list(self, request):
        name = request.query_params.get('name')
        month = request.query_params.get('month')
        min_debt = request.query_params.get('min_debt')

        # Har bir ustoz uchun hisoblangan va to'langan summani topish
        teachers = Employee.objects.filter(position__icontains='o\'qituvchi')

        debts = []
        for teacher in teachers:
            if name and name.lower() not in teacher.full_name.lower():
                continue

            # Hisoblangan summa
            calculated_qs = TeacherSalaryCalculations.objects.filter(teacher=teacher)
            if month:
                calculated_qs = calculated_qs.filter(month=month)
            calculated = calculated_qs.aggregate(total=Sum('total_amount'))['total'] or 0

            # To'langan summa
            paid_qs = TeacherSalaryPayments.objects.filter(teacher=teacher)
            if month:
                month_date = datetime.strptime(month, '%Y-%m-%d')
                paid_qs = paid_qs.filter(payment_date__year=month_date.year, payment_date__month=month_date.month)
            paid = paid_qs.aggregate(total=Sum('amount'))['total'] or 0

            debt = calculated - paid

            if debt > 0:
                if min_debt and debt < float(min_debt):
                    continue

                debts.append({
                    'teacher_id': teacher.id,
                    'teacher_name': teacher.full_name,
                    'phone': teacher.phone,
                    'calculated_amount': calculated,
                    'paid_amount': paid,
                    'debt_amount': debt,
                    'month': month or 'Barchasi'
                })

        # Qarzga ko'ra saralash
        debts.sort(key=lambda x: x['debt_amount'], reverse=True)

        return Response(debts)

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Ustozlar qarzi jami"""
        month = request.query_params.get('month')

        teachers = Employee.objects.filter(position__icontains='o\'qituvchi')

        total_calculated = 0
        total_paid = 0
        debtors = []

        for teacher in teachers:
            calculated_qs = TeacherSalaryCalculations.objects.filter(teacher=teacher)
            paid_qs = TeacherSalaryPayments.objects.filter(teacher=teacher)

            if month:
                calculated_qs = calculated_qs.filter(month=month)
                month_date = datetime.strptime(month, '%Y-%m-%d')
                paid_qs = paid_qs.filter(payment_date__year=month_date.year, payment_date__month=month_date.month)

            calculated = calculated_qs.aggregate(total=Sum('total_amount'))['total'] or 0
            paid = paid_qs.aggregate(total=Sum('amount'))['total'] or 0

            total_calculated += calculated
            total_paid += paid

            if calculated - paid > 0:
                debtors.append(teacher.full_name)

        return Response({
            'total_calculated': total_calculated,
            'total_paid': total_paid,
            'total_debt': total_calculated - total_paid,
            'debtors_count': len(debtors),
            'month': month or 'Barchasi'
        })


@extend_schema(tags=["Debts - Qarzdorlar"])
class AllDebtsView(APIView):
    """Barcha qarzdorlar - talabalar va ustozlar"""

    def get(self, request):
        month = request.query_params.get('month')

        # Talabalar qarzi
        student_debts = Sale.objects.filter(debt_amount__gt=0)
        if month:
            student_debts = student_debts.filter(month=month)

        student_total = student_debts.aggregate(total=Sum('debt_amount'))['total'] or 0
        student_count = student_debts.count()

        # Ustozlar qarzi
        teachers = Employee.objects.filter(position__icontains='o\'qituvchi')
        teacher_total_debt = 0
        teacher_debtors = 0

        for teacher in teachers:
            calculated_qs = TeacherSalaryCalculations.objects.filter(teacher=teacher)
            paid_qs = TeacherSalaryPayments.objects.filter(teacher=teacher)

            if month:
                calculated_qs = calculated_qs.filter(month=month)
                month_date = datetime.strptime(month, '%Y-%m-%d')
                paid_qs = paid_qs.filter(payment_date__year=month_date.year, payment_date__month=month_date.month)

            calculated = calculated_qs.aggregate(total=Sum('total_amount'))['total'] or 0
            paid = paid_qs.aggregate(total=Sum('amount'))['total'] or 0
            debt = calculated - paid

            if debt > 0:
                teacher_total_debt += debt
                teacher_debtors += 1

        return Response({
            'total_student_debt': student_total,
            'total_teacher_debt': teacher_total_debt,
            'total_debt': student_total + teacher_total_debt,
            'student_debtors_count': student_count,
            'teacher_debtors_count': teacher_debtors,
            'total_debtors_count': student_count + teacher_debtors,
            'month': month or 'Barchasi',
            'breakdown': {
                'students': {
                    'debt': student_total,
                    'count': student_count
                },
                'teachers': {
                    'debt': teacher_total_debt,
                    'count': teacher_debtors
                }
            }
        })

# konversiya



@extend_schema(tags=["CRM - Konversiya Hisobotlari"])
class ConversionReportViewSet(viewsets.ViewSet):
    """Konversiya hisobotlari"""

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, description='YYYY-MM-DD'),
            OpenApiParameter('end_date', str, description='YYYY-MM-DD'),
            OpenApiParameter('source', int, description='Manba ID'),
            OpenApiParameter('assigned_to', int, description='Xodim ID'),
        ]
    )
    @action(detail=False, methods=['get'])
    def overview(self, request):
        """Umumiy ko'rsatkichlar"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        source = request.query_params.get('source')
        assigned_to = request.query_params.get('assigned_to')

        queryset = CRMLead.objects.all()

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)
        if source:
            queryset = queryset.filter(source_id=source)
        if assigned_to:
            queryset = queryset.filter(assigned_to_id=assigned_to)

        total_leads = queryset.count()
        active_leads = queryset.filter(status='active').count()
        converted_leads = queryset.filter(status='converted').count()
        lost_leads = queryset.filter(status='lost').count()

        conversion_rate = (converted_leads / total_leads * 100) if total_leads > 0 else 0

        return Response({
            'total_leads': total_leads,
            'active_leads': active_leads,
            'converted_leads': converted_leads,
            'lost_leads': lost_leads,
            'conversion_rate': round(conversion_rate, 2),
            'date_range': {
                'start': start_date,
                'end': end_date
            }
        })

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str),
            OpenApiParameter('end_date', str),
        ]
    )
    @action(detail=False, methods=['get'])
    def funnel(self, request):
        """Sotuv voronkasi (har bir bosqich)"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = CRMLead.objects.all()

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        total_leads = queryset.count()

        # Har bir pipeline bo'yicha
        pipelines = CRMPipelines.objects.all().order_by('position')
        funnel_data = []

        for pipeline in pipelines:
            leads_in_pipeline = queryset.filter(pipline=pipeline).count()
            percentage = (leads_in_pipeline / total_leads * 100) if total_leads > 0 else 0

            # Conversion rate - keyingi bosqichga o'tganlar foizi
            if pipeline.position > 1:
                prev_pipeline = pipelines.filter(position=pipeline.position - 1).first()
                if prev_pipeline:
                    prev_count = queryset.filter(pipline=prev_pipeline).count()
                    conversion = (leads_in_pipeline / prev_count * 100) if prev_count > 0 else 0
                else:
                    conversion = 0
            else:
                conversion = 100

            funnel_data.append({
                'pipeline_name': pipeline.name,
                'pipeline_position': pipeline.position,
                'total_leads': leads_in_pipeline,
                'percentage': round(percentage, 2),
                'conversion_rate': round(conversion, 2)
            })

        return Response({
            'total_leads': total_leads,
            'funnel': funnel_data
        })

    @action(detail=False, methods=['get'])
    def by_source(self, request):
        """Manba bo'yicha konversiya"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = CRMLead.objects.all()

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        sources_data = queryset.values('source__name').annotate(
            total=Count('id'),
            active=Count('id', filter=Q(status='active')),
            converted=Count('id', filter=Q(status='converted')),
            lost=Count('id', filter=Q(status='lost'))
        )

        result = []
        for source in sources_data:
            total = source['total']
            converted = source['converted']
            conversion_rate = (converted / total * 100) if total > 0 else 0

            result.append({
                'source_name': source['source__name'] or 'Noma\'lum',
                'total_leads': total,
                'active': source['active'],
                'converted': converted,
                'lost': source['lost'],
                'conversion_rate': round(conversion_rate, 2)
            })

        result.sort(key=lambda x: x['conversion_rate'], reverse=True)

        return Response(result)

    @action(detail=False, methods=['get'])
    def by_employee(self, request):
        """Xodim bo'yicha konversiya"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = CRMLead.objects.all()

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        employees_data = queryset.values(
            'assigned_to__first_name',
            'assigned_to__last_name'
        ).annotate(
            total=Count('id'),
            active=Count('id', filter=Q(status='active')),
            converted=Count('id', filter=Q(status='converted')),
            lost=Count('id', filter=Q(status='lost'))
        )

        result = []
        for emp in employees_data:
            total = emp['total']
            converted = emp['converted']
            conversion_rate = (converted / total * 100) if total > 0 else 0

            full_name = f"{emp['assigned_to__first_name'] or ''} {emp['assigned_to__last_name'] or ''}".strip()

            result.append({
                'employee_name': full_name or 'Tayinlanmagan',
                'total_leads': total,
                'active': emp['active'],
                'converted': converted,
                'lost': emp['lost'],
                'conversion_rate': round(conversion_rate, 2)
            })

        result.sort(key=lambda x: x['conversion_rate'], reverse=True)

        return Response(result)

    @action(detail=False, methods=['get'])
    def pipeline_transitions(self, request):
        """Pipeline o'zgarishlari tarixi"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = CRMLeadsHistory.objects.select_related(
            'old_pipeline', 'new_pipeline', 'lead', 'changed_by'
        ).all()

        if start_date:
            queryset = queryset.filter(changed_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(changed_at__lte=end_date)

        transitions = []
        for history in queryset[:100]:  # Oxirgi 100 ta
            transitions.append({
                'lead_name': history.lead.full_name,
                'from_pipeline': history.old_pipeline.name if history.old_pipeline else 'Yangi',
                'to_pipeline': history.new_pipeline.name if history.new_pipeline else 'Noma\'lum',
                'changed_by': history.changed_by.get_full_name() if history.changed_by else 'Noma\'lum',
                'changed_at': history.changed_at
            })

        return Response(transitions)

    @action(detail=False, methods=['get'])
    def lost_reasons(self, request):
        """Yo'qotilgan sabablar tahlili"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = CRMLeadLost.objects.select_related('reason', 'lead').all()

        if start_date:
            queryset = queryset.filter(created_at__gte=start_date)
        if end_date:
            queryset = queryset.filter(created_at__lte=end_date)

        reasons_data = queryset.values('reason__name').annotate(
            count=Count('id')
        ).order_by('-count')

        total = queryset.count()

        result = []
        for reason in reasons_data:
            count = reason['count']
            percentage = (count / total * 100) if total > 0 else 0

            result.append({
                'reason': reason['reason__name'] or 'Noma\'lum',
                'count': count,
                'percentage': round(percentage, 2)
            })

        return Response({
            'total_lost': total,
            'reasons': result
        })


@extend_schema(tags=["CRM - Leads"])
class CRMLeadViewSet(viewsets.ModelViewSet):
    queryset = CRMLead.objects.select_related('source', 'pipline', 'assigned_to').all()
    serializer_class = CRMLeadSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        status = self.request.query_params.get('status')
        source = self.request.query_params.get('source')
        pipeline = self.request.query_params.get('pipeline')
        assigned_to = self.request.query_params.get('assigned_to')
        search = self.request.query_params.get('search')

        if status:
            queryset = queryset.filter(status=status)
        if source:
            queryset = queryset.filter(source_id=source)
        if pipeline:
            queryset = queryset.filter(pipline_id=pipeline)
        if assigned_to:
            queryset = queryset.filter(assigned_to_id=assigned_to)
        if search:
            queryset = queryset.filter(
                Q(full_name__icontains=search) | Q(phone_number__icontains=search)
            )

        return queryset.order_by('-created_at')


from django.db.models.functions import TruncMonth, ExtractHour


# Lid hisobotlarini ko'rish uchun API chqiaris
@extend_schema(tags=["Lidlar Hisoboti"])
class LeadsReportViewSet(viewsets.ViewSet):
    """Lidlar hisoboti va diagrammalar"""

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, description='YYYY-MM-DD', required=True),
            OpenApiParameter('end_date', str, description='YYYY-MM-DD', required=True),
        ]
    )
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Umumiy statistika va diagrammalar"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        # Lidlar soni
        leads = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )

        total_leads = leads.count()

        # Kanal bo'yicha (Pie chart)
        by_source = leads.values('source__name').annotate(
            count=Count('id')
        ).order_by('-count')

        source_data = []
        for item in by_source:
            percentage = (item['count'] / total_leads * 100) if total_leads > 0 else 0
            source_data.append({
                'source': item['source__name'] or 'Boshqalar',
                'count': item['count'],
                'percentage': round(percentage, 2)
            })

        # Oylik tahlil (Bar chart)
        by_month = leads.annotate(
            month=TruncMonth('created_at')
        ).values('month').annotate(
            count=Count('id')
        ).order_by('month')

        month_data = []
        for item in by_month:
            month_data.append({
                'month': item['month'].strftime('%Y-%m'),
                'month_name': item['month'].strftime('%B %Y'),
                'count': item['count']
            })

        return Response({
            'total_leads': total_leads,
            'start_date': start_date,
            'end_date': end_date,
            'summary': f"Lidlar soni: {total_leads} ({start_date} — {end_date})",
            'by_source': source_data,
            'by_month': month_data
        })

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
        ]
    )
    @action(detail=False, methods=['get'])
    def pie_chart(self, request):
        """Kanal bo'yicha taqsimot (Pirog diagrammasi)"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leads = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )

        total = leads.count()

        by_source = leads.values('source__name').annotate(
            count=Count('id')
        ).order_by('-count')

        result = []
        for item in by_source:
            percentage = (item['count'] / total * 100) if total > 0 else 0
            result.append({
                'label': item['source__name'] or 'Boshqalar',
                'value': item['count'],
                'percentage': round(percentage, 2)
            })

        return Response({
            'total': total,
            'data': result
        })

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
        ]
    )
    @action(detail=False, methods=['get'])
    def bar_chart(self, request):
        """Oylik tahlil (Shtabik diagramma)"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leads = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )

        by_month = leads.annotate(
            month=TruncMonth('created_at')
        ).values('month').annotate(
            count=Count('id')
        ).order_by('month')

        result = []
        for item in by_month:
            result.append({
                'month': item['month'].strftime('%Y-%m'),
                'month_name': item['month'].strftime('%B %Y'),
                'count': item['count']
            })

        return Response({
            'data': result
        })

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Qisqacha umumiy ma'lumot"""
        # Oxirgi 30 kun
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=30)

        total = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        ).count()

        # Eng ko'p lid kelgan manba
        top_source = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        ).values('source__name').annotate(
            count=Count('id')
        ).order_by('-count').first()

        # Oxirgi oylik o'sish
        prev_start = start_date - timedelta(days=30)
        prev_total = CRMLead.objects.filter(
            created_at__date__gte=prev_start,
            created_at__date__lt=start_date
        ).count()

        growth = ((total - prev_total) / prev_total * 100) if prev_total > 0 else 0

        return Response({
            'period': 'Oxirgi 30 kun',
            'total_leads': total,
            'top_source': top_source['source__name'] if top_source else 'Noma\'lum',
            'top_source_count': top_source['count'] if top_source else 0,
            'growth_percentage': round(growth, 2),
            'start_date': start_date,
            'end_date': end_date
        })

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
            OpenApiParameter('source', int, description='Manba ID'),
        ]
    )
    @action(detail=False, methods=['get'])
    def detailed_report(self, request):
        """Batafsil hisobot"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        source = request.query_params.get('source')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leads = CRMLead.objects.filter(
            created_at__date__gte=start_date,
            created_at__date__lte=end_date
        )

        if source:
            leads = leads.filter(source_id=source)

        total = leads.count()
        active = leads.filter(status='active').count()
        converted = leads.filter(status='converted').count()
        lost = leads.filter(status='lost').count()

        # Gender bo'yicha
        by_gender = leads.values('gender').annotate(count=Count('id'))

        # Expected course bo'yicha
        by_course = leads.exclude(expected_course='').values('expected_course').annotate(
            count=Count('id')
        ).order_by('-count')[:5]

        return Response({
            'period': f"{start_date} — {end_date}",
            'total_leads': total,
            'status_breakdown': {
                'active': active,
                'converted': converted,
                'lost': lost
            },
            'by_gender': list(by_gender),
            'top_courses': list(by_course)
        })

# Guruhni tark etgan talabalar hisoboti ko'rish uchun API yaratish



@extend_schema(tags=["Guruhni tark etgan o'quvchilar"])
class StudentLeavesReportViewSet(viewsets.ViewSet):
    """Guruhni tark etgan o'quvchilar hisoboti"""

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, description='YYYY-MM-DD', required=True),
            OpenApiParameter('end_date', str, description='YYYY-MM-DD', required=True),
            OpenApiParameter('course', int, description='Kurs ID'),
            OpenApiParameter('teacher', int, description='Ustoz ID'),
            OpenApiParameter('leave_reason', int, description='Chiqish sababi ID'),
        ]
    )
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Umumiy statistika va barcha grafiklar"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        course = request.query_params.get('course')
        teacher = request.query_params.get('teacher')
        leave_reason = request.query_params.get('leave_reason')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        # Asosiy queryset
        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        ).select_related('student', 'group', 'leave_reason', 'created_by', 'group__course')

        # Filtrlar
        if course:
            leaves = leaves.filter(group__course_id=course)
        if teacher:
            # Ustoz bo'yicha filtr
            teacher_groups = GroupTeacher.objects.filter(teacher_id=teacher).values_list('group_id', flat=True)
            leaves = leaves.filter(group_id__in=teacher_groups)
        if leave_reason:
            leaves = leaves.filter(leave_reason_id=leave_reason)

        total_count = leaves.count()

        # 1. Ustoz kesimida
        teacher_data = []
        teacher_groups = GroupTeacher.objects.filter(
            group_id__in=leaves.values_list('group_id', flat=True)
        ).select_related('teacher', 'group')

        teacher_stats = {}
        for tg in teacher_groups:
            teacher_name = tg.teacher.full_name
            group_leaves = leaves.filter(group=tg.group).count()

            if teacher_name in teacher_stats:
                teacher_stats[teacher_name] += group_leaves
            else:
                teacher_stats[teacher_name] = group_leaves

        for name, count in teacher_stats.items():
            teacher_data.append({'teacher': name, 'count': count})

        teacher_data.sort(key=lambda x: x['count'], reverse=True)

        # 2. Kurs kesimida
        by_course = leaves.values('group__course__name').annotate(
            count=Count('id')
        ).order_by('-count')

        course_data = [
            {'course': item['group__course__name'] or 'Noma\'lum', 'count': item['count']}
            for item in by_course
        ]

        # 3. Oylik kesimida
        by_month = leaves.annotate(
            month=TruncMonth('leave_date')
        ).values('month').annotate(
            count=Count('id')
        ).order_by('month')

        month_data = [
            {
                'month': item['month'].strftime('%Y-%m'),
                'month_name': item['month'].strftime('%B %Y'),
                'count': item['count']
            }
            for item in by_month
        ]

        # 4. Sabab kesimida
        by_reason = leaves.values('leave_reason__name').annotate(
            count=Count('id')
        ).order_by('-count')

        reason_data = [
            {'reason': item['leave_reason__name'] or 'Noma\'lum', 'count': item['count']}
            for item in by_reason
        ]

        return Response({
            'total_count': total_count,
            'period': f"{start_date} — {end_date}",
            'by_teacher': teacher_data,
            'by_course': course_data,
            'by_month': month_data,
            'by_reason': reason_data
        })

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
            OpenApiParameter('teacher', int),
        ]
    )
    @action(detail=False, methods=['get'])
    def by_teacher(self, request):
        """Ustoz kesimida"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        teacher = request.query_params.get('teacher')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        )

        teacher_groups = GroupTeacher.objects.select_related('teacher', 'group')

        if teacher:
            teacher_groups = teacher_groups.filter(teacher_id=teacher)

        teacher_groups = teacher_groups.filter(
            group_id__in=leaves.values_list('group_id', flat=True)
        )

        result = {}
        for tg in teacher_groups:
            teacher_name = tg.teacher.full_name
            count = leaves.filter(group=tg.group).count()

            if teacher_name in result:
                result[teacher_name] += count
            else:
                result[teacher_name] = count

        data = [{'teacher': k, 'count': v} for k, v in result.items()]
        data.sort(key=lambda x: x['count'], reverse=True)

        return Response({'data': data})

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
            OpenApiParameter('course', int),
        ]
    )
    @action(detail=False, methods=['get'])
    def by_course(self, request):
        """Kurs kesimida"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        course = request.query_params.get('course')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        )

        if course:
            leaves = leaves.filter(group__course_id=course)

        by_course = leaves.values('group__course__name').annotate(
            count=Count('id')
        ).order_by('-count')

        data = [
            {'course': item['group__course__name'] or 'Noma\'lum', 'count': item['count']}
            for item in by_course
        ]

        return Response({'data': data})

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
        ]
    )
    @action(detail=False, methods=['get'])
    def by_month(self, request):
        """Oylik kesimida"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        )

        by_month = leaves.annotate(
            month=TruncMonth('leave_date')
        ).values('month').annotate(
            count=Count('id')
        ).order_by('month')

        data = [
            {
                'month': item['month'].strftime('%Y-%m'),
                'month_name': item['month'].strftime('%B %Y'),
                'count': item['count']
            }
            for item in by_month
        ]

        return Response({'data': data})

    @extend_schema(
        parameters=[
            OpenApiParameter('start_date', str, required=True),
            OpenApiParameter('end_date', str, required=True),
            OpenApiParameter('leave_reason', int),
        ]
    )
    @action(detail=False, methods=['get'])
    def by_reason(self, request):
        """Sabab kesimida"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        leave_reason = request.query_params.get('leave_reason')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        )

        if leave_reason:
            leaves = leaves.filter(leave_reason_id=leave_reason)

        by_reason = leaves.values('leave_reason__name').annotate(
            count=Count('id')
        ).order_by('-count')

        data = [
            {'reason': item['leave_reason__name'] or 'Noma\'lum', 'count': item['count']}
            for item in by_reason
        ]

        return Response({'data': data})

    @action(detail=False, methods=['get'])
    def detailed_list(self, request):
        """Batafsil ro'yxat"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        course = request.query_params.get('course')
        teacher = request.query_params.get('teacher')
        leave_reason = request.query_params.get('leave_reason')

        if not start_date or not end_date:
            return Response({'error': 'start_date va end_date majburiy'}, status=400)

        leaves = StudentGroupLeaves.objects.filter(
            leave_date__date__gte=start_date,
            leave_date__date__lte=end_date
        ).select_related('student', 'group', 'leave_reason', 'created_by', 'group__course')

        if course:
            leaves = leaves.filter(group__course_id=course)
        if teacher:
            teacher_groups = GroupTeacher.objects.filter(teacher_id=teacher).values_list('group_id', flat=True)
            leaves = leaves.filter(group_id__in=teacher_groups)
        if leave_reason:
            leaves = leaves.filter(leave_reason_id=leave_reason)

        return Response(StudentGroupLeavesSerializer(leaves, many=True).data)


@extend_schema(tags=["StudentGroupLeaves"])
class StudentGroupLeavesViewSet(viewsets.ModelViewSet):
    queryset = StudentGroupLeaves.objects.select_related('student', 'group', 'leave_reason', 'created_by').all()
    serializer_class = StudentGroupLeavesSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        student = self.request.query_params.get('student')
        group = self.request.query_params.get('group')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if student:
            queryset = queryset.filter(student_id=student)
        if group:
            queryset = queryset.filter(group_id=group)
        if start_date:
            queryset = queryset.filter(leave_date__gte=start_date)
        if end_date:
            queryset = queryset.filter(leave_date__lte=end_date)

        return queryset.order_by('-leave_date')


@extend_schema(tags=["LeaveReason"])
class LeaveReasonViewSet(viewsets.ModelViewSet):
    queryset = LeaveReason.objects.all()
    serializer_class = LeaveReasonSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        is_active = self.request.query_params.get('is_active')

        if is_active:
            queryset = queryset.filter(is_active=is_active == 'true')

        return queryset

# workly
import requests
from django.utils import timezone


@extend_schema(tags=["Workly Integration"])
class WorklyIntegrationViewSet(viewsets.ModelViewSet):
    queryset = WorklyIntegration.objects.all()
    serializer_class = WorklyIntegrationSerializer

    @extend_schema(
        request=WorklyConnectionTestSerializer,
        responses={200: {'type': 'object', 'properties': {'status': {'type': 'string'}}}}
    )
    @action(detail=False, methods=['post'])
    def test_connection(self, request):
        """Workly bilan ulanishni tekshirish"""
        serializer = WorklyConnectionTestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data

        try:
            # Workly API ga so'rov yuborish

            url = "https://api.workly.com/auth/token"  # Misol URL
            payload = {
                'client_id': data['client_id'],
                'client_secret': data['client_secret'],
                'username': data['username'],
                'password': data['password']
            }

            # Test uchun (Workly API hali yo'q bo'lsa):
            return Response({
                'status': 'success',
                'message': 'Test rejimida: Ulanish muvaffaqiyatli',
                'connected': True
            })

        except requests.RequestException as e:
            return Response({
                'status': 'error',
                'message': f'Tarmoq xatosi: {str(e)}',
                'connected': False
            }, status=500)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': f'Xatolik: {str(e)}',
                'connected': False
            }, status=500)

    @action(detail=True, methods=['post'])
    def activate(self, request, pk=None):
        """Integratsiyani faollashtirish"""
        integration = self.get_object()

        # Avval ulanishni tekshirish
        try:
            # Ulanish testi
            integration.is_active = True
            integration.is_connected = True
            integration.error_message = None
            integration.save()

            return Response({
                'status': 'success',
                'message': 'Integratsiya faollashtirildi',
                'is_active': True
            })
        except Exception as e:
            integration.is_active = False
            integration.is_connected = False
            integration.error_message = str(e)
            integration.save()

            return Response({
                'status': 'error',
                'message': f'Faollashtirish xatosi: {str(e)}',
                'is_active': False
            }, status=400)

    @action(detail=True, methods=['post'])
    def deactivate(self, request, pk=None):
        """Integratsiyani o'chirish"""
        integration = self.get_object()
        integration.is_active = False
        integration.is_connected = False
        integration.save()

        return Response({
            'status': 'success',
            'message': 'Integratsiya o\'chirildi',
            'is_active': False
        })

    @action(detail=True, methods=['post'])
    def sync_attendance(self, request, pk=None):
        """Workly dan ishga kelish ma'lumotlarini sinxronlash"""
        integration = self.get_object()

        if not integration.is_active:
            return Response({
                'status': 'error',
                'message': 'Integratsiya faol emas'
            }, status=400)

        try:
            # Workly API dan ma'lumotlarni olish
            # Bu yerda Workly API endpoint va ma'lumotlarni olish logikasi

            # Misol:
            # url = "https://api.workly.com/attendance"
            # headers = {
            #     'Authorization': f'Bearer {access_token}'
            # }
            # response = requests.get(url, headers=headers)
            #
            # if response.status_code == 200:
            #     data = response.json()
            #
            #     # Ma'lumotlarni saqlash
            #     for item in data['records']:
            #         WorklyAttendance.objects.update_or_create(
            #             workly_id=item['id'],
            #             defaults={
            #                 'employee_id': item['employee_id'],
            #                 'date': item['date'],
            #                 'check_in': item['check_in'],
            #                 'check_out': item['check_out'],
            #                 'is_late': item['is_late'],
            #                 'late_minutes': item['late_minutes'],
            #                 'status': item['status']
            #             }
            #         )

            integration.last_sync = timezone.now()
            integration.save()

            return Response({
                'status': 'success',
                'message': 'Ma\'lumotlar muvaffaqiyatli sinxronlandi',
                'synced_at': integration.last_sync
            })

        except Exception as e:
            integration.error_message = str(e)
            integration.save()

            return Response({
                'status': 'error',
                'message': f'Sinxronlash xatosi: {str(e)}'
            }, status=500)

    @action(detail=False, methods=['get'])
    def status(self, request):
        """Integratsiya holati"""
        integration = self.queryset.first()

        if not integration:
            return Response({
                'configured': False,
                'is_active': False,
                'message': 'Integratsiya sozlanmagan'
            })

        return Response({
            'configured': True,
            'is_active': integration.is_active,
            'is_connected': integration.is_connected,
            'last_sync': integration.last_sync,
            'error_message': integration.error_message
        })


@extend_schema(tags=["Workly Attendance"])
class WorklyAttendanceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = WorklyAttendance.objects.select_related('employee').all()
    serializer_class = WorklyAttendanceSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        employee = self.request.query_params.get('employee')
        date = self.request.query_params.get('date')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        is_late = self.request.query_params.get('is_late')

        if employee:
            queryset = queryset.filter(employee_id=employee)
        if date:
            queryset = queryset.filter(date=date)
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)
        if is_late:
            queryset = queryset.filter(is_late=is_late == 'true')

        return queryset.order_by('-date', '-check_in')

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Ishga kelish statistikasi"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = self.queryset

        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)

        total_records = queryset.count()
        late_count = queryset.filter(is_late=True).count()
        on_time_count = total_records - late_count
        total_late_minutes = queryset.filter(is_late=True).aggregate(
            total=Sum('late_minutes')
        )['total'] or 0

        by_employee = queryset.values('employee__full_name').annotate(
            total=Count('id'),
            late=Count('id', filter=Q(is_late=True)),
            total_late_minutes=Sum('late_minutes')
        ).order_by('-late')

        return Response({
            'total_records': total_records,
            'on_time': on_time_count,
            'late': late_count,
            'total_late_minutes': total_late_minutes,
            'by_employee': list(by_employee)
        })


from django.db.models import Q, Avg, Sum, Count


@extend_schema(tags=["Qo'ng'iroqlar Jurnali"])
class CallLogViewSet(viewsets.ModelViewSet):
    queryset = CallLog.objects.select_related('caller').all()
    serializer_class = CallLogSerializer

    def get_queryset(self):
        queryset = super().get_queryset()

        # Sana filtri
        date = self.request.query_params.get('date')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')

        if date:
            queryset = queryset.filter(call_time__date=date)
        if start_date:
            queryset = queryset.filter(call_time__date__gte=start_date)
        if end_date:
            queryset = queryset.filter(call_time__date__lte=end_date)

        # Turi bo'yicha filtr
        call_filter = self.request.query_params.get('type', 'all')

        if call_filter == 'incoming':
            queryset = queryset.filter(call_type='incoming')
        elif call_filter == 'outgoing':
            queryset = queryset.filter(call_type='outgoing')
        elif call_filter == 'missed':
            queryset = queryset.filter(status='missed')
        elif call_filter == 'answered_connected':
            queryset = queryset.filter(status='connected_no_answer')
        elif call_filter == 'unanswered_not_connected':
            queryset = queryset.filter(status='not_connected')
        elif call_filter == 'no_answer':
            queryset = queryset.filter(status='no_answer')

        # Qidirish
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(caller_name__icontains=search) |
                Q(receiver_name__icontains=search) |
                Q(receiver_phone__icontains=search)
            )

        # Caller bo'yicha
        caller = self.request.query_params.get('caller')
        if caller:
            queryset = queryset.filter(caller_id=caller)

        # Gateway bo'yicha
        gateway = self.request.query_params.get('gateway')
        if gateway:
            queryset = queryset.filter(gateway=gateway)

        return queryset

    @extend_schema(
        parameters=[
            OpenApiParameter('date', str, description='YYYY-MM-DD'),
            OpenApiParameter('start_date', str, description='YYYY-MM-DD'),
            OpenApiParameter('end_date', str, description='YYYY-MM-DD'),
            OpenApiParameter('type', str, description='all, incoming, outgoing, missed, etc.'),
        ]
    )
    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Umumiy statistika"""
        queryset = self.get_queryset()

        total_calls = queryset.count()
        incoming_count = queryset.filter(call_type='incoming').count()
        outgoing_count = queryset.filter(call_type='outgoing').count()
        answered = queryset.filter(status='answered').count()
        missed = queryset.filter(status='missed').count()
        no_answer = queryset.filter(status='no_answer').count()

        total_duration = queryset.aggregate(total=Sum('duration'))['total'] or 0
        avg_duration = queryset.aggregate(avg=Avg('duration'))['avg'] or 0

        # Gateway bo'yicha
        by_gateway = queryset.values('gateway').annotate(
            count=Count('id')
        ).order_by('-count')

        # Status bo'yicha
        by_status = queryset.values('status').annotate(
            count=Count('id')
        ).order_by('-count')

        # Operator bo'yicha
        by_caller = queryset.values('caller__full_name').annotate(
            count=Count('id'),
            total_duration=Sum('duration')
        ).order_by('-count')

        return Response({
            'total_calls': total_calls,
            'incoming': incoming_count,
            'outgoing': outgoing_count,
            'answered': answered,
            'missed': missed,
            'no_answer': no_answer,
            'total_duration': total_duration,
            'avg_duration': round(avg_duration, 2),
            'by_gateway': list(by_gateway),
            'by_status': list(by_status),
            'by_caller': list(by_caller[:10])  # Top 10
        })

    @action(detail=False, methods=['get'])
    def daily_report(self, request):
        """Kunlik hisobot"""
        date = request.query_params.get('date', timezone.now().date())

        calls = self.queryset.filter(call_time__date=date)

        hourly_stats = calls.annotate(
            hour=ExtractHour('call_time')
        ).values('hour').annotate(
            count=Count('id'),
            answered=Count('id', filter=Q(status='answered')),
            missed=Count('id', filter=Q(status='missed'))
        ).order_by('hour')

        return Response({
            'date': date,
            'total_calls': calls.count(),
            'hourly_breakdown': list(hourly_stats)
        })

    @action(detail=False, methods=['get'])
    def operator_performance(self, request):
        """Operator samaradorligi"""
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        queryset = self.queryset

        if start_date:
            queryset = queryset.filter(call_time__date__gte=start_date)
        if end_date:
            queryset = queryset.filter(call_time__date__lte=end_date)

        operators = queryset.values(
            'caller_id',
            'caller__full_name'
        ).annotate(
            total_calls=Count('id'),
            answered_calls=Count('id', filter=Q(status='answered')),
            missed_calls=Count('id', filter=Q(status='missed')),
            total_duration=Sum('duration'),
            avg_duration=Avg('duration')
        ).order_by('-total_calls')

        result = []
        for op in operators:
            answer_rate = (op['answered_calls'] / op['total_calls'] * 100) if op['total_calls'] > 0 else 0
            result.append({
                'operator_id': op['caller_id'],
                'operator_name': op['caller__full_name'] or 'Noma\'lum',
                'total_calls': op['total_calls'],
                'answered': op['answered_calls'],
                'missed': op['missed_calls'],
                'answer_rate': round(answer_rate, 2),
                'total_duration': op['total_duration'] or 0,
                'avg_duration': round(op['avg_duration'] or 0, 2)
            })

        return Response(result)

    @action(detail=True, methods=['get'])
    def audio(self, request, pk=None):
        """Audio yozuvni olish"""
        call = self.get_object()

        if not call.audio_file:
            return Response({'error': 'Audio fayl mavjud emas'}, status=404)

        return Response({
            'audio_url': request.build_absolute_uri(call.audio_file.url),
            'duration': call.duration
        })