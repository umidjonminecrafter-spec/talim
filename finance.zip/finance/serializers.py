from rest_framework import serializers
from .models import ExpenseCategory, Expenses,MonthlyIncome, Payment,Sale,DetailedExpense,ExpenseSubcategory,CallLog
from django.db.models import Sum
from accounts.models import Employee
from academics.groups import Course
from .models import Bonus, Fine, Salary,WorklyAttendance,WorklyIntegration
from academics.teacher import TeacherSalaryRules, TeacherSalaryPayments, TeacherSalaryCalculations
from crm.models import (CRMSource, CRMPipelines, CRMLead, CRMActivity,
                        CRMLeadsHistory, CRMLostReason, CRMLeadLost, CRMLeadNotes)
from academics.student import (Student, StudentGroup, StudentGroupLeaves,
                                      LeaveReason)
from academics.group import Group, Course, GroupTeacher
class ExpenseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseCategory
        fields = '__all__'


class ExpensesSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    class Meta:
        model = Expenses
        fields = '__all__'


class MonthlyIncomeSerializer(serializers.ModelSerializer):
    net_profit = serializers.SerializerMethodField()

    class Meta:
        model = MonthlyIncome
        fields = '__all__'

    def get_net_profit(self, obj):
        month_expenses = Expenses.objects.filter(
            expense_date__year=obj.month.year,
            expense_date__month=obj.month.month
        ).aggregate(total=Sum('amount'))['total'] or 0
        return obj.total_amount - month_expenses


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = '__all__'


class SaleSerializer(serializers.ModelSerializer):
    paid_amount = serializers.SerializerMethodField()

    class Meta:
        model = Sale
        fields = '__all__'

    def get_paid_amount(self, obj):
        return obj.amount - obj.debt_amount

    def validate_amount(self, value):
        if value > 500000:
            raise serializers.ValidationError("Summa 500,000 so'mdan oshmasligi kerak")
        return value


class ExpenseSubcategorySerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    total_expenses = serializers.SerializerMethodField()

    class Meta:
        model = ExpenseSubcategory
        fields = '__all__'

    def get_total_expenses(self, obj):
        return obj.detailed_expenses.aggregate(total=Sum('amount'))['total'] or 0


class DetailedExpenseSerializer(serializers.ModelSerializer):
    subcategory_name = serializers.CharField(source='subcategory.name', read_only=True)
    payment_name = serializers.CharField(source='payment_type.name', read_only=True)

    class Meta:
        model = DetailedExpense
        fields = '__all__'

    def validate_amount(self, value):
        if value and value > 1000000:
            raise serializers.ValidationError("Summa 1,000,000 so'mdan oshmasligi kerak")
        return value


# ish haqi


class BonusSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    course_name = serializers.CharField(source='course.name', read_only=True)

    class Meta:
        model = Bonus
        fields = '__all__'


class FineSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)

    class Meta:
        model = Fine
        fields = '__all__'


class SalarySerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    payment_name = serializers.CharField(source='payment_type.name', read_only=True)

    class Meta:
        model = Salary
        fields = '__all__'
        read_only_fields = ('total_amount',)





class TeacherSalaryRulesSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)

    class Meta:
        model = TeacherSalaryRules
        fields = '__all__'

    def validate(self, data):
        if data.get('effective_from') and data.get('effective_to'):
            if data['effective_from'] > data['effective_to']:
                raise serializers.ValidationError("effective_from effective_to dan katta bo'lmasligi kerak")
        return data


class TeacherSalaryPaymentsSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)

    class Meta:
        model = TeacherSalaryPayments
        fields = '__all__'


class TeacherSalaryCalculationsSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)
    group_name = serializers.CharField(source='group.name', read_only=True)

    class Meta:
        model = TeacherSalaryCalculations
        fields = '__all__'
        read_only_fields = ('total_amount',)

# bu sanan boyicha ish haqi
class PayPeriodSerializer(serializers.Serializer):
    """Sana tanlash uchun serializer"""
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    name = serializers.CharField(max_length=100, required=False)

    def validate(self, data):
        if data['start_date'] > data['end_date']:
            raise serializers.ValidationError("Boshlanish sanasi tugash sanasidan katta bo'lmasligi kerak")
        return data


class BulkSalaryConfigSerializer(serializers.Serializer):
    """Barcha ustozlar uchun sozlamalar"""
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    percent_per_student = serializers.DecimalField(max_digits=12, decimal_places=2)
    fixed_bonus = serializers.DecimalField(max_digits=12, decimal_places=2)
    apply_to_all = serializers.BooleanField(default=True)
# qarzdorlar
class StudentDebtSerializer(serializers.Serializer):
    """Talaba qarzi"""
    id = serializers.IntegerField()
    customer_name = serializers.CharField()
    phone = serializers.CharField()
    course = serializers.CharField()
    total_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    debt_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    paid_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    sale_date = serializers.DateTimeField()
    month = serializers.DateField()

class TeacherDebtSerializer(serializers.Serializer):
    """Ustoz qarzi"""
    teacher_id = serializers.IntegerField()
    teacher_name = serializers.CharField()
    phone = serializers.CharField()
    calculated_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    paid_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    debt_amount = serializers.DecimalField(max_digits=12, decimal_places=2)
    month = serializers.CharField()

class AllDebtsSerializer(serializers.Serializer):
    """Umumiy qarzlar"""
    total_student_debt = serializers.DecimalField(max_digits=12, decimal_places=2)
    total_teacher_debt = serializers.DecimalField(max_digits=12, decimal_places=2)
    total_debt = serializers.DecimalField(max_digits=12, decimal_places=2)
    student_debtors_count = serializers.IntegerField()
    teacher_debtors_count = serializers.IntegerField()
    total_debtors_count = serializers.IntegerField()

# konversiya



class CRMSourceSerializer(serializers.ModelSerializer):
    leads_count = serializers.SerializerMethodField()

    class Meta:
        model = CRMSource
        fields = '__all__'

    def get_leads_count(self, obj):
        return obj.source.count()


class CRMPipelinesSerializer(serializers.ModelSerializer):
    leads_count = serializers.SerializerMethodField()

    class Meta:
        model = CRMPipelines
        fields = '__all__'

    def get_leads_count(self, obj):
        return obj.pipline.count()


class CRMLeadSerializer(serializers.ModelSerializer):
    source_name = serializers.CharField(source='source.name', read_only=True)
    pipeline_name = serializers.CharField(source='pipline.name', read_only=True)
    assigned_to_name = serializers.CharField(source='assigned_to.get_full_name', read_only=True)

    class Meta:
        model = CRMLead
        fields = '__all__'


class CRMActivitySerializer(serializers.ModelSerializer):
    lead_name = serializers.CharField(source='lead.full_name', read_only=True)
    created_by_name = serializers.CharField(source='created_by.get_full_name', read_only=True)

    class Meta:
        model = CRMActivity
        fields = '__all__'


class ConversionFunnelSerializer(serializers.Serializer):
    """Sotuv voronkasi ma'lumotlari"""
    pipeline_name = serializers.CharField()
    pipeline_position = serializers.IntegerField()
    total_leads = serializers.IntegerField()
    percentage = serializers.DecimalField(max_digits=5, decimal_places=2)
    conversion_rate = serializers.DecimalField(max_digits=5, decimal_places=2)

# Lid hisobotlarini ko'rish uchun API chqiaris
class LeadsReportSerializer(serializers.Serializer):
    start_date = serializers.DateField()
    end_date = serializers.DateField()

    def validate(self, data):
        if data['start_date'] > data['end_date']:
            raise serializers.ValidationError("Boshlanish sanasi tugash sanasidan katta bo'lmasligi kerak")
        return data


class LeadsStatisticsSerializer(serializers.Serializer):
    total_leads = serializers.IntegerField()
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    by_source = serializers.ListField()
    by_month = serializers.ListField()



# Guruhni tark etgan talabalar hisoboti ko'rish uchun API yaratish

class LeaveReasonSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveReason
        fields = '__all__'


class StudentGroupLeavesSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    group_name = serializers.CharField(source='group.name', read_only=True)
    course_name = serializers.CharField(source='group.course.name', read_only=True)
    reason_name = serializers.CharField(source='leave_reason.name', read_only=True)
    created_by_name = serializers.CharField(source='created_by.full_name', read_only=True)

    class Meta:
        model = StudentGroupLeaves
        fields = '__all__'


class StudentLeavesReportSerializer(serializers.Serializer):
    start_date = serializers.DateField()
    end_date = serializers.DateField()
    course = serializers.IntegerField(required=False)
    teacher = serializers.IntegerField(required=False)
    leave_reason = serializers.IntegerField(required=False)

    def validate(self, data):
        if data['start_date'] > data['end_date']:
            raise serializers.ValidationError("Boshlanish sanasi tugash sanasidan katta bo'lmasligi kerak")
        return data

# Workly hisoboti uchun API yaratish
class WorklyIntegrationSerializer(serializers.ModelSerializer):
    # Read uchun shifrlangan ma'lumotlarni ko'rsatmaymiz
    client_id_masked = serializers.SerializerMethodField()
    client_secret_masked = serializers.SerializerMethodField()
    username_masked = serializers.SerializerMethodField()
    password_masked = serializers.SerializerMethodField()

    class Meta:
        model = WorklyIntegration
        fields = '__all__'
        extra_kwargs = {
            'client_secret': {'write_only': True},
            'password': {'write_only': True}
        }

    def get_client_id_masked(self, obj):
        if obj.client_id:
            decrypted = obj.decrypt_field(obj.client_id)
            return f"{decrypted[:4]}{'*' * (len(decrypted) - 4)}"
        return None

    def get_client_secret_masked(self, obj):
        return "***********" if obj.client_secret else None

    def get_username_masked(self, obj):
        if obj.username:
            decrypted = obj.decrypt_field(obj.username)
            return f"{decrypted[:2]}***"
        return None

    def get_password_masked(self, obj):
        return "***********" if obj.password else None


class WorklyConnectionTestSerializer(serializers.Serializer):
    """Ulanishni tekshirish uchun"""
    client_id = serializers.CharField()
    client_secret = serializers.CharField()
    username = serializers.CharField()
    password = serializers.CharField()


class WorklyAttendanceSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)

    class Meta:
        model = WorklyAttendance
        fields = '__all__'


class CallLogSerializer(serializers.ModelSerializer):
    caller_full_name = serializers.CharField(source='caller.full_name', read_only=True)
    audio_url = serializers.SerializerMethodField()
    duration_formatted = serializers.SerializerMethodField()

    class Meta:
        model = CallLog
        fields = '__all__'

    def get_audio_url(self, obj):
        if obj.audio_file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.audio_file.url)
            return obj.audio_file.url
        return None

    def get_duration_formatted(self, obj):
        """Davomiyatni formatlash (MM:SS)"""
        minutes = obj.duration // 60
        seconds = obj.duration % 60
        return f"{minutes:02d}:{seconds:02d}"


class CallLogFilterSerializer(serializers.Serializer):
    """Filtrlash parametrlari"""
    date = serializers.DateField(required=False)
    start_date = serializers.DateField(required=False)
    end_date = serializers.DateField(required=False)
    call_type = serializers.ChoiceField(
        choices=['all', 'incoming', 'outgoing', 'missed', 'answered_connected',
                 'unanswered_not_connected', 'no_answer'],
        required=False
    )