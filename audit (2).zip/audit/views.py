from django.shortcuts import render
from drf_spectacular.utils import extend_schema
from academics.group import Group
# Create your views here.
from rest_framework import status
from rest_framework import viewsets
from rest_framework.decorators import permission_classes, api_view
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q, Count, Case, When, IntegerField
from django.utils import timezone
from datetime import datetime
from .models import AuditLog
from .serializers import AuditLogSerializer, AttendanceReportSerializer, AttendanceReportFilterSerializer
from ..academics.models import StudentGroup


@extend_schema(tags=["AuditLog - Barcha bajarilgan ishlarni saqlab boradi "])
class AuditLogViewSet(viewsets.ModelViewSet):
    queryset = AuditLog.objects.all()
    serializer_class = AuditLogSerializer


# ==================== VIEWS ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def attendance_report(request):
    """
    Davomat hisoboti

    POST /api/reports/attendance/

    Body:
    {
        "start_date": "2025-01-01",
        "end_date": "2025-01-31",
        "group_id": 1  // optional
    }

    Response:
    {
        "success": true,
        "filters": {
            "start_date": "2025-01-01",
            "end_date": "2025-01-31",
            "group_name": "Python Bootcamp"
        },
        "data": [
            {
                "indicator_name": "Davomat",
                "description": "Talabalar davomat statistikasi",
                "came_once": 45,
                "not_came": 5,
                "not_marked": 2,
                "total": 52
            }
        ]
    }
    """

    # Filtrlarni validatsiya qilish
    filter_serializer = AttendanceReportFilterSerializer(data=request.data)

    if not filter_serializer.is_valid():
        return Response({
            'success': False,
            'errors': filter_serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    start_date = filter_serializer.validated_data['start_date']
    end_date = filter_serializer.validated_data['end_date']
    group_id = filter_serializer.validated_data.get('group_id')

    # Guruhni olish (agar berilgan bo'lsa)
    group = None
    if group_id:
        try:
            group = Group.objects.get(pk=group_id)
        except Group.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Guruh topilmadi.'
            }, status=status.HTTP_404_NOT_FOUND)

    # Talabalarni filtrlash
    student_groups = StudentGroup.objects.filter(
        left_at__gte=timezone.now().date()  # Faqat faol talabalar
    )

    if group:
        student_groups = student_groups.filter(group=group)

    total_students = student_groups.count()

    # 1. KELGAN TALABALAR (eng kam bir marta)
    came_once = student_groups.filter(
        Sgroup_student__A_Sgroup__lesson_date__range=[start_date, end_date],
        Sgroup_student__A_Sgroup__is_present=True
    ).distinct().count()

    # 2. KELMAGAN (martadan ko'p) - hech kelmaganlar yoki ko'p kelmagan
    # Hech davomat qo'yilmagan yoki barcha davomatlari absent
    not_came_ids = []

    for sg in student_groups:
        attendances = sg.A_Sgroup.filter(
            lesson_date__range=[start_date, end_date]
        )

        if attendances.exists():
            # Agar bor bo'lsa, barchasi absent bo'lishi kerak
            if not attendances.filter(is_present=True).exists():
                not_came_ids.append(sg.id)
        else:
            # Agar davomat yo'q bo'lsa ham "kelmagan" deb hisoblanadi
            not_came_ids.append(sg.id)

    not_came = len(not_came_ids)

    # 3. DAVOMAT BELGILANMAGAN
    # Darslar bor lekin davomat qo'yilmagan talabalar

    # Avval guruh darslar sanalarini topamiz (bu murakkabroq, sodda variant)
    # Sodda variant: Hech davomat yo'q talabalar

    marked_students = student_groups.filter(
        Sgroup_student__A_Sgroup__lesson_date__range=[start_date, end_date]
    ).distinct().count()

    not_marked = total_students - marked_students

    # Natija
    report_data = {
        'indicator_name': 'Davomat',
        'description': 'Talabalar davomat statistikasi',
        'came_once': came_once,
        'not_came': not_came,
        'not_marked': not_marked,
        'total': total_students
    }

    serializer = AttendanceReportSerializer(report_data)

    return Response({
        'success': True,
        'filters': {
            'start_date': str(start_date),
            'end_date': str(end_date),
            'group_name': group.name if group else 'Barcha guruhlar'
        },
        'data': [serializer.data]
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def active_groups_list(request):
    """
    Filtr uchun faol guruhlar ro'yxati

    GET /api/reports/groups/

    Response:
    {
        "success": true,
        "data": [
            {"id": 1, "name": "Python Bootcamp"},
            {"id": 2, "name": "JavaScript Pro"}
        ]
    }
    """

    groups = Group.objects.filter(status='active').values('id', 'name').order_by('name')

    return Response({
        'success': True,
        'data': list(groups)
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def attendance_report_v2(request):
    """
    Davomat hisoboti (Yaxshilangan)

    POST /api/reports/attendance/

    Body:
    {
        "start_date": "2025-01-01",
        "end_date": "2025-01-31",
        "group_id": 1  // optional
    }
    """

    start_date = request.data.get('start_date')
    end_date = request.data.get('end_date')
    group_id = request.data.get('group_id')

    # Validatsiya
    if not start_date or not end_date:
        return Response({
            'success': False,
            'message': 'start_date va end_date majburiy.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Guruh
    group = None
    if group_id:
        try:
            group = Group.objects.get(pk=group_id)
        except Group.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Guruh topilmadi.'
            }, status=status.HTTP_404_NOT_FOUND)

    # Faol talabalar
    student_groups = StudentGroup.objects.filter(
        left_at__gte=timezone.now().date(),
        joined_at__lte=end_date
    )

    if group:
        student_groups = student_groups.filter(group=group)

    total_students = student_groups.count()

    # HISOBOTLAR

    # 1. KELGAN TALABALAR (eng kam 1 marta present)
    came_once = 0
    not_came = 0
    not_marked = 0

    for sg in student_groups:
        # Shu vaqt oralig'idagi davomatlar
        attendances = sg.A_Sgroup.filter(
            lesson_date__range=[start_date, end_date]
        )

        # Agar hech davomat yo'q
        if not attendances.exists():
            not_marked += 1
        else:
            # Agar hech bo'lmaganda 1 marta present
            if attendances.filter(is_present=True).exists():
                came_once += 1
            else:
                # Davomat bor lekin hech qachon kelmagan
                not_came += 1

    # Natija
    report_data = {
        'indicator_name': 'Davomat hisoboti',
        'description': f'{start_date} dan {end_date} gacha davomat statistikasi',
        'came_once': came_once,
        'not_came': not_came,
        'not_marked': not_marked,
        'total': total_students
    }

    return Response({
        'success': True,
        'filters': {
            'start_date': start_date,
            'end_date': end_date,
            'group_id': group_id,
            'group_name': group.name if group else 'Barcha guruhlar'
        },
        'data': report_data,
        'breakdown': {
            'came_once_percent': round((came_once / total_students * 100) if total_students > 0 else 0, 2),
            'not_came_percent': round((not_came / total_students * 100) if total_students > 0 else 0, 2),
            'not_marked_percent': round((not_marked / total_students * 100) if total_students > 0 else 0, 2)
        }
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def detailed_attendance_report(request):
    """
    Batafsil davomat hisoboti (har bir talaba uchun)

    POST /api/reports/attendance/detailed/

    Response:
    {
        "success": true,
        "students": [
            {
                "student_id": 1,
                "student_name": "Jasur Aliyev",
                "group_name": "Python",
                "total_lessons": 20,
                "attended": 18,
                "missed": 2,
                "not_marked": 0,
                "attendance_rate": 90.0
            }
        ]
    }
    """

    start_date = request.data.get('start_date')
    end_date = request.data.get('end_date')
    group_id = request.data.get('group_id')

    # Validatsiya
    if not start_date or not end_date:
        return Response({
            'success': False,
            'message': 'start_date va end_date majburiy.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Guruh
    group = None
    if group_id:
        try:
            group = Group.objects.get(pk=group_id)
        except Group.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Guruh topilmadi.'
            }, status=status.HTTP_404_NOT_FOUND)

    # Faol talabalar
    student_groups = StudentGroup.objects.filter(
        left_at__gte=timezone.now().date(),
        joined_at__lte=end_date
    )

    if group:
        student_groups = student_groups.filter(group=group)

    # Har bir talaba uchun hisobot
    students_data = []

    for sg in student_groups:
        attendances = sg.A_Sgroup.filter(
            lesson_date__range=[start_date, end_date]
        )

        attended = attendances.filter(is_present=True).count()
        missed = attendances.filter(is_present=False).count()
        total_marked = attendances.count()

        # Umumiy darslar soni (guruh jadvaliga qarab)
        # Sodda variant: marked + not marked
        # Murakkab variant: LessonSchedule dan hisoblash

        attendance_rate = (attended / total_marked * 100) if total_marked > 0 else 0

        students_data.append({
            'student_id': sg.student.id,
            'student_name': sg.student.full_name,
            'group_name': sg.group.name,
            'total_lessons': total_marked,
            'attended': attended,
            'missed': missed,
            'not_marked': 0,  # Hozircha 0
            'attendance_rate': round(attendance_rate, 2)
        })

    return Response({
        'success': True,
        'filters': {
            'start_date': start_date,
            'end_date': end_date,
            'group_name': group.name if group else 'Barcha guruhlar'
        },
        'count': len(students_data),
        'students': students_data
    })