from rest_framework import viewsets

from drf_spectacular.utils import extend_schema
from rest_framework import status
from audit.models import AuditLog
from rest_framework import viewsets, filters
from drf_spectacular.utils import extend_schema
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db.models import Q, Count
from django.core.exceptions import ValidationError
from rest_framework import viewsets
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema

from .models import Group, GroupTeacher, Course, Room
from .serializers import (
    GroupListSerializer,
    GroupDetailSerializer,
    GroupCreateUpdateSerializer,
    GroupTeacherSerializer,
    CourseSerializer,
    RoomSerializer
)
from .models import (
    Student, StudentGroup, StudentPricing, StudentBalances,
    StudentTarnsactions, LeaveReason, StudentGroupLeaves,
    StudentFreezes, StudentBalanceHistory, Attendence,
    Room, Course, Group, GroupTeacher,
    LessonTime, LessonSchedule, Exams, ExamResults,
    TeacherSalaryRules, TeacherSalaryPayments, TeacherSalaryCalculations
)
from .serializers import (
    StudentSerializer, StudentGroupSerializer, StudentPricingSerializer,
    StudentBalancesSerializer, StudentTarnsactionsSerializer, LeaveReasonSerializer,
    StudentGroupLeavesSerializer, StudentFreezesSerializer, StudentBalanceHistorySerializer,
    AttendenceSerializer, RoomSerializer, CourseSerializer, GroupSerializer,
    GroupTeacherSerializer, LessonTimeSerializer, LessonScheduleSerializer,
    ExamsSerializer, ExamResultsSerializer,
    TeacherSalaryRulesSerializer, TeacherSalaryPaymentsSerializer, TeacherSalaryCalculationsSerializer
)


# ==================== STUDENT VIEWSETS ====================
@extend_schema(tags=["Students - Studentlar "])
class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

@extend_schema(tags=["StudentGroup - Student va Guruh bog'langan jadval "])
class StudentGroupViewSet(viewsets.ModelViewSet):
    queryset = StudentGroup.objects.all()
    serializer_class = StudentGroupSerializer

@extend_schema(tags=["StudentPricing - Studentga narx belgilash "])
class StudentPricingViewSet(viewsets.ModelViewSet):
    queryset = StudentPricing.objects.all()
    serializer_class = StudentPricingSerializer

@extend_schema(tags=["StudentBalances - Studentning balansini ko'rish"])
class StudentBalancesViewSet(viewsets.ModelViewSet):
    queryset = StudentBalances.objects.all()
    serializer_class = StudentBalancesSerializer

@extend_schema(tags=["StudentTarnsactions - Student to'lovlarni tarixi"])
class StudentTarnsactionsViewSet(viewsets.ModelViewSet):
    queryset = StudentTarnsactions.objects.all()
    serializer_class = StudentTarnsactionsSerializer

@extend_schema(tags=["LeaveReason - Studentlarning chiqib ketish sabablari"])
class LeaveReasonViewSet(viewsets.ModelViewSet):
    queryset = LeaveReason.objects.all()
    serializer_class = LeaveReasonSerializer

@extend_schema(tags=["StudentGroupLeaves - Studentni guruhdan chiqib ketish "])
class StudentGroupLeavesViewSet(viewsets.ModelViewSet):
    queryset = StudentGroupLeaves.objects.all()
    serializer_class = StudentGroupLeavesSerializer

@extend_schema(tags=["StudentFreezes - Studentdarsni muzlatish"])
class StudentFreezesViewSet(viewsets.ModelViewSet):
    queryset = StudentFreezes.objects.all()
    serializer_class = StudentFreezesSerializer

@extend_schema(tags=["StudentBalanceHistory - Student balansi tarixi"])
class StudentBalanceHistoryViewSet(viewsets.ModelViewSet):
    queryset = StudentBalanceHistory.objects.all()
    serializer_class = StudentBalanceHistorySerializer

@extend_schema(tags=["Attendence - Yo'qlama"])
class AttendenceViewSet(viewsets.ModelViewSet):
    queryset = Attendence.objects.all()
    serializer_class = AttendenceSerializer


# ==================== GROUP VIEWSETS ====================
@extend_schema(tags=["Room - Xona"])
class RoomViewSet(viewsets.ModelViewSet):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer

@extend_schema(tags=["Course - Kurslar"])
class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

@extend_schema(tags=["Group - Guruh "])
class GroupViewSet(viewsets.ModelViewSet):
    queryset = Group.objects.all()
    serializer_class = GroupSerializer

@extend_schema(tags=["GroupTeacher - Guruhlarni o'qituvchilarga bog'lash "])
class GroupTeacherViewSet(viewsets.ModelViewSet):
    queryset = GroupTeacher.objects.all()
    serializer_class = GroupTeacherSerializer


# ==================== LESSON VIEWSETS ====================
@extend_schema(tags=["LessonTime - Dars vaqtlari"])
class LessonTimeViewSet(viewsets.ModelViewSet):
    serializer_class = LessonTimeSerializer

    def get_queryset(self):
        qs = LessonTime.objects.all()

        name = self.request.query_params.get("name")
        code = self.request.query_params.get("code")

        if name:
            qs = qs.filter(name__icontains=name)

        if code:
            qs = qs.filter(code__icontains=code)

        return qs

    def list(self, request, *args, **kwargs):
        qs = self.get_queryset()
        serializer = self.get_serializer(qs, many=True)
        return Response({
            "count": qs.count(),
            "results": serializer.data
        })

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

@extend_schema(tags=["LessonSchedule - Dars jadvali ro'yxati "])
class LessonScheduleViewSet(viewsets.ModelViewSet):
    queryset = LessonSchedule.objects.all()
    serializer_class = LessonScheduleSerializer

@extend_schema(tags=["ExamsView - Imtihonlar jadvlai "])
class ExamsViewSet(viewsets.ModelViewSet):
    queryset = Exams.objects.all()
    serializer_class = ExamsSerializer

@extend_schema(tags=["ExamResults - Imtihonlar natijalari "])
class ExamResultsViewSet(viewsets.ModelViewSet):
    queryset = ExamResults.objects.all()
    serializer_class = ExamResultsSerializer



# ==================== TEACHER VIEWSETS ====================
@extend_schema(tags=["TeacherSalaryRules - O'qituvchi oylik qoidalari "])
class TeacherSalaryRulesViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryRules.objects.all()
    serializer_class = TeacherSalaryRulesSerializer

@extend_schema(tags=["TeacherSalaryPayments - O'qituvchilarga oylik berish"])
class TeacherSalaryPaymentsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryPayments.objects.all()
    serializer_class = TeacherSalaryPaymentsSerializer

@extend_schema(tags=["TeacherSalaryCalculations - O'qituvchi oyliklarini hisoblash "])
class TeacherSalaryCalculationsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryCalculations.objects.all()
    serializer_class = TeacherSalaryCalculationsSerializer





# ==================== GROUP VIEWS ====================

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def group_list_create(request):
    """
    GET: Barcha guruhlarni olish (filter bilan)
    POST: Yangi guruh yaratish
    """
    if request.method == 'GET':
        # Filterlar
        status_filter = request.query_params.get('status', None)
        course_id = request.query_params.get('course', None)
        room_id = request.query_params.get('room', None)
        search = request.query_params.get('search', None)

        # Barcha guruhlar
        groups = Group.objects.all().select_related('course', 'room')

        # Status filter
        if status_filter:
            groups = groups.filter(status=status_filter)

        # Course filter
        if course_id:
            groups = groups.filter(course_id=course_id)

        # Room filter
        if room_id:
            groups = groups.filter(room_id=room_id)

        # Search (guruh nomi bo'yicha)
        if search:
            groups = groups.filter(name__icontains=search)

        # Serializer
        serializer = GroupListSerializer(groups, many=True)

        return Response({
            'success': True,
            'count': groups.count(),
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        # Yangi guruh yaratish
        serializer = GroupCreateUpdateSerializer(data=request.data)

        if serializer.is_valid():
            try:
                group = serializer.save()

                return Response({
                    'success': True,
                    'message': 'Guruh muvaffaqiyatli yaratildi.',
                    'data': serializer.data
                }, status=status.HTTP_201_CREATED)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def group_detail_update_delete(request, pk):
    """
    GET: Bitta guruhni olish
    PUT/PATCH: Guruhni yangilash
    DELETE: Guruhni o'chirish (arxivlash)
    """
    group = get_object_or_404(Group, pk=pk)

    if request.method == 'GET':
        # Guruh detallari
        serializer = GroupDetailSerializer(group)
        return Response({
            'success': True,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method in ['PUT', 'PATCH']:
        # Guruhni yangilash
        partial = request.method == 'PATCH'
        serializer = GroupCreateUpdateSerializer(group, data=request.data, partial=partial)

        if serializer.is_valid():
            try:
                group = serializer.save()

                return Response({
                    'success': True,
                    'message': 'Guruh muvaffaqiyatli yangilandi.',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        # Guruhni arxivlash (soft delete)
        group.status = 'archived'
        group.save()

        return Response({
            'success': True,
            'message': 'Guruh arxivlandi.'
        }, status=status.HTTP_200_OK)


# ==================== GROUP TEACHER VIEWS ====================

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def group_teacher_list_create(request, group_pk):
    """
    GET: Guruh o'qituvchilarini olish
    POST: Guruhga o'qituvchi qo'shish
    """
    group = get_object_or_404(Group, pk=group_pk)

    if request.method == 'GET':
        # Guruh o'qituvchilari
        teachers = group.group.all().select_related('teacher', 'group')
        serializer = GroupTeacherSerializer(teachers, many=True)

        return Response({
            'success': True,
            'count': teachers.count(),
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        # O'qituvchi qo'shish
        data = request.data.copy()
        data['group'] = group.pk

        serializer = GroupTeacherSerializer(data=data)

        if serializer.is_valid():
            try:
                serializer.save()

                return Response({
                    'success': True,
                    'message': 'O\'qituvchi muvaffaqiyatli qo\'shildi.',
                    'data': serializer.data
                }, status=status.HTTP_201_CREATED)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def group_teacher_detail_update_delete(request, group_pk, pk):
    """
    GET: Bitta guruh-o'qituvchi ma'lumotini olish
    PUT/PATCH: Guruh-o'qituvchi ma'lumotini yangilash
    DELETE: Guruhdan o'qituvchini o'chirish
    """
    group = get_object_or_404(Group, pk=group_pk)
    group_teacher = get_object_or_404(GroupTeacher, pk=pk, group=group)

    if request.method == 'GET':
        serializer = GroupTeacherSerializer(group_teacher)
        return Response({
            'success': True,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method in ['PUT', 'PATCH']:
        partial = request.method == 'PATCH'
        serializer = GroupTeacherSerializer(group_teacher, data=request.data, partial=partial)

        if serializer.is_valid():
            try:
                serializer.save()

                return Response({
                    'success': True,
                    'message': 'Ma\'lumot muvaffaqiyatli yangilandi.',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Malumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        # O'qituvchini guruhdan o'chirish
        # Kamida bitta o'qituvchi qolishi kerak
        if group.group.count() <= 1:
            return Response({
                'success': False,
                'message': 'Guruhda kamida bitta o\'qituvchi bo\'lishi kerak.'
            }, status=status.HTTP_400_BAD_REQUEST)

        group_teacher.delete()

        return Response({
            'success': True,
            'message': 'O\'qituvchi guruhdan o\'chirildi.'
        }, status=status.HTTP_200_OK)


# ==================== HELPER VIEWS ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def course_list(request):
    """Barcha kurslarni olish (dropdown uchun)"""
    courses = Course.objects.all()
    serializer = CourseSerializer(courses, many=True)

    return Response({
        'success': True,
        'count': courses.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def room_list(request):
    """Barcha xonalarni olish (dropdown uchun)"""
    rooms = Room.objects.all()
    serializer = RoomSerializer(rooms, many=True)

    return Response({
        'success': True,
        'count': rooms.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def available_rooms(request):
    """
    Bo'sh xonalarni olish
    Query params: lesson, start_date, end_date
    """
    lesson_id = request.query_params.get('lesson')
    start_date = request.query_params.get('start_date')
    end_date = request.query_params.get('end_date')

    if not all([lesson_id, start_date, end_date]):
        return Response({
            'success': False,
            'message': 'lesson, start_date va end_date parametrlari majburiy.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Band xonalarni topish
    occupied_rooms = Group.objects.filter(
        course__lesson_id=lesson_id,
        status='active'
    ).filter(
        Q(start_date__lte=end_date) &
        Q(end_date__gte=start_date)
    ).values_list('room_id', flat=True)

    # Bo'sh xonalar
    available = Room.objects.exclude(id__in=occupied_rooms)
    serializer = RoomSerializer(available, many=True)

    return Response({
        'success': True,
        'count': available.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_statistics(request):
    """Guruhlar statistikasi"""
    total_groups = Group.objects.count()
    active_groups = Group.objects.filter(status='active').count()
    expired_groups = Group.objects.filter(status='expried').count()
    archived_groups = Group.objects.filter(status='archived').count()

    return Response({
        'success': True,
        'data': {
            'total': total_groups,
            'active': active_groups,
            'expired': expired_groups,
            'archived': archived_groups
        }
    }, status=status.HTTP_200_OK)


from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.utils import timezone

from .models import Group, StudentGroup, Student, Attendence, StudentPricing, Exams, ExamResults
from .serializers import (
    GroupFullInfoSerializer, AttendanceSerializer, StudentListSerializer,
    AddStudentSerializer, SMSSerializer, DiscountSerializer,
    ExamSerializer, ExamResultSerializer
)


# 1. GURUH MA'LUMOTLARI
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_full_info(request, pk):
    group = get_object_or_404(Group, pk=pk)
    serializer = GroupFullInfoSerializer(group)
    return Response({'success': True, 'data': serializer.data})


# 2. DAVOMAT
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def attendance_list_create(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)

    if request.method == 'GET':
        date = request.query_params.get('date')
        attendances = Attendence.objects.filter(student_group__group=group)
        if date:
            attendances = attendances.filter(lesson_date=date)
        serializer = AttendanceSerializer(attendances, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = AttendanceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(marked_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 3. O'QUVCHILAR RO'YXATI
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def students_list(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    status_filter = request.query_params.get('status')
    search = request.query_params.get('search')

    students = StudentGroup.objects.filter(group=group)

    if status_filter == 'active':
        students = students.filter(left_at__gte=timezone.now().date())
    elif status_filter == 'left':
        students = students.filter(left_at__lt=timezone.now().date())

    if search:
        students = students.filter(student__full_name__icontains=search)

    serializer = StudentListSerializer(students, many=True)
    return Response({'success': True, 'data': serializer.data})


# 5. GURUHGA ODAM QO'SHISH
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_student(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    data = request.data.copy()
    data['group'] = group.pk

    serializer = AddStudentSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
    return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def remove_student(request, group_pk, student_group_pk):
    sg = get_object_or_404(StudentGroup, pk=student_group_pk, group_id=group_pk)
    sg.left_at = timezone.now().date()
    sg.save()
    return Response({'success': True, 'message': 'Talaba o\'chirildi'})


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def send_sms(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    serializer = SMSSerializer(data=request.data)

    if serializer.is_valid():
        message = serializer.validated_data['message']
        send_to = serializer.validated_data['send_to']

        phones = []
        students = StudentGroup.objects.filter(group=group, left_at__gte=timezone.now().date())

        for sg in students:
            if send_to in ['all', 'students']:
                phones.append(sg.student.phone_number)
            if send_to in ['all', 'parents'] and sg.student.parent_phone:
                phones.append(sg.student.parent_phone)

        # TODO: SMS provider integration
        return Response({'success': True, 'message': f'{len(phones)} ta SMS yuborildi'})

    return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 6. CHEGIRMALAR
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def discount_list_create(request):
    if request.method == 'GET':
        student_id = request.query_params.get('student')
        discounts = StudentPricing.objects.all()
        if student_id:
            discounts = discounts.filter(student_id=student_id)
        serializer = DiscountSerializer(discounts, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = DiscountSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def discount_detail(request, pk):
    discount = get_object_or_404(StudentPricing, pk=pk)

    if request.method == 'GET':
        serializer = DiscountSerializer(discount)
        return Response({'success': True, 'data': serializer.data})

    elif request.method == 'PUT':
        serializer = DiscountSerializer(discount, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'data': serializer.data})
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    else:  # DELETE
        # FOREIGN KEY CHEKLOVI: StudentGroup mavjudligini tekshirish
        related_student_groups = StudentGroup.objects.filter(
            student=discount.student,
            group__course=discount.course,
            left_at__gte=timezone.now().date()
        )

        if related_student_groups.exists():
            return Response({
                'success': False,
                'message': f'Bu chegirmani o\'chirish mumkin emas. {related_student_groups.count()} ta faol guruhda ishlatilmoqda.'
            }, status=status.HTTP_400_BAD_REQUEST)

        discount.delete()
        return Response({'success': True, 'message': 'Chegirma o\'chirildi'})


# 7. IMTIHONLAR
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def exam_list_create(request):
    if request.method == 'GET':
        group_id = request.query_params.get('group')
        exams = Exams.objects.all()
        if group_id:
            exams = exams.filter(group_id=group_id)
        serializer = ExamSerializer(exams, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = ExamSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def exam_detail(request, pk):
    exam = get_object_or_404(Exams, pk=pk)

    if request.method == 'GET':
        serializer = ExamSerializer(exam)
        return Response({'success': True, 'data': serializer.data})

    elif request.method == 'PUT':
        serializer = ExamSerializer(exam, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'data': serializer.data})
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    else:  # DELETE
        # FOREIGN KEY CHEKLOVI: ExamResults mavjudligini tekshirish
        results_count = ExamResults.objects.filter(exam=exam).count()

        if results_count > 0:
            return Response({
                'success': False,
                'message': f'Bu imtihonni o\'chirish mumkin emas. {results_count} ta natija mavjud. Avval natijalarni o\'chiring.'
            }, status=status.HTTP_400_BAD_REQUEST)

        exam.delete()
        return Response({'success': True, 'message': 'Imtihon o\'chirildi'})


@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def exam_results(request, exam_pk):
    exam = get_object_or_404(Exams, pk=exam_pk)

    if request.method == 'GET':
        results = ExamResults.objects.filter(exam=exam)
        serializer = ExamResultSerializer(results, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        data = request.data.copy()
        data['exam'] = exam.pk
        serializer = ExamResultSerializer(data=data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 8. TARIX (AUDIT LOG)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_history(request, group_pk):

    group = get_object_or_404(Group, pk=group_pk)

    logs = AuditLog.objects.filter(
        entity_type='group',
        entity_id=group.id
    ).order_by('-created_at')

    # 🔹 action bo‘yicha filter
    action = request.query_params.get('action')
    if action:
        logs = logs.filter(action=action)

    # 🔹 bitta sana bo‘yicha filter
    date = request.query_params.get('date')
    if date:
        parsed_date = parse_date(date)
        if parsed_date:
            logs = logs.filter(created_at__date=parsed_date)

    # 🔹 sana oralig‘i bo‘yicha filter
    date_from = request.query_params.get('from')
    date_to = request.query_params.get('to')

    if date_from:
        logs = logs.filter(created_at__date__gte=date_from)

    if date_to:
        logs = logs.filter(created_at__date__lte=date_to)

    data = [{
        'id': str(log.id),
        'action': log.action,
        'old_data': log.old_data,
        'new_data': log.new_action,
        'performed_by': (
            f"{log.performed_by.user.first_name} {log.performed_by.user.last_name}"
            if log.performed_by and log.performed_by.user else None
        ),
        'created_at': log.created_at
    } for log in logs]

    return Response(data)


# ==================== 1. O'QUVCHINI QIDIRISH ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_search(request):
    """
    O'quvchini ismi yoki telefon raqami bo'yicha qidirish

    GET /api/students/search/?q=ismi_yoki_raqami

    Query params:
    - q: qidiruv so'zi (ism yoki telefon raqam)

    Response:
    {
        "success": true,
        "count": 5,
        "data": [
            {
                "id": 1,
                "full_name": "Jasur Aliyev",
                "phone_number": "+998901234567",
                "balance": 500000,
                "groups_count": 2
            }
        ]
    }
    """
    query = request.query_params.get('q', '').strip()

    if not query:
        return Response({
            'success': False,
            'message': 'Qidiruv so\'zi kiritilmagan. q parametrini kiriting.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Qidiruv: ism yoki telefon raqam bo'yicha
    students = Student.objects.filter(
        Q(full_name__icontains=query) |
        Q(phone_number__icontains=query) |
        Q(phone_number2__icontains=query)
    ).distinct()[:20]  # Faqat 20 ta natija

    serializer = StudentSearchSerializer(students, many=True)

    return Response({
        'success': True,
        'count': students.count(),
        'query': query,
        'data': serializer.data
    }, status=status.HTTP_200_OK)


# ==================== 2. GURUHGA TALABA QO'SHISH (YANGILANGAN) ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_student_to_group(request, group_pk):
    """
    Guruhga talaba qo'shish

    POST /api/groups/<group_id>/add-student/

    Body:
    {
        "student": 1,
        "joined_at": "2025-02-01",
        "left_at": "2025-08-01",
        "end_date": "2025-08-01"
    }

    Response:
    {
        "success": true,
        "message": "Talaba guruhga qo'shildi",
        "data": {...}
    }
    """
    from .models import Group

    group = get_object_or_404(Group, pk=group_pk)

    data = request.data.copy()
    data['group'] = group.pk

    serializer = AddStudentToGroupSerializer(data=data)

    if serializer.is_valid():
        student_group = serializer.save()

        return Response({
            'success': True,
            'message': 'Talaba muvaffaqiyatli guruhga qo\'shildi.',
            'data': serializer.data
        }, status=status.HTTP_201_CREATED)

    return Response({
        'success': False,
        'message': 'Ma\'lumotlar noto\'g\'ri.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


# ==================== 3. TALABANI FAOLLASHTIRISH ====================

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def activate_student(request, student_pk):
    """
    Talabani faollashtirish - balansga pul qo'shish

    PUT /api/students/<student_id>/activate/

    Body:
    {
        "amount": 500000,
        "payment_type": "cash",
        "comment": "Birinchi to'lov"
    }

    Response:
    {
        "success": true,
        "message": "Talaba muvaffaqiyatli faollashtirildi",
        "data": {
            "student_id": 1,
            "student_name": "Jasur Aliyev",
            "old_balance": 0,
            "added_amount": 500000,
            "new_balance": 500000,
            "status": "active"
        }
    }
    """
    student = get_object_or_404(Student, pk=student_pk)

    serializer = ActivateStudentSerializer(data=request.data)

    if serializer.is_valid():
        try:
            # Talabani faollashtirish
            result = serializer.activate_student(
                student=student,
                validated_data=serializer.validated_data,
                user=request.user.employee
            )

            return Response({
                'success': True,
                'message': 'Talaba muvaffaqiyatli faollashtirildi.',
                'data': result
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'success': False,
                'message': f'Xatolik yuz berdi: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response({
        'success': False,
        'message': 'Ma\'lumotlar noto\'g\'ri.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


# ==================== 4. TALABA BALANSI VA HOLATI ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_balance_status(request, student_pk):
    """
    Talaba balansi va holati

    GET /api/students/<student_id>/balance-status/

    Response:
    {
        "success": true,
        "data": {
            "student_id": 1,
            "full_name": "Jasur Aliyev",
            "balance": 500000,
            "status": "active",
            "active_groups": 2,
            "transactions_count": 5
        }
    }
    """
    from .models import StudentBalances, StudentTarnsactions
    from django.utils import timezone

    student = get_object_or_404(Student, pk=student_pk)

    # Balance
    try:
        student_balance = student.Sbalances_student.first()
        balance = float(student_balance.balance) if student_balance else 0.0
    except:
        balance = 0.0

    # Active groups count
    active_groups = student.Sgroup_student.filter(
        left_at__gte=timezone.now().date()
    ).count()

    # Transactions count
    transactions_count = student.Strans_student.count()

    # Status
    student_status = 'active' if balance > 0 else 'inactive'

    return Response({
        'success': True,
        'data': {
            'student_id': student.id,
            'full_name': student.full_name,
            'phone_number': student.phone_number,
            'balance': balance,
            'status': student_status,
            'active_groups': active_groups,
            'transactions_count': transactions_count
        }
    }, status=status.HTTP_200_OK)