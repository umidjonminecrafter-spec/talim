from rest_framework import serializers
from .models import (
    Student, StudentGroup, StudentPricing, StudentBalances,
    StudentTarnsactions, LeaveReason, StudentGroupLeaves,
    StudentFreezes, StudentBalanceHistory, Attendence,
    Room, Course, Group, GroupTeacher,
    LessonTime, LessonSchedule, Exams, ExamResults,
    TeacherSalaryRules, TeacherSalaryPayments, TeacherSalaryCalculations
)
from rest_framework import serializers
from django.db import transaction
from django.db.models import Q
from django.core.exceptions import ValidationError as DjangoValidationError
from .models import Group, Course, Room, GroupTeacher
from accounts.models import Employee


from rest_framework import serializers
from django.db import transaction
from django.utils import timezone
from datetime import timedelta

from .models import (
    Group, GroupTeacher, Course, Room, LessonSchedule,
    Student, StudentGroup, StudentPricing, Attendence, Exams, ExamResults
)


# ==================== STUDENT SERIALIZERS ====================
class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'


class StudentGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentGroup
        fields = '__all__'


class StudentPricingSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentPricing
        fields = '__all__'


class StudentBalancesSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentBalances
        fields = '__all__'


class StudentTarnsactionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentTarnsactions
        fields = '__all__'


class LeaveReasonSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeaveReason
        fields = '__all__'


class StudentGroupLeavesSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentGroupLeaves
        fields = '__all__'


class StudentFreezesSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentFreezes
        fields = '__all__'


class StudentBalanceHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentBalanceHistory
        fields = '__all__'


class AttendenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Attendence
        fields = '__all__'


# ==================== GROUP SERIALIZERS ====================





class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = '__all__'





# ==================== LESSON SERIALIZERS ====================
class LessonTimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonTime
        fields = '__all__'


class LessonScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonSchedule
        fields = '__all__'


class ExamsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Exams
        fields = '__all__'


class ExamResultsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExamResults
        fields = '__all__'




# ==================== TEACHER SERIALIZERS ====================
class TeacherSalaryRulesSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeacherSalaryRules
        fields = '__all__'


class TeacherSalaryPaymentsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeacherSalaryPayments
        fields = '__all__'


class TeacherSalaryCalculationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TeacherSalaryCalculations
        fields = '__all__'





class RoomSerializer(serializers.ModelSerializer):
    """Xona uchun serializer"""

    class Meta:
        model = Room
        fields = ['id', 'name', 'capacity', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


class CourseSerializer(serializers.ModelSerializer):
    """Kurs uchun serializer"""
    lesson_time = serializers.CharField(source='lesson.name', read_only=True)

    class Meta:
        model = Course
        fields = [
            'id', 'name', 'code', 'monthly_price',
            'lesson', 'lesson_time', 'lesson_month',
            'comment', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class EmployeeSimpleSerializer(serializers.ModelSerializer):
    """O'qituvchi uchun sodda serializer"""
    full_name = serializers.SerializerMethodField()

    class Meta:
        model = Employee
        fields = ['id', 'full_name', 'email']

    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}" if hasattr(obj, 'first_name') else str(obj)


class GroupTeacherSerializer(serializers.ModelSerializer):
    """Guruh o'qituvchisi uchun serializer"""
    teacher_info = EmployeeSimpleSerializer(source='teacher', read_only=True)
    group_name = serializers.CharField(source='group.name', read_only=True)

    class Meta:
        model = GroupTeacher
        fields = [
            'id', 'group', 'group_name', 'teacher', 'teacher_info',
            'start_date', 'end_date', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        """Validatsiyalar"""
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        group = attrs.get('group')
        teacher = attrs.get('teacher')

        # 1. Start date end date dan kichik bo'lishi kerak
        if start_date and end_date:
            if start_date >= end_date:
                raise serializers.ValidationError({
                    'end_date': 'Tugash sanasi boshlanish sanasidan katta bo\'lishi kerak.'
                })

        # 2. O'qituvchi vaqti guruh davri ichida bo'lishi kerak
        if group and start_date and end_date:
            if start_date < group.start_date:
                raise serializers.ValidationError({
                    'start_date': f'O\'qituvchi boshlanish sanasi guruh boshlanish sanasidan ({group.start_date}) oldin bo\'lmasligi kerak.'
                })
            if end_date > group.end_date:
                raise serializers.ValidationError({
                    'end_date': f'O\'qituvchi tugash sanasi guruh tugash sanasidan ({group.end_date}) keyin bo\'lmasligi kerak.'
                })

        # 3. Bir o'qituvchi bir vaqtda ikki guruhda bo'lmasligi kerak (bir xil dars vaqtida)
        if teacher and start_date and end_date and group and group.course and group.course.lesson:
            conflicting = GroupTeacher.objects.filter(
                teacher=teacher,
                group__course__lesson=group.course.lesson,
                group__status='active'
            ).filter(
                Q(start_date__lte=end_date) &
                Q(end_date__gte=start_date)
            )

            # Update qilayotgan bo'lsa, o'zini exclude qilish
            if self.instance:
                conflicting = conflicting.exclude(pk=self.instance.pk)

            if conflicting.exists():
                conflict = conflicting.first()
                raise serializers.ValidationError({
                    'teacher': f'Bu o\'qituvchi shu vaqtda ({group.course.lesson}) boshqa guruhda ({conflict.group.name}) dars beradi.'
                })

        return attrs


class GroupListSerializer(serializers.ModelSerializer):
    """Guruhlar ro'yxati uchun serializer (minimal ma'lumot)"""
    course_name = serializers.CharField(source='course.name', read_only=True)
    room_name = serializers.CharField(source='room.name', read_only=True)
    teacher_count = serializers.SerializerMethodField()

    class Meta:
        model = Group
        fields = [
            'id', 'name', 'course', 'course_name',
            'status', 'room', 'room_name',
            'start_date', 'end_date',
            'teacher_count', 'created_at'
        ]

    def get_teacher_count(self, obj):
        """O'qituvchilar sonini olish"""
        return obj.group.count()


class GroupDetailSerializer(serializers.ModelSerializer):
    """Guruh detallari uchun serializer (to'liq ma'lumot)"""
    course_info = CourseSerializer(source='course', read_only=True)
    room_info = RoomSerializer(source='room', read_only=True)
    teachers = GroupTeacherSerializer(source='group', many=True, read_only=True)

    class Meta:
        model = Group
        fields = [
            'id', 'name', 'course', 'course_info',
            'status', 'room', 'room_info',
            'start_date', 'end_date',
            'teachers', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class GroupCreateUpdateSerializer(serializers.ModelSerializer):
    """Guruh yaratish va yangilash uchun serializer"""
    teacher_ids = serializers.ListField(
        child=serializers.IntegerField(),
        write_only=True,
        required=False,
        help_text="O'qituvchilar ID ro'yxati"
    )

    class Meta:
        model = Group
        fields = [
            'id', 'name', 'course', 'status', 'room',
            'start_date', 'end_date', 'teacher_ids'
        ]
        read_only_fields = ['id']

    def validate(self, attrs):
        """Validatsiyalar"""
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        room = attrs.get('room')
        course = attrs.get('course')

        # Update uchun eski qiymatlarni olish
        if self.instance:
            start_date = start_date or self.instance.start_date
            end_date = end_date or self.instance.end_date
            room = room or self.instance.room
            course = course or self.instance.course

        # 1. Start date end date dan kichik bo'lishi kerak
        if start_date and end_date:
            if start_date >= end_date:
                raise serializers.ValidationError({
                    'end_date': 'Tugash sanasi boshlanish sanasidan katta bo\'lishi kerak.'
                })

        # 2. Bir vaqtning o'zida bir xonada faqat bitta guruh bo'lishi mumkin
        if room and start_date and end_date and course and course.lesson:
            overlapping = Group.objects.filter(
                room=room,
                course__lesson=course.lesson,
                status='active'
            ).filter(
                Q(start_date__lte=end_date) &
                Q(end_date__gte=start_date)
            )

            # Update uchun o'zini exclude qilish
            if self.instance:
                overlapping = overlapping.exclude(pk=self.instance.pk)

            if overlapping.exists():
                conflict = overlapping.first()
                raise serializers.ValidationError({
                    'room': f'Bu xonada ({room.name}) shu vaqtda ({course.lesson}) boshqa guruh ({conflict.name}) bor. Boshqa xona yoki vaqt tanlang.'
                })

        # 3. Guruhga o'qituvchi biriktirilishi kerak (faqat create uchun)
        if not self.instance:  # Yangi guruh yaratilayotgan bo'lsa
            teacher_ids = self.initial_data.get('teacher_ids', [])
            if not teacher_ids:
                raise serializers.ValidationError({
                    'teacher_ids': 'Guruhga kamida bitta o\'qituvchi biriktirilishi kerak.'
                })

        return attrs

    @transaction.atomic
    def create(self, validated_data):
        """Guruh yaratish va o'qituvchilarni biriktirish"""
        teacher_ids = validated_data.pop('teacher_ids', [])

        # Guruhni yaratish
        group = Group.objects.create(**validated_data)

        # O'qituvchilarni biriktirish
        if teacher_ids:
            self._assign_teachers(group, teacher_ids, validated_data['start_date'], validated_data['end_date'])

        return group

    @transaction.atomic
    def update(self, instance, validated_data):
        """Guruhni yangilash"""
        teacher_ids = validated_data.pop('teacher_ids', None)

        # Guruhni yangilash
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # O'qituvchilarni yangilash (agar berilgan bo'lsa)
        if teacher_ids is not None:
            # Eski o'qituvchilarni o'chirish
            instance.group.all().delete()
            # Yangi o'qituvchilarni qo'shish
            self._assign_teachers(instance, teacher_ids, instance.start_date, instance.end_date)

        return instance

    def _assign_teachers(self, group, teacher_ids, start_date, end_date):
        """O'qituvchilarni guruhga biriktirish"""
        teachers = Employee.objects.filter(id__in=teacher_ids)

        if len(teachers) != len(teacher_ids):
            raise serializers.ValidationError({
                'teacher_ids': 'Ba\'zi o\'qituvchilar topilmadi.'
            })

        for teacher in teachers:
            # Har bir o'qituvchi uchun validatsiya
            group_teacher_data = {
                'group': group,
                'teacher': teacher,
                'start_date': start_date,
                'end_date': end_date
            }

            group_teacher_serializer = GroupTeacherSerializer(data=group_teacher_data)
            group_teacher_serializer.is_valid(raise_exception=True)
            group_teacher_serializer.save()

    def to_representation(self, instance):
        """Response uchun detali serializer ishlatish"""
        return GroupDetailSerializer(instance, context=self.context).data





# ============ 1. GURUH TO'LIQ MA'LUMOTLARI ============

class GroupFullInfoSerializer(serializers.ModelSerializer):
    """Kurs nomi, O'qituvchi, Narx, Mashg'ulot sanalan, Xona va sig'imi"""
    course_name = serializers.CharField(source='course.name', read_only=True)
    monthly_price = serializers.DecimalField(source='course.monthly_price', max_digits=10, decimal_places=2,
                                             read_only=True)
    room_name = serializers.CharField(source='room.name', read_only=True)
    room_capacity = serializers.IntegerField(source='room.capacity', read_only=True)
    teachers = serializers.SerializerMethodField()
    schedule = serializers.SerializerMethodField()
    student_count = serializers.SerializerMethodField()

    class Meta:
        model = Group
        fields = [
            'id', 'name', 'status', 'start_date', 'end_date',
            'course_name', 'monthly_price', 'room_name', 'room_capacity',
            'teachers', 'schedule', 'student_count'
        ]

    def get_teachers(self, obj):
        teachers = obj.group.all()
        return [{
            'id': t.teacher.id,
            'name': f"{t.teacher.first_name} {t.teacher.last_name}"
        } for t in teachers]

    def get_schedule(self, obj):
        schedules = obj.lesson_group.all()
        return [{
            'day_type': s.day_type,
            'start_time': str(s.start_time),
            'end_time': str(s.end_time)
        } for s in schedules]

    def get_student_count(self, obj):
        return obj.Sgroup_group.filter(left_at__gte=timezone.now().date()).count()


# ============ 2. DAVOMAT ============

class AttendanceSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student_group.student.full_name', read_only=True)

    class Meta:
        model = Attendence
        fields = ['id', 'student_group', 'student_name', 'lesson_date', 'is_present', 'marked_by']
        read_only_fields = ['marked_by']

    def validate(self, attrs):
        lesson_date = attrs.get('lesson_date')
        today = timezone.now().date()

        # 3 kun chegarasi
        if not (today - timedelta(days=3) <= lesson_date <= today + timedelta(days=3)):
            raise serializers.ValidationError({
                'lesson_date': 'Davomat faqat 3 kun oldin va keyin qo\'yilishi mumkin.'
            })

        return attrs


# ============ 3. O'QUVCHILAR RO'YXATI ============

class StudentListSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    student_phone = serializers.CharField(source='student.phone_number', read_only=True)
    group_name = serializers.CharField(source='group.name', read_only=True)

    class Meta:
        model = StudentGroup
        fields = ['id', 'student', 'student_name', 'student_phone', 'group', 'group_name', 'joined_at', 'left_at']


# ============ 5. GURUHGA ODAM QO'SHISH =======


class SMSSerializer(serializers.Serializer):
    message = serializers.CharField(max_length=500)
    send_to = serializers.ChoiceField(choices=['all', 'students', 'parents'])


# ============ 6. CHEGIRMALAR ============

class DiscountSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    course_name = serializers.CharField(source='course.name', read_only=True)

    class Meta:
        model = StudentPricing
        fields = ['id', 'student', 'student_name', 'course', 'course_name', 'price_override', 'reason', 'start_date',
                  'end_date', 'created_by']
        read_only_fields = ['created_by']


# ============ 7. IMTIHONLAR ============

class ExamSerializer(serializers.ModelSerializer):
    group_name = serializers.CharField(source='group.name', read_only=True)

    class Meta:
        model = Exams
        fields = ['id', 'group', 'group_name', 'title', 'exam_date', 'min_score', 'max_score', 'description', 'file',
                  'created_by']
        read_only_fields = ['created_by']


class ExamResultSerializer(serializers.ModelSerializer):
    exam_title = serializers.CharField(source='exam.title', read_only=True)
    student_name = serializers.CharField(source='student.full_name', read_only=True)

    class Meta:
        model = ExamResults
        fields = ['id', 'exam', 'exam_title', 'student', 'student_name', 'score', 'comment', 'created_by']
        read_only_fields = ['created_by']


# ============ GURUHGA ODAM QO'SHISH - VALIDATSIYA BILAN ============

class AddStudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentGroup
        fields = ['student', 'group', 'joined_at', 'left_at', 'end_date']

    def validate(self, attrs):
        """Validatsiyalar"""
        student = attrs.get('student')
        group = attrs.get('group')

        # 1. Guruh active ekanligini tekshirish
        if group and group.status != 'active':
            raise serializers.ValidationError({
                'group': 'Faqat faol guruhlarga talaba qo\'shish mumkin.'
            })

        # 2. Talaba allaqachon guruhda emasligini tekshirish
        if student and group:
            existing = StudentGroup.objects.filter(
                student=student,
                group=group,
                left_at__gte=timezone.now().date()
            )

            if existing.exists():
                raise serializers.ValidationError({
                    'student': 'Bu talaba allaqachon guruhda.'
                })

        # 3. Xona sig'imi tekshiruvi
        if group and group.room:
            current_count = StudentGroup.objects.filter(
                group=group,
                left_at__gte=timezone.now().date()
            ).count()

            if current_count >= group.room.capacity:
                raise serializers.ValidationError({
                    'group': f'Guruh to\'lgan! Xona sig\'imi: {group.room.capacity}, hozir: {current_count} ta talaba.'
                })

        return attrs


# ============ YANGI VAZIFA: O'QUVCHI QIDIRISH VA FAOLLASHTIRISH ============

from rest_framework import serializers
from django.utils import timezone
from .models import Student, StudentGroup, StudentBalances


# 1. O'quvchini qidirish uchun serializer
class StudentSearchSerializer(serializers.ModelSerializer):
    """O'quvchini ismi yoki telefon raqami bo'yicha qidirish"""
    balance = serializers.SerializerMethodField()
    groups_count = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = [
            'id', 'full_name', 'photo', 'phone_number', 'phone_number2',
            'email', 'telegram_username', 'balance', 'groups_count'
        ]

    def get_balance(self, obj):
        """Talaba balansi"""
        try:
            student_balance = obj.Sbalances_student.first()
            return float(student_balance.balance) if student_balance else 0.0
        except:
            return 0.0

    def get_groups_count(self, obj):
        """Nechta guruhda"""
        return obj.Sgroup_student.filter(
            left_at__gte=timezone.now().date()
        ).count()


# 2. Guruhga qo'shish uchun serializer (yangilangan versiya)
class AddStudentToGroupSerializer(serializers.ModelSerializer):
    """Guruhga talaba qo'shish"""

    class Meta:
        model = StudentGroup
        fields = ['student', 'group', 'joined_at', 'left_at', 'end_date']

    def validate(self, attrs):
        """Validatsiyalar"""
        student = attrs.get('student')
        group = attrs.get('group')

        # 1. Guruh active ekanligini tekshirish
        if group and group.status != 'active':
            raise serializers.ValidationError({
                'group': 'Faqat faol guruhlarga talaba qo\'shish mumkin.'
            })

        # 2. Talaba allaqachon guruhda emasligini tekshirish
        if student and group:
            existing = StudentGroup.objects.filter(
                student=student,
                group=group,
                left_at__gte=timezone.now().date()
            )

            if existing.exists():
                raise serializers.ValidationError({
                    'student': 'Bu talaba allaqachon guruhda.'
                })

        # 3. Xona sig'imi tekshiruvi
        if group and group.room:
            current_count = StudentGroup.objects.filter(
                group=group,
                left_at__gte=timezone.now().date()
            ).count()

            if current_count >= group.room.capacity:
                raise serializers.ValidationError({
                    'group': f'Guruh to\'lgan! Xona sig\'imi: {group.room.capacity}, hozir: {current_count} ta talaba.'
                })

        return attrs


# 3. Talaba faollashtirish uchun serializer
class ActivateStudentSerializer(serializers.Serializer):
    """
    Talabani faollashtirish (balansga pul kiritilganda)
    Bu API StudentBalances ga pul qo'shadi va talabani faol qiladi
    """
    amount = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=0.01,
        help_text="Qo'shiladigan pul miqdori"
    )
    payment_type = serializers.ChoiceField(
        choices=[('cash', 'Naqd'), ('card', 'Karta'), ('transfer', 'O\'tkazma')],
        help_text="To'lov turi"
    )
    comment = serializers.CharField(
        max_length=500,
        required=False,
        allow_blank=True,
        help_text="Izoh"
    )

    def validate_amount(self, value):
        """Pul miqdori musbat bo'lishi kerak"""
        if value <= 0:
            raise serializers.ValidationError('Pul miqdori 0 dan katta bo\'lishi kerak.')
        return value

    def activate_student(self, student, validated_data, user):
        """
        Talabani faollashtirish:
        1. StudentBalances ga pul qo'shish
        2. StudentTransactions yaratish
        """
        from django.db import transaction
        from .models import StudentTarnsactions

        amount = validated_data['amount']
        payment_type = validated_data['payment_type']
        comment = validated_data.get('comment', 'Talaba faollashtirildi')

        with transaction.atomic():
            # 1. Balance yaratish yoki yangilash
            student_balance, created = StudentBalances.objects.get_or_create(
                student=student,
                defaults={'balance': 0}
            )

            # Balansni yangilash
            student_balance.balance += amount
            student_balance.save()

            # 2. Transaction yaratish
            StudentTarnsactions.objects.create(
                student=student,
                transaction_type='payment',
                amount=amount,
                payment_type=payment_type,
                transaction_date=timezone.now(),
                accepted_by=user,
                comment=comment
            )

            return {
                'student_id': student.id,
                'student_name': student.full_name,
                'old_balance': float(student_balance.balance - amount),
                'added_amount': float(amount),
                'new_balance': float(student_balance.balance),
                'status': 'active',
                'message': 'Talaba muvaffaqiyatli faollashtirildi'
            }