from django.urls import path

from .views import (
    StudentViewSet, StudentGroupViewSet, StudentPricingViewSet,
    StudentBalancesViewSet, StudentTarnsactionsViewSet, LeaveReasonViewSet,
    StudentGroupLeavesViewSet, StudentFreezesViewSet, StudentBalanceHistoryViewSet,
    AttendenceViewSet, RoomViewSet, CourseViewSet, GroupViewSet,
    GroupTeacherViewSet, LessonTimeViewSet, LessonScheduleViewSet,
    ExamsViewSet, ExamResultsViewSet,
    TeacherSalaryRulesViewSet, TeacherSalaryPaymentsViewSet, TeacherSalaryCalculationsViewSet
)
from . import views
urlpatterns = [
    # ==================== STUDENT URLs ====================
    path('students/', StudentViewSet.as_view({'get': 'list', 'post': 'create'}), name='student-list'),
    path('students/<int:pk>/',
         StudentViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='student-detail'),

    path('student-groups/', StudentGroupViewSet.as_view({'get': 'list', 'post': 'create'}), name='studentgroup-list'),
    path('student-groups/<int:pk>/', StudentGroupViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentgroup-detail'),

    path('student-pricings/', StudentPricingViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studentpricing-list'),
    path('student-pricings/<int:pk>/', StudentPricingViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentpricing-detail'),

    path('student-balances/', StudentBalancesViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studentbalances-list'),
    path('student-balances/<int:pk>/', StudentBalancesViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentbalances-detail'),

    path('student-transactions/', StudentTarnsactionsViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studenttransactions-list'),
    path('student-transactions/<int:pk>/', StudentTarnsactionsViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studenttransactions-detail'),

    path('leave-reasons/', LeaveReasonViewSet.as_view({'get': 'list', 'post': 'create'}), name='leavereason-list'),
    path('leave-reasons/<int:pk>/', LeaveReasonViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='leavereason-detail'),

    path('student-group-leaves/', StudentGroupLeavesViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studentgroupleaves-list'),
    path('student-group-leaves/<int:pk>/', StudentGroupLeavesViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentgroupleaves-detail'),

    path('student-freezes/', StudentFreezesViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studentfreezes-list'),
    path('student-freezes/<int:pk>/', StudentFreezesViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentfreezes-detail'),

    path('student-balance-history/', StudentBalanceHistoryViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='studentbalancehistory-list'),
    path('student-balance-history/<int:pk>/', StudentBalanceHistoryViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='studentbalancehistory-detail'),

    path('attendences/', AttendenceViewSet.as_view({'get': 'list', 'post': 'create'}), name='attendence-list'),
    path('attendences/<int:pk>/', AttendenceViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='attendence-detail'),

    # ==================== GROUP URLs ====================
    path('rooms/', RoomViewSet.as_view({'get': 'list', 'post': 'create'}), name='room-list'),
    path('rooms/<int:pk>/',
         RoomViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='room-detail'),

    path('courses/', CourseViewSet.as_view({'get': 'list', 'post': 'create'}), name='course-list'),
    path('courses/<int:pk>/',
         CourseViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='course-detail'),

    path('groups/', GroupViewSet.as_view({'get': 'list', 'post': 'create'}), name='group-list'),
    path('groups/<int:pk>/',
         GroupViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='group-detail'),

    path('group-teachers/', GroupTeacherViewSet.as_view({'get': 'list', 'post': 'create'}), name='groupteacher-list'),
    path('group-teachers/<int:pk>/', GroupTeacherViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='groupteacher-detail'),

    # ==================== GROUP URLS ====================

    # Guruhlar ro'yxati va yaratish
    # GET: /api/groups/ - Barcha guruhlarni olish (filter: status, course, room, search)
    # POST: /api/groups/ - Yangi guruh yaratish
    path('groups/', views.group_list_create, name='group-list-create'),

    # Bitta guruh: detail, update, delete
    # GET: /api/groups/<id>/ - Guruh detallari
    # PUT: /api/groups/<id>/ - Guruhni to'liq yangilash
    # PATCH: /api/groups/<id>/ - Guruhni qisman yangilash
    # DELETE: /api/groups/<id>/ - Guruhni arxivlash
    path('groups/<int:pk>/', views.group_detail_update_delete, name='group-detail'),

    # ==================== GROUP TEACHER URLS ====================

    # Guruh o'qituvchilari ro'yxati va qo'shish
    # GET: /api/groups/<group_id>/teachers/ - Guruh o'qituvchilarini olish
    # POST: /api/groups/<group_id>/teachers/ - Guruhga o'qituvchi qo'shish
    path('groups/<int:group_pk>/teachers/', views.group_teacher_list_create, name='group-teacher-list'),

    # Guruh o'qituvchisi: detail, update, delete
    # GET: /api/groups/<group_id>/teachers/<id>/ - O'qituvchi ma'lumotlari
    # PUT: /api/groups/<group_id>/teachers/<id>/ - O'qituvchi ma'lumotini to'liq yangilash
    # PATCH: /api/groups/<group_id>/teachers/<id>/ - O'qituvchi ma'lumotini qisman yangilash
    # DELETE: /api/groups/<group_id>/teachers/<id>/ - O'qituvchini guruhdan o'chirish
    path('groups/<int:group_pk>/teachers/<int:pk>/', views.group_teacher_detail_update_delete,
         name='group-teacher-detail'),

    # ==================== HELPER URLS ====================

    # Kurslar ro'yxati (dropdown uchun)
    # GET: /api/courses/ - Barcha kurslarni olish
    path('courses/', views.course_list, name='course-list'),

    # Xonalar ro'yxati (dropdown uchun)
    # GET: /api/rooms/ - Barcha xonalarni olish
    path('rooms/', views.room_list, name='room-list'),

    # Bo'sh xonalarni olish
    # GET: /api/rooms/available/?lesson=<id>&start_date=<date>&end_date=<date>
    path('rooms/available/', views.available_rooms, name='available-rooms'),

    # Guruhlar statistikasi
    # GET: /api/groups/statistics/ - Guruhlar statistikasi
    path('statistics/', views.group_statistics, name='group-statistics'),

    # ==================== LESSON URLs ====================
    path('lesson-times/', LessonTimeViewSet.as_view({'get': 'list', 'post': 'create'}), name='lessontime-list'),
    path('lesson-times/<int:pk>/', LessonTimeViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='lessontime-detail'),

    path('lesson-schedules/', LessonScheduleViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='lessonschedule-list'),
    path('lesson-schedules/<int:pk>/', LessonScheduleViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='lessonschedule-detail'),

    path('exams/', ExamsViewSet.as_view({'get': 'list', 'post': 'create'}), name='exams-list'),
    path('exams/<int:pk>/',
         ExamsViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='exams-detail'),

    path('exam-results/', ExamResultsViewSet.as_view({'get': 'list', 'post': 'create'}), name='examresults-list'),
    path('exam-results/<int:pk>/', ExamResultsViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='examresults-detail'),


    # ==================== TEACHER URLs ====================
    path('teacher-salary-rules/', TeacherSalaryRulesViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='teachersalaryrules-list'),
    path('teacher-salary-rules/<int:pk>/', TeacherSalaryRulesViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='teachersalaryrules-detail'),

    path('teacher-salary-payments/', TeacherSalaryPaymentsViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='teachersalarypayments-list'),
    path('teacher-salary-payments/<int:pk>/', TeacherSalaryPaymentsViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='teachersalarypayments-detail'),

    path('teacher-salary-calculations/', TeacherSalaryCalculationsViewSet.as_view({'get': 'list', 'post': 'create'}),
         name='teachersalarycalculations-list'),
    path('teacher-salary-calculations/<int:pk>/', TeacherSalaryCalculationsViewSet.as_view(
        {'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}),
         name='teachersalarycalculations-detail')    ,


    # 1. Guruh to'liq ma'lumotlari
    path('groups/<int:pk>/info/', views.group_full_info, name='group-info'),

    # 2. Davomat
    path('groups/<int:group_pk>/attendance/', views.attendance_list_create, name='attendance'),

    # 3. O'quvchilar ro'yxati
    path('groups/<int:group_pk>/students/', views.students_list, name='students-list'),

    # 5. Guruh operatsiyalari
    path('groups/<int:group_pk>/add-student/', views.add_student, name='add-student'),
    path('groups/<int:group_pk>/students/<int:student_group_pk>/', views.remove_student, name='remove-student'),
    path('groups/<int:group_pk>/send-sms/', views.send_sms, name='send-sms'),

    # 6. Chegirmalar
    path('discounts/', views.discount_list_create, name='discounts'),
    path('discounts/<int:pk>/', views.discount_detail, name='discount-detail'),

    # 7. Imtihonlar
    path('exams/', views.exam_list_create, name='exams'),
    path('exams/<int:pk>/', views.exam_detail, name='exam-detail'),
    path('exams/<int:exam_pk>/results/', views.exam_results, name='exam-results'),

    # 8. Tarix
    path('groups/<int:group_pk>/history/', views.group_history, name='group-history'),

    # ==================== YANGI: O'QUVCHI QIDIRISH VA FAOLLASHTIRISH ====================

    # 1. O'quvchini qidirish
    # GET /api/students/search/?q=ismi_yoki_raqami
    path('students/search/', views.student_search, name='student-search'),

    # 2. Guruhga talaba qo'shish (yangilangan)
    # POST /api/groups/<group_id>/add-student/
    # Bu URL allaqachon bor, faqat viewni almashtiring
    path('groups/<int:group_pk>/add-student/', views.add_student_to_group, name='add-student-to-group'),

    # 3. Talabani faollashtirish (balansga pul qo'shish)
    # PUT /api/students/<student_id>/activate/
    path('students/<int:student_pk>/activate/', views.activate_student, name='activate-student'),

    # 4. Talaba balansi va holati
    # GET /api/students/<student_id>/balance-status/
    path('students/<int:student_pk>/balance-status/', views.student_balance_status, name='student-balance-status'),
]

"""
============================================================
YANGI API ENDPOINTLAR SUMMARY
============================================================

1. O'QUVCHI QIDIRISH:
   GET  /api/students/search/?q=Jasur
   GET  /api/students/search/?q=998901234567

2. GURUHGA QO'SHISH:
   POST /api/groups/<group_id>/add-student/
   Body: {
       "student": 1,
       "joined_at": "2025-02-01",
       "left_at": "2025-08-01",
       "end_date": "2025-08-01"
   }

3. TALABANI FAOLLASHTIRISH:
   PUT  /api/students/<student_id>/activate/
   Body: {
       "amount": 500000,
       "payment_type": "cash",
       "comment": "Birinchi to'lov"
   }

4. TALABA HOLATI:
   # GET  /api/students/<student_id>/balance-status/
"""