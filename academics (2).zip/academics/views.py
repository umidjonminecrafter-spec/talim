from audit.models import AuditLog
from django.db.models import Q, Count
from django.core.exceptions import ValidationError
from rest_framework import viewsets
from drf_spectacular.utils import extend_schema
from .models import OnlineLesson, Group
from .serializers import (
    OnlineLessonListSerializer,
    OnlineLessonDetailSerializer,
    OnlineLessonCreateUpdateSerializer, AddStudentToGroupSerializer, ActivateStudentSerializer, StudentSearchSerializer,
    LessonScheduleDetailSerializer, LessonScheduleListSerializer, MoveLessonDateSerializer,
    StudentLeaveReportSerializer, LeaveReportFilterSerializer, RestoreLessonSerializer, CancelLessonSerializer,
    DiscountPriceSerializer
)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.db.models import Avg
from .models import Exams, ExamResults, Group
from .models import StudentGroup, StudentFreezes
from .serializers import (
    ExamCreateSerializer,
    ExamUpdateSerializer,
    ExamResultSerializer,
    ExamListSerializer,
    ExamDetailSerializer,
    ExamParticipantsSettingsSerializer
)
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import HttpResponse
from django.db.models import Q, Prefetch
from .models import Group, GroupTeacher
from .models import StudentGroup, StudentFreezes
from .serializers import (
    GroupExportFilterSerializer,
    GroupExportColumnsSerializer,
    StudentExportFilterSerializer,
    StudentExportColumnsSerializer,
    GroupExportDataSerializer,
    StudentExportDataSerializer,
    ExportHistorySerializer,
    create_export_audit_log
)
from audit.models import AuditLog, AuditEntityType, AuditAction
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from datetime import datetime
from .models import Group, GroupTeacher, Course, Room
from .serializers import (
    GroupCreateUpdateSerializer,

)
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from .serializers import CreateStudentDiscountSerializer, StudentDiscountSerializer
from .models import (
    Student, StudentGroup, StudentPricing, StudentBalances,
    StudentTarnsactions, LeaveReason, StudentGroupLeaves,
    StudentFreezes, StudentBalanceHistory, Attendence,
    Room, Course, Group, GroupTeacher,
    LessonTime, LessonSchedule, Exams, ExamResults,
    TeacherSalaryRules, TeacherSalaryPayments, TeacherSalaryCalculations
)
from .serializers import (
    StudentSerializer, StudentGroupSerializer, StudentPricingSerializer,
    StudentBalancesSerializer, StudentTarnsactionsSerializer, LeaveReasonSerializer,
    StudentGroupLeavesSerializer, StudentFreezesSerializer, StudentBalanceHistorySerializer,
    AttendenceSerializer, RoomSerializer, CourseSerializer, GroupSerializer,
    GroupTeacherSerializer, LessonTimeSerializer, LessonScheduleSerializer,
    ExamsSerializer, ExamResultsSerializer,
    TeacherSalaryRulesSerializer, TeacherSalaryPaymentsSerializer, TeacherSalaryCalculationsSerializer
)
from ..accounts.models import Employee


# ==================== STUDENT VIEWSETS ====================
@extend_schema(tags=["Students - Studentlar "])
class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

@extend_schema(tags=["StudentGroup - Student va Guruh bog'langan jadval "])
class StudentGroupViewSet(viewsets.ModelViewSet):
    queryset = StudentGroup.objects.all()
    serializer_class = StudentGroupSerializer

@extend_schema(tags=["StudentPricing - Studentga narx belgilash "])
class StudentPricingViewSet(viewsets.ModelViewSet):
    queryset = StudentPricing.objects.all()
    serializer_class = StudentPricingSerializer

@extend_schema(tags=["StudentBalances - Studentning balansini ko'rish"])
class StudentBalancesViewSet(viewsets.ModelViewSet):
    queryset = StudentBalances.objects.all()
    serializer_class = StudentBalancesSerializer

@extend_schema(tags=["StudentTarnsactions - Student to'lovlarni tarixi"])
class StudentTarnsactionsViewSet(viewsets.ModelViewSet):
    queryset = StudentTarnsactions.objects.all()
    serializer_class = StudentTarnsactionsSerializer

@extend_schema(tags=["LeaveReason - Studentlarning chiqib ketish sabablari"])
class LeaveReasonViewSet(viewsets.ModelViewSet):
    queryset = LeaveReason.objects.all()
    serializer_class = LeaveReasonSerializer

@extend_schema(tags=["StudentGroupLeaves - Studentni guruhdan chiqib ketish "])
class StudentGroupLeavesViewSet(viewsets.ModelViewSet):
    queryset = StudentGroupLeaves.objects.all()
    serializer_class = StudentGroupLeavesSerializer

@extend_schema(tags=["StudentFreezes - Studentdarsni muzlatish"])
class StudentFreezesViewSet(viewsets.ModelViewSet):
    queryset = StudentFreezes.objects.all()
    serializer_class = StudentFreezesSerializer

@extend_schema(tags=["StudentBalanceHistory - Student balansi tarixi"])
class StudentBalanceHistoryViewSet(viewsets.ModelViewSet):
    queryset = StudentBalanceHistory.objects.all()
    serializer_class = StudentBalanceHistorySerializer

@extend_schema(tags=["Attendence - Yo'qlama"])
class AttendenceViewSet(viewsets.ModelViewSet):
    queryset = Attendence.objects.all()
    serializer_class = AttendenceSerializer


# ==================== GROUP VIEWSETS ====================
@extend_schema(tags=["Room - Xona"])
class RoomViewSet(viewsets.ModelViewSet):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer

@extend_schema(tags=["Course - Kurslar"])
class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

@extend_schema(tags=["Group - Guruh "])
class GroupViewSet(viewsets.ModelViewSet):
    queryset = Group.objects.all()
    serializer_class = GroupSerializer

@extend_schema(tags=["GroupTeacher - Guruhlarni o'qituvchilarga bog'lash "])
class GroupTeacherViewSet(viewsets.ModelViewSet):
    queryset = GroupTeacher.objects.all()
    serializer_class = GroupTeacherSerializer


# ==================== LESSON VIEWSETS ====================
@extend_schema(tags=["LessonTime - Dars vaqtlari"])
class LessonTimeViewSet(viewsets.ModelViewSet):
    serializer_class = LessonTimeSerializer

    def get_queryset(self):
        qs = LessonTime.objects.all()

        name = self.request.query_params.get("name")
        code = self.request.query_params.get("code")

        if name:
            qs = qs.filter(name__icontains=name)

        if code:
            qs = qs.filter(code__icontains=code)

        return qs

    def list(self, request, *args, **kwargs):
        qs = self.get_queryset()
        serializer = self.get_serializer(qs, many=True)
        return Response({
            "count": qs.count(),
            "results": serializer.data
        })

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

@extend_schema(tags=["LessonSchedule - Dars jadvali ro'yxati "])
class LessonScheduleViewSet(viewsets.ModelViewSet):
    queryset = LessonSchedule.objects.all()
    serializer_class = LessonScheduleSerializer

@extend_schema(tags=["ExamsView - Imtihonlar jadvlai "])
class ExamsViewSet(viewsets.ModelViewSet):
    queryset = Exams.objects.all()
    serializer_class = ExamsSerializer

@extend_schema(tags=["ExamResults - Imtihonlar natijalari "])
class ExamResultsViewSet(viewsets.ModelViewSet):
    queryset = ExamResults.objects.all()
    serializer_class = ExamResultsSerializer



# ==================== TEACHER VIEWSETS ====================
@extend_schema(tags=["TeacherSalaryRules - O'qituvchi oylik qoidalari "])
class TeacherSalaryRulesViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryRules.objects.all()
    serializer_class = TeacherSalaryRulesSerializer

@extend_schema(tags=["TeacherSalaryPayments - O'qituvchilarga oylik berish"])
class TeacherSalaryPaymentsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryPayments.objects.all()
    serializer_class = TeacherSalaryPaymentsSerializer

@extend_schema(tags=["TeacherSalaryCalculations - O'qituvchi oyliklarini hisoblash "])
class TeacherSalaryCalculationsViewSet(viewsets.ModelViewSet):
    queryset = TeacherSalaryCalculations.objects.all()
    serializer_class = TeacherSalaryCalculationsSerializer





# ==================== GROUP VIEWS ====================

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def group_list_create(request):
    """
    GET: Barcha guruhlarni olish (filter bilan)
    POST: Yangi guruh yaratish
    """
    if request.method == 'GET':
        # Filterlar
        status_filter = request.query_params.get('status', None)
        course_id = request.query_params.get('course', None)
        room_id = request.query_params.get('room', None)
        search = request.query_params.get('search', None)

        # Barcha guruhlar
        groups = Group.objects.all().select_related('course', 'room')

        # Status filter
        if status_filter:
            groups = groups.filter(status=status_filter)

        # Course filter
        if course_id:
            groups = groups.filter(course_id=course_id)

        # Room filter
        if room_id:
            groups = groups.filter(room_id=room_id)

        # Search (guruh nomi bo'yicha)
        if search:
            groups = groups.filter(name__icontains=search)

        # Serializer
        serializer = GroupListSerializer(groups, many=True)

        return Response({
            'success': True,
            'count': groups.count(),
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        # Yangi guruh yaratish
        serializer = GroupCreateUpdateSerializer(data=request.data)

        if serializer.is_valid():
            try:
                group = serializer.save()

                return Response({
                    'success': True,
                    'message': 'Guruh muvaffaqiyatli yaratildi.',
                    'data': serializer.data
                }, status=status.HTTP_201_CREATED)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def group_detail_update_delete(request, pk):
    """
    GET: Bitta guruhni olish
    PUT/PATCH: Guruhni yangilash
    DELETE: Guruhni o'chirish (arxivlash)
    """
    group = get_object_or_404(Group, pk=pk)

    if request.method == 'GET':
        # Guruh detallari
        serializer = GroupDetailSerializer(group)
        return Response({
            'success': True,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method in ['PUT', 'PATCH']:
        # Guruhni yangilash
        partial = request.method == 'PATCH'
        serializer = GroupCreateUpdateSerializer(group, data=request.data, partial=partial)

        if serializer.is_valid():
            try:
                group = serializer.save()

                return Response({
                    'success': True,
                    'message': 'Guruh muvaffaqiyatli yangilandi.',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        # Guruhni arxivlash (soft delete)
        group.status = 'archived'
        group.save()

        return Response({
            'success': True,
            'message': 'Guruh arxivlandi.'
        }, status=status.HTTP_200_OK)


# ==================== GROUP TEACHER VIEWS ====================

@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def group_teacher_list_create(request, group_pk):
    """
    GET: Guruh o'qituvchilarini olish
    POST: Guruhga o'qituvchi qo'shish
    """
    group = get_object_or_404(Group, pk=group_pk)

    if request.method == 'GET':
        # Guruh o'qituvchilari
        teachers = group.group.all().select_related('teacher', 'group')
        serializer = GroupTeacherSerializer(teachers, many=True)

        return Response({
            'success': True,
            'count': teachers.count(),
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        # O'qituvchi qo'shish
        data = request.data.copy()
        data['group'] = group.pk

        serializer = GroupTeacherSerializer(data=data)

        if serializer.is_valid():
            try:
                serializer.save()

                return Response({
                    'success': True,
                    'message': 'O\'qituvchi muvaffaqiyatli qo\'shildi.',
                    'data': serializer.data
                }, status=status.HTTP_201_CREATED)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Ma\'lumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def group_teacher_detail_update_delete(request, group_pk, pk):
    """
    GET: Bitta guruh-o'qituvchi ma'lumotini olish
    PUT/PATCH: Guruh-o'qituvchi ma'lumotini yangilash
    DELETE: Guruhdan o'qituvchini o'chirish
    """
    group = get_object_or_404(Group, pk=group_pk)
    group_teacher = get_object_or_404(GroupTeacher, pk=pk, group=group)

    if request.method == 'GET':
        serializer = GroupTeacherSerializer(group_teacher)
        return Response({
            'success': True,
            'data': serializer.data
        }, status=status.HTTP_200_OK)

    elif request.method in ['PUT', 'PATCH']:
        partial = request.method == 'PATCH'
        serializer = GroupTeacherSerializer(group_teacher, data=request.data, partial=partial)

        if serializer.is_valid():
            try:
                serializer.save()

                return Response({
                    'success': True,
                    'message': 'Ma\'lumot muvaffaqiyatli yangilandi.',
                    'data': serializer.data
                }, status=status.HTTP_200_OK)

            except ValidationError as e:
                return Response({
                    'success': False,
                    'message': 'Validatsiya xatosi.',
                    'errors': e.message_dict if hasattr(e, 'message_dict') else str(e)
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': False,
            'message': 'Malumotlar noto\'g\'ri.',
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        # O'qituvchini guruhdan o'chirish
        # Kamida bitta o'qituvchi qolishi kerak
        if group.group.count() <= 1:
            return Response({
                'success': False,
                'message': 'Guruhda kamida bitta o\'qituvchi bo\'lishi kerak.'
            }, status=status.HTTP_400_BAD_REQUEST)

        group_teacher.delete()

        return Response({
            'success': True,
            'message': 'O\'qituvchi guruhdan o\'chirildi.'
        }, status=status.HTTP_200_OK)


# ==================== HELPER VIEWS ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def course_list(request):
    """Barcha kurslarni olish (dropdown uchun)"""
    courses = Course.objects.all()
    serializer = CourseSerializer(courses, many=True)

    return Response({
        'success': True,
        'count': courses.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def room_list(request):
    """Barcha xonalarni olish (dropdown uchun)"""
    rooms = Room.objects.all()
    serializer = RoomSerializer(rooms, many=True)

    return Response({
        'success': True,
        'count': rooms.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def available_rooms(request):
    """
    Bo'sh xonalarni olish
    Query params: lesson, start_date, end_date
    """
    lesson_id = request.query_params.get('lesson')
    start_date = request.query_params.get('start_date')
    end_date = request.query_params.get('end_date')

    if not all([lesson_id, start_date, end_date]):
        return Response({
            'success': False,
            'message': 'lesson, start_date va end_date parametrlari majburiy.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Band xonalarni topish
    occupied_rooms = Group.objects.filter(
        course__lesson_id=lesson_id,
        status='active'
    ).filter(
        Q(start_date__lte=end_date) &
        Q(end_date__gte=start_date)
    ).values_list('room_id', flat=True)

    # Bo'sh xonalar
    available = Room.objects.exclude(id__in=occupied_rooms)
    serializer = RoomSerializer(available, many=True)

    return Response({
        'success': True,
        'count': available.count(),
        'data': serializer.data
    }, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_statistics(request):
    """Guruhlar statistikasi"""
    total_groups = Group.objects.count()
    active_groups = Group.objects.filter(status='active').count()
    expired_groups = Group.objects.filter(status='expried').count()
    archived_groups = Group.objects.filter(status='archived').count()

    return Response({
        'success': True,
        'data': {
            'total': total_groups,
            'active': active_groups,
            'expired': expired_groups,
            'archived': archived_groups
        }
    }, status=status.HTTP_200_OK)


from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.utils import timezone

from .models import Group, StudentGroup, Student, Attendence, StudentPricing, Exams, ExamResults
from .serializers import (
    GroupFullInfoSerializer, AttendanceSerializer, StudentListSerializer,
    AddStudentSerializer, SMSSerializer, DiscountSerializer,
    ExamSerializer, ExamResultSerializer
)


# 1. GURUH MA'LUMOTLARI
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_full_info(request, pk):
    group = get_object_or_404(Group, pk=pk)
    serializer = GroupFullInfoSerializer(group)
    return Response({'success': True, 'data': serializer.data})


# 2. DAVOMAT
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def attendance_list_create(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)

    if request.method == 'GET':
        date = request.query_params.get('date')
        attendances = Attendence.objects.filter(student_group__group=group)
        if date:
            attendances = attendances.filter(lesson_date=date)
        serializer = AttendanceSerializer(attendances, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = AttendanceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(marked_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 3. O'QUVCHILAR RO'YXATI
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def students_list(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    status_filter = request.query_params.get('status')
    search = request.query_params.get('search')

    students = StudentGroup.objects.filter(group=group)

    if status_filter == 'active':
        students = students.filter(left_at__gte=timezone.now().date())
    elif status_filter == 'left':
        students = students.filter(left_at__lt=timezone.now().date())

    if search:
        students = students.filter(student__full_name__icontains=search)

    serializer = StudentListSerializer(students, many=True)
    return Response({'success': True, 'data': serializer.data})


# 5. GURUHGA ODAM QO'SHISH
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_student(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    data = request.data.copy()
    data['group'] = group.pk

    serializer = AddStudentSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
    return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def remove_student(request, group_pk, student_group_pk):
    sg = get_object_or_404(StudentGroup, pk=student_group_pk, group_id=group_pk)
    sg.left_at = timezone.now().date()
    sg.save()
    return Response({'success': True, 'message': 'Talaba o\'chirildi'})


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def send_sms(request, group_pk):
    group = get_object_or_404(Group, pk=group_pk)
    serializer = SMSSerializer(data=request.data)

    if serializer.is_valid():
        message = serializer.validated_data['message']
        send_to = serializer.validated_data['send_to']

        phones = []
        students = StudentGroup.objects.filter(group=group, left_at__gte=timezone.now().date())

        for sg in students:
            if send_to in ['all', 'students']:
                phones.append(sg.student.phone_number)
            if send_to in ['all', 'parents'] and sg.student.parent_phone:
                phones.append(sg.student.parent_phone)

        # TODO: SMS provider integration
        return Response({'success': True, 'message': f'{len(phones)} ta SMS yuborildi'})

    return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 6. CHEGIRMALAR
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def discount_list_create(request):
    if request.method == 'GET':
        student_id = request.query_params.get('student')
        discounts = StudentPricing.objects.all()
        if student_id:
            discounts = discounts.filter(student_id=student_id)
        serializer = DiscountSerializer(discounts, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = DiscountSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def discount_detail(request, pk):
    discount = get_object_or_404(StudentPricing, pk=pk)

    if request.method == 'GET':
        serializer = DiscountSerializer(discount)
        return Response({'success': True, 'data': serializer.data})

    elif request.method == 'PUT':
        serializer = DiscountSerializer(discount, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'data': serializer.data})
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    else:  # DELETE
        # FOREIGN KEY CHEKLOVI: StudentGroup mavjudligini tekshirish
        related_student_groups = StudentGroup.objects.filter(
            student=discount.student,
            group__course=discount.course,
            left_at__gte=timezone.now().date()
        )

        if related_student_groups.exists():
            return Response({
                'success': False,
                'message': f'Bu chegirmani o\'chirish mumkin emas. {related_student_groups.count()} ta faol guruhda ishlatilmoqda.'
            }, status=status.HTTP_400_BAD_REQUEST)

        discount.delete()
        return Response({'success': True, 'message': 'Chegirma o\'chirildi'})


# 7. IMTIHONLAR
@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def exam_list_create(request):
    if request.method == 'GET':
        group_id = request.query_params.get('group')
        exams = Exams.objects.all()
        if group_id:
            exams = exams.filter(group_id=group_id)
        serializer = ExamSerializer(exams, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        serializer = ExamSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([IsAuthenticated])
def exam_detail(request, pk):
    exam = get_object_or_404(Exams, pk=pk)

    if request.method == 'GET':
        serializer = ExamSerializer(exam)
        return Response({'success': True, 'data': serializer.data})

    elif request.method == 'PUT':
        serializer = ExamSerializer(exam, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'data': serializer.data})
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    else:  # DELETE
        # FOREIGN KEY CHEKLOVI: ExamResults mavjudligini tekshirish
        results_count = ExamResults.objects.filter(exam=exam).count()

        if results_count > 0:
            return Response({
                'success': False,
                'message': f'Bu imtihonni o\'chirish mumkin emas. {results_count} ta natija mavjud. Avval natijalarni o\'chiring.'
            }, status=status.HTTP_400_BAD_REQUEST)

        exam.delete()
        return Response({'success': True, 'message': 'Imtihon o\'chirildi'})


@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def exam_results(request, exam_pk):
    exam = get_object_or_404(Exams, pk=exam_pk)

    if request.method == 'GET':
        results = ExamResults.objects.filter(exam=exam)
        serializer = ExamResultSerializer(results, many=True)
        return Response({'success': True, 'data': serializer.data})

    else:  # POST
        data = request.data.copy()
        data['exam'] = exam.pk
        serializer = ExamResultSerializer(data=data)
        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({'success': True, 'data': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


# 8. TARIX (AUDIT LOG)
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_history(request, group_pk):

    group = get_object_or_404(Group, pk=group_pk)

    logs = AuditLog.objects.filter(
        entity_type='group',
        entity_id=group.id
    ).order_by('-created_at')

    # 🔹 action bo‘yicha filter
    action = request.query_params.get('action')
    if action:
        logs = logs.filter(action=action)

    # 🔹 bitta sana bo‘yicha filter
    date = request.query_params.get('date')
    if date:
        parsed_date = parse_date(date)
        if parsed_date:
            logs = logs.filter(created_at__date=parsed_date)

    # 🔹 sana oralig‘i bo‘yicha filter
    date_from = request.query_params.get('from')
    date_to = request.query_params.get('to')

    if date_from:
        logs = logs.filter(created_at__date__gte=date_from)

    if date_to:
        logs = logs.filter(created_at__date__lte=date_to)

    data = [{
        'id': str(log.id),
        'action': log.action,
        'old_data': log.old_data,
        'new_data': log.new_action,
        'performed_by': (
            f"{log.performed_by.user.first_name} {log.performed_by.user.last_name}"
            if log.performed_by and log.performed_by.user else None
        ),
        'created_at': log.created_at
    } for log in logs]

    return Response(data)


# ==================== 1. O'QUVCHINI QIDIRISH ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_search(request):
    """
    O'quvchini ismi yoki telefon raqami bo'yicha qidirish

    GET /api/students/search/?q=ismi_yoki_raqami

    Query params:
    - q: qidiruv so'zi (ism yoki telefon raqam)

    Response:
    {
        "success": true,
        "count": 5,
        "data": [
            {
                "id": 1,
                "full_name": "Jasur Aliyev",
                "phone_number": "+998901234567",
                "balance": 500000,
                "groups_count": 2
            }
        ]
    }
    """
    query = request.query_params.get('q', '').strip()

    if not query:
        return Response({
            'success': False,
            'message': 'Qidiruv so\'zi kiritilmagan. q parametrini kiriting.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Qidiruv: ism yoki telefon raqam bo'yicha
    students = Student.objects.filter(
        Q(full_name__icontains=query) |
        Q(phone_number__icontains=query) |
        Q(phone_number2__icontains=query)
    ).distinct()[:20]  # Faqat 20 ta natija

    serializer = StudentSearchSerializer(students, many=True)

    return Response({
        'success': True,
        'count': students.count(),
        'query': query,
        'data': serializer.data
    }, status=status.HTTP_200_OK)


# ==================== 2. GURUHGA TALABA QO'SHISH (YANGILANGAN) ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_student_to_group(request, group_pk):
    """
    Guruhga talaba qo'shish

    POST /api/groups/<group_id>/add-student/

    Body:
    {
        "student": 1,
        "joined_at": "2025-02-01",
        "left_at": "2025-08-01",
        "end_date": "2025-08-01"
    }

    Response:
    {
        "success": true,
        "message": "Talaba guruhga qo'shildi",
        "data": {...}
    }
    """
    from .models import Group

    group = get_object_or_404(Group, pk=group_pk)

    data = request.data.copy()
    data['group'] = group.pk

    serializer = AddStudentToGroupSerializer(data=data)

    if serializer.is_valid():
        student_group = serializer.save()

        return Response({
            'success': True,
            'message': 'Talaba muvaffaqiyatli guruhga qo\'shildi.',
            'data': serializer.data
        }, status=status.HTTP_201_CREATED)

    return Response({
        'success': False,
        'message': 'Ma\'lumotlar noto\'g\'ri.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


# ==================== 3. TALABANI FAOLLASHTIRISH ====================

@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def activate_student(request, student_pk):
    """
    Talabani faollashtirish - balansga pul qo'shish

    PUT /api/students/<student_id>/activate/

    Body:
    {
        "amount": 500000,
        "payment_type": "cash",
        "comment": "Birinchi to'lov"
    }

    Response:
    {
        "success": true,
        "message": "Talaba muvaffaqiyatli faollashtirildi",
        "data": {
            "student_id": 1,
            "student_name": "Jasur Aliyev",
            "old_balance": 0,
            "added_amount": 500000,
            "new_balance": 500000,
            "status": "active"
        }
    }
    """
    student = get_object_or_404(Student, pk=student_pk)

    serializer = ActivateStudentSerializer(data=request.data)

    if serializer.is_valid():
        try:
            # Talabani faollashtirish
            result = serializer.activate_student(
                student=student,
                validated_data=serializer.validated_data,
                user=request.user.employee
            )

            return Response({
                'success': True,
                'message': 'Talaba muvaffaqiyatli faollashtirildi.',
                'data': result
            }, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({
                'success': False,
                'message': f'Xatolik yuz berdi: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    return Response({
        'success': False,
        'message': 'Ma\'lumotlar noto\'g\'ri.',
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


# ==================== 4. TALABA BALANSI VA HOLATI ====================

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def student_balance_status(request, student_pk):
    """
    Talaba balansi va holati

    GET /api/students/<student_id>/balance-status/

    Response:
    {
        "success": true,
        "data": {
            "student_id": 1,
            "full_name": "Jasur Aliyev",
            "balance": 500000,
            "status": "active",
            "active_groups": 2,
            "transactions_count": 5
        }
    }
    """
    from .models import StudentBalances, StudentTarnsactions
    from django.utils import timezone

    student = get_object_or_404(Student, pk=student_pk)

    # Balance
    try:
        student_balance = student.Sbalances_student.first()
        balance = float(student_balance.balance) if student_balance else 0.0
    except:
        balance = 0.0

    # Active groups count
    active_groups = student.Sgroup_student.filter(
        left_at__gte=timezone.now().date()
    ).count()

    # Transactions count
    transactions_count = student.Strans_student.count()

    # Status
    student_status = 'active' if balance > 0 else 'inactive'

    return Response({
        'success': True,
        'data': {
            'student_id': student.id,
            'full_name': student.full_name,
            'phone_number': student.phone_number,
            'balance': balance,
            'status': student_status,
            'active_groups': active_groups,
            'transactions_count': transactions_count
        }
    }, status=status.HTTP_200_OK)


# ============ ONLAYN DARSLAR VIEWS ============




@api_view(['GET', 'POST'])
@permission_classes([IsAuthenticated])
def group_online_lessons(request, group_pk):
    """
    GET  /api/groups/{groupId}/online-lessons/
    POST /api/groups/{groupId}/online-lessons/
    """
    group = get_object_or_404(Group, pk=group_pk)

    if request.method == 'GET':
        # Filterlar
        is_published = request.query_params.get('is_published')
        content_type = request.query_params.get('content_type')

        lessons = OnlineLesson.objects.filter(group=group)

        if is_published is not None:
            is_published_bool = is_published.lower() in ['true', '1']
            lessons = lessons.filter(is_published=is_published_bool)

        if content_type:
            lessons = lessons.filter(content_type=content_type)

        serializer = OnlineLessonListSerializer(lessons, many=True, context={'request': request})

        return Response({
            'success': True,
            'count': lessons.count(),
            'data': serializer.data
        })

    else:  # POST
        data = request.data.copy()
        data['group'] = group.pk

        serializer = OnlineLessonCreateUpdateSerializer(data=data, context={'request': request})

        if serializer.is_valid():
            serializer.save(created_by=request.user.employee)
            return Response({
                'success': True,
                'message': 'Dars yaratildi.',
                'data': serializer.data
            }, status=status.HTTP_201_CREATED)

        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PATCH', 'DELETE'])
@permission_classes([IsAuthenticated])
def online_lesson_detail(request, pk):
    """
    GET    /api/online-lessons/{lessonId}/
    PATCH  /api/online-lessons/{lessonId}/
    DELETE /api/online-lessons/{lessonId}/
    """
    lesson = get_object_or_404(OnlineLesson, pk=pk)

    if request.method == 'GET':
        serializer = OnlineLessonDetailSerializer(lesson, context={'request': request})
        return Response({'success': True, 'data': serializer.data})

    elif request.method == 'PATCH':
        serializer = OnlineLessonCreateUpdateSerializer(
            lesson, data=request.data, partial=True, context={'request': request}
        )

        if serializer.is_valid():
            serializer.save()
            return Response({
                'success': True,
                'message': 'Dars yangilandi.',
                'data': serializer.data
            })

        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    else:  # DELETE
        lesson.delete()
        return Response({
            'success': True,
            'message': 'Dars o\'chirildi.'
        })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def publish_lesson(request, pk):
    """POST /api/online-lessons/{lessonId}/publish/"""
    lesson = get_object_or_404(OnlineLesson, pk=pk)
    lesson.is_published = True
    lesson.save()

    return Response({
        'success': True,
        'message': 'Dars nashr qilindi.',
        'data': OnlineLessonDetailSerializer(lesson, context={'request': request}).data
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def unpublish_lesson(request, pk):
    """POST /api/online-lessons/{lessonId}/unpublish/"""
    lesson = get_object_or_404(OnlineLesson, pk=pk)
    lesson.is_published = False
    lesson.save()

    return Response({
        'success': True,
        'message': 'Dars nashrdan olindi.',
        'data': OnlineLessonDetailSerializer(lesson, context={'request': request}).data
    })


# ============ STUDENT DISCOUNT VIEWS ============




@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_student_discount(request, group_pk, student_group_pk):
    """
    O'quvchiga chegirma narxi berish

    POST /api/groups/{groupId}/students/{studentId}/discount/

    Body:
    {
        "price_override": 400000,
        "reason": "Yaxshi o'qiydi",
        "start_date": "2025-02-01",
        "end_date": "2025-08-01"
    }
    """
    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student

    serializer = CreateStudentDiscountSerializer(data=request.data)

    if serializer.is_valid():
        try:
            discount = serializer.create_discount(
                student=student,
                group=group,
                validated_data=serializer.validated_data,
                user=request.user.employee
            )

            response_serializer = StudentDiscountSerializer(discount, context={'request': request})

            return Response({
                'success': True,
                'message': 'Chegirma muvaffaqiyatli yaratildi.',
                'data': response_serializer.data
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_student_discount(request, group_pk, student_group_pk):
    """
    O'quvchi chegirmasini yangilash

    PATCH /api/groups/{groupId}/students/{studentId}/discount/

    Body:
    {
        "price_override": 350000,
        "reason": "Yangi sabab"
    }
    """
    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Hozirgi aktiv chegirmani topish
    today = timezone.now().date()

    try:
        discount = StudentPricing.objects.get(
            student=student,
            course=course,
            start_date__lte=today,
            end_date__gte=today
        )
    except StudentPricing.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Bu o\'quvchi uchun aktiv chegirma topilmadi.'
        }, status=status.HTTP_404_NOT_FOUND)

    serializer = StudentDiscountSerializer(discount, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()

        return Response({
            'success': True,
            'message': 'Chegirma yangilandi.',
            'data': serializer.data
        })

    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def delete_student_discount(request, group_pk, student_group_pk):
    """
    O'quvchi chegirmasini bekor qilish

    DELETE /api/groups/{groupId}/students/{studentId}/discount/
    """
    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Hozirgi aktiv chegirmani topish
    today = timezone.now().date()

    try:
        discount = StudentPricing.objects.get(
            student=student,
            course=course,
            start_date__lte=today,
            end_date__gte=today
        )
    except StudentPricing.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Bu o\'quvchi uchun aktiv chegirma topilmadi.'
        }, status=status.HTTP_404_NOT_FOUND)

    # Chegirmani bekor qilish (end_date ni bugunga qo'yamiz)
    discount.end_date = today
    discount.save()

    return Response({
        'success': True,
        'message': 'Chegirma bekor qilindi.'
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_student_discount(request, group_pk, student_group_pk):
    """
    O'quvchi chegirmasini ko'rish

    GET /api/groups/{groupId}/students/{studentId}/discount/
    """
    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Barcha chegirmalar
    discounts = StudentPricing.objects.filter(
        student=student,
        course=course
    ).order_by('-created_at')

    if not discounts.exists():
        return Response({
            'success': True,
            'message': 'Chegirma topilmadi.',
            'data': None
        })

    # Hozirgi aktiv chegirma
    today = timezone.now().date()
    active_discount = discounts.filter(
        start_date__lte=today,
        end_date__gte=today
    ).first()

    serializer = StudentDiscountSerializer(
        active_discount or discounts.first(),
        context={'request': request}
    )

    return Response({
        'success': True,
        'data': serializer.data,
        'is_active': active_discount is not None
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def calculate_payment_difference(request, group_pk, student_group_pk):
    """
    Faollashtirilgan o'quvchi uchun to'lov farqini hisoblash

    GET /api/groups/{groupId}/students/{studentId}/discount/calculate/

    Response:
    {
        "original_price": 500000,
        "discount_price": 400000,
        "difference": 100000,
        "months_remaining": 6,
        "total_savings": 600000
    }
    """
    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Hozirgi aktiv chegirma
    today = timezone.now().date()

    try:
        discount = StudentPricing.objects.get(
            student=student,
            course=course,
            start_date__lte=today,
            end_date__gte=today
        )
    except StudentPricing.DoesNotExist:
        return Response({
            'success': False,
            'message': 'Aktiv chegirma topilmadi.'
        }, status=status.HTTP_404_NOT_FOUND)

    # Hisoblash
    original_price = float(course.monthly_price)
    discount_price = float(discount.price_override)
    difference = original_price - discount_price

    # Qolgan oylar (guruh tugashiga qadar)
    from dateutil.relativedelta import relativedelta
    months_remaining = 0
    if group.end_date > today:
        delta = relativedelta(group.end_date, today)
        months_remaining = delta.years * 12 + delta.months

    total_savings = difference * months_remaining

    return Response({
        'success': True,
        'data': {
            'original_price': original_price,
            'discount_price': discount_price,
            'difference': difference,
            'discount_percentage': round((difference / original_price) * 100, 2),
            'months_remaining': months_remaining,
            'total_savings': total_savings,
            'group_end_date': group.end_date
        }
    })


# ============ DARS SANASI BOSHQARUVI VIEWS ============




@api_view(['GET'])
@permission_classes([IsAuthenticated])
def group_lessons(request, group_pk):
    """
    Guruh darslarini olish

    GET /api/groups/{groupId}/lessons/
    """
    group = get_object_or_404(Group, pk=group_pk)

    # Filterlar
    day_type = request.query_params.get('day_type')

    lessons = LessonSchedule.objects.filter(group=group)

    if day_type:
        lessons = lessons.filter(day_type=day_type)

    lessons = lessons.order_by('day_type', 'start_time')

    serializer = LessonScheduleListSerializer(lessons, many=True)

    return Response({
        'success': True,
        'count': lessons.count(),
        'data': serializer.data
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def lesson_detail(request, group_pk, lesson_pk):
    """
    Tanlangan darsni aniqlash

    GET /api/groups/{groupId}/lessons/{lessonId}/
    """
    group = get_object_or_404(Group, pk=group_pk)
    lesson = get_object_or_404(LessonSchedule, pk=lesson_pk, group=group)

    serializer = LessonScheduleDetailSerializer(lesson)

    return Response({
        'success': True,
        'data': serializer.data
    })


@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def move_lesson_date(request, group_pk, lesson_pk):
    """
    Dars sanasini ko'chirish

    PATCH /api/groups/{groupId}/lessons/{lessonId}/move-date/

    Body:
    {
        "new_start_time": "14:00",
        "new_end_time": "16:00",
        "new_day_type": "even"  // optional
    }
    """
    group = get_object_or_404(Group, pk=group_pk)
    lesson = get_object_or_404(LessonSchedule, pk=lesson_pk, group=group)

    serializer = MoveLessonDateSerializer(data=request.data)

    if serializer.is_valid():
        try:
            old_start = lesson.start_time
            old_end = lesson.end_time
            old_day_type = lesson.day_type

            updated_lesson = serializer.move_lesson(lesson, serializer.validated_data)

            response_serializer = LessonScheduleDetailSerializer(updated_lesson)

            return Response({
                'success': True,
                'message': 'Dars sanasi muvaffaqiyatli ko\'chirildi.',
                'old_schedule': {
                    'day_type': old_day_type,
                    'start_time': str(old_start),
                    'end_time': str(old_end)
                },
                'new_schedule': {
                    'day_type': updated_lesson.day_type,
                    'start_time': str(updated_lesson.start_time),
                    'end_time': str(updated_lesson.end_time)
                },
                'data': response_serializer.data
            })

        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def check_time_availability(request, group_pk):
    """
    Yangi sana band emasligini tekshirish

    POST /api/groups/{groupId}/lessons/check-availability/

    Body:
    {
        "start_time": "14:00",
        "end_time": "16:00",
        "day_type": "even",
        "exclude_lesson_id": 5  // optional - ko'chirayotgan darsni exclude qilish
    }
    """
    group = get_object_or_404(Group, pk=group_pk)

    start_time = request.data.get('start_time')
    end_time = request.data.get('end_time')
    day_type = request.data.get('day_type')
    exclude_lesson_id = request.data.get('exclude_lesson_id')

    if not all([start_time, end_time, day_type]):
        return Response({
            'success': False,
            'message': 'start_time, end_time va day_type majburiy.'
        }, status=status.HTTP_400_BAD_REQUEST)

    from django.db.models import Q

    # Xona to'qnashuvi
    room_conflicts = LessonSchedule.objects.filter(
        group__room=group.room,
        day_type=day_type
    ).filter(
        Q(start_time__lt=end_time) & Q(end_time__gt=start_time)
    )

    if exclude_lesson_id:
        room_conflicts = room_conflicts.exclude(pk=exclude_lesson_id)

    # O'qituvchi to'qnashuvi
    from .models import GroupTeacher

    teachers = GroupTeacher.objects.filter(group=group)
    teacher_conflicts = []

    for gt in teachers:
        conflicts = LessonSchedule.objects.filter(
            group__group__teacher=gt.teacher,
            day_type=day_type
        ).filter(
            Q(start_time__lt=end_time) & Q(end_time__gt=start_time)
        )

        if exclude_lesson_id:
            conflicts = conflicts.exclude(pk=exclude_lesson_id)

        if conflicts.exists():
            teacher_conflicts.append({
                'teacher': f"{gt.teacher.first_name} {gt.teacher.last_name}",
                'conflict_group': conflicts.first().group.name
            })

    is_available = not room_conflicts.exists() and not teacher_conflicts

    return Response({
        'success': True,
        'is_available': is_available,
        'room_conflicts': [{
            'group': c.group.name,
            'start_time': str(c.start_time),
            'end_time': str(c.end_time)
        } for c in room_conflicts],
        'teacher_conflicts': teacher_conflicts
    })

# bu guruhni tark etgan oquvcilar uchun
# ==================== VIEWS ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def student_leave_report(request):
    """
    Guruhni tark etgan talabalar hisoboti

    POST /api/reports/student-leaves/

    Body:
    {
        "leave_date_start": "2025-01-01",  // optional
        "leave_date_end": "2025-01-31",    // optional
        "search": "Jasur",                 // optional - ism yoki telefon
        "course_id": 1,                    // optional
        "group_id": 1,                     // optional
        "teacher_id": 1,                   // optional
        "archived_by_id": 1,               // optional
        "leave_reason_id": 1               // optional
    }

    Response:
    {
        "success": true,
        "filters": {...},
        "count": 25,
        "data": [
            {
                "student_id": 1,
                "full_name": "Jasur Aliyev",
                "phone_number": "+998901234567",
                "course_name": "Python",
                "group_name": "Python-01",
                "teacher_name": "Aziz Karimov",
                "status": "expelled",
                "archived_by": "Admin User",
                "leave_date": "2025-01-15T10:30:00Z",
                "leave_reason": "To'lov qilmadi",
                "comment": "3 oy to'lov qilmagan"
            }
        ]
    }
    """

    # Filtrlash serializer
    filter_serializer = LeaveReportFilterSerializer(data=request.data)

    if not filter_serializer.is_valid():
        return Response({
            'success': False,
            'errors': filter_serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    filters = filter_serializer.validated_data

    # Tark etgan talabalar (StudentGroupLeaves)
    leaves = StudentGroupLeaves.objects.select_related(
        'student',
        'group',
        'group__course',
        'leave_reason',
        'created_by'
    ).all()

    # Filtrlash

    # 1. Sana bo'yicha
    if filters.get('leave_date_start'):
        leaves = leaves.filter(leave_date__gte=filters['leave_date_start'])

    if filters.get('leave_date_end'):
        leaves = leaves.filter(leave_date__lte=filters['leave_date_end'])

    # 2. Ism yoki telefon
    if filters.get('search'):
        search = filters['search']
        leaves = leaves.filter(
            Q(student__full_name__icontains=search) |
            Q(student__phone_number__icontains=search) |
            Q(student__phone_number2__icontains=search)
        )

    # 3. Kurs
    if filters.get('course_id'):
        leaves = leaves.filter(group__course_id=filters['course_id'])

    # 4. Guruh
    if filters.get('group_id'):
        leaves = leaves.filter(group_id=filters['group_id'])

    # 5. O'qituvchi
    if filters.get('teacher_id'):
        leaves = leaves.filter(group__group__teacher_id=filters['teacher_id'])

    # 6. Arxivlagan xodim
    if filters.get('archived_by_id'):
        leaves = leaves.filter(created_by_id=filters['archived_by_id'])

    # 7. Sabab
    if filters.get('leave_reason_id'):
        leaves = leaves.filter(leave_reason_id=filters['leave_reason_id'])

    # Natijalar
    results = []

    for leave in leaves:
        # O'qituvchilar
        teachers = leave.group.group.all()
        teacher_names = ', '.join([
            f"{t.teacher.first_name} {t.teacher.last_name}"
            for t in teachers
        ])

        results.append({
            'student_id': leave.student.id,
            'full_name': leave.student.full_name,
            'phone_number': leave.student.phone_number,
            'course_name': leave.group.course.name if leave.group.course else '-',
            'group_name': leave.group.name,
            'teacher_name': teacher_names or '-',
            'status': 'archived',  # Tark etgan talabalar
            'archived_by': f"{leave.created_by.first_name} {leave.created_by.last_name}" if leave.created_by else '-',
            'leave_date': leave.leave_date,
            'leave_reason': leave.leave_reason.name if leave.leave_reason else '-',
            'comment': leave.comment or '-'
        })

    serializer = StudentLeaveReportSerializer(results, many=True)

    return Response({
        'success': True,
        'filters': filters,
        'count': len(results),
        'data': serializer.data
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def leave_reasons_list(request):
    """
    Tark etish sabablari ro'yxati (filter uchun)

    GET /api/reports/leave-reasons/
    """
    from .models import LeaveReason

    reasons = LeaveReason.objects.filter(is_active=True).values('id', 'name')

    return Response({
        'success': True,
        'data': list(reasons)
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def teachers_list(request):
    """
    O'qituvchilar ro'yxati (filter uchun)

    GET /api/reports/teachers/
    """

    teachers = Employee.objects.filter(
        is_active=True
    ).values('id', 'first_name', 'last_name')

    data = [
        {
            'id': t['id'],
            'name': f"{t['first_name']} {t['last_name']}"
        }
        for t in teachers
    ]

    return Response({
        'success': True,
        'data': data
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def courses_list(request):
    """
    Kurslar ro'yxati (filter uchun)

    GET /api/reports/courses/
    """

    courses = Course.objects.all().values('id', 'name')

    return Response({
        'success': True,
        'data': list(courses)
    })

# bu darsni bekor qilish

# ==================== VIEWS ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def cancel_lesson(request, group_pk, lesson_pk):
    """
    Darsni bekor qilish

    POST /api/groups/{groupId}/lessons/{lessonId}/cancel/

    Body:
    {
        "lesson_date": "2025-02-15",
        "cancellation_reason": "O'qituvchi kasal",
        "recalculate_balance": true
    }
    """

    group = get_object_or_404(Group, pk=group_pk)
    lesson = get_object_or_404(LessonSchedule, pk=lesson_pk, group=group)

    serializer = CancelLessonSerializer(
        data=request.data,
        context={'lesson_schedule_id': lesson.id}
    )

    if serializer.is_valid():
        try:
            audit = serializer.cancel_lesson(
                group=group,
                lesson_schedule=lesson,
                validated_data=serializer.validated_data,
                user=request.user.employee
            )

            return Response({
                'success': True,
                'message': 'Dars bekor qilindi.',
                'data': {
                    'id': audit.id,
                    'lesson_date': audit.old_data['lesson_date'],
                    'refund_per_student': audit.new_data.get('refund_per_student', 0),
                    'total_refunded': audit.new_data.get('total_refunded', 0),
                    'students_count': audit.new_data.get('students_count', 0)
                }
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({
                'success': False,
                'message': f'Xatolik: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def restore_lesson(request, audit_pk):
    """
    Darsni qayta tiklash

    POST /api/cancelled-lessons/{auditId}/restore/

    Body:
    {
        "restore_note": "Xatolik bo'lgan"
    }
    """

    audit = get_object_or_404(
        AuditLog,
        pk=audit_pk,
        entity_type='cancelled_lesson',
        action='cancelled'
    )

    serializer = RestoreLessonSerializer(data=request.data)

    if serializer.is_valid():
        try:
            restored = serializer.restore_lesson(
                cancelled_audit=audit,
                user=request.user.employee
            )

            return Response({
                'success': True,
                'message': 'Dars qayta tiklandi. DIQQAT: Balans avtomatik qaytarilmadi!',
                'data': {
                    'id': restored.id,
                    'restored_at': restored.new_data.get('restored_at'),
                    'restored_by_name': restored.new_data.get('restored_by_name')
                }
            })

        except Exception as e:
            return Response({
                'success': False,
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)

    return Response({
        'success': False,
        'errors': serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def cancelled_lessons_list(request, group_pk):
    """
    Guruh bekor qilingan darslari

    GET /api/groups/{groupId}/cancelled-lessons/

    Query params:
    - is_restored: true/false
    """

    group = get_object_or_404(Group, pk=group_pk)

    # Bekor qilingan darslar
    cancelled = AuditLog.objects.filter(
        entity_type='cancelled_lesson',
        action='cancelled'
    ).filter(
        old_data__group_id=group.id
    ).order_by('-created_at')

    # Filter: tiklanganlar
    is_restored = request.query_params.get('is_restored')
    if is_restored == 'true':
        cancelled = cancelled.filter(new_data__has_key='restored_at')
    elif is_restored == 'false':
        cancelled = cancelled.exclude(new_data__has_key='restored_at')

    # Format qilish
    results = []
    for audit in cancelled:
        results.append({
            'id': audit.id,
            'lesson_date': audit.old_data.get('lesson_date'),
            'group_name': audit.old_data.get('group_name'),
            'reason': audit.new_data.get('reason', ''),
            'cancelled_by_name': audit.new_data.get('cancelled_by_name'),
            'cancelled_at': audit.new_data.get('cancelled_at'),
            'refund_per_student': audit.new_data.get('refund_per_student', 0),
            'total_refunded': audit.new_data.get('total_refunded', 0),
            'is_restored': 'restored_at' in audit.new_data,
            'restored_at': audit.new_data.get('restored_at'),
            'restored_by_name': audit.new_data.get('restored_by_name')
        })

    return Response({
        'success': True,
        'count': len(results),
        'data': results
    })



# chegirma berishni viewsi
# ==================== VIEWS ====================

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def set_discount_price(request, group_pk, student_group_pk):
    """
    Chegirmali narx belgilash

    POST /api/groups/{groupId}/students/{studentGroupId}/discount-price/

    Body:
    {
        "price_override": 100000,
        "reason": "Yaxshi o'qiydi",
        "start_date": "2025-02-01",
        "end_date": "2025-12-31"
    }

    LOGIKA:
    1. Agar eski chegirma bor bo'lsa - bekor qilish
    2. Yangi chegirma yaratish
    3. Agar faollashtirilgan bo'lsa - balansni qaytarish
    4. Transaction yaratish
    """

    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    serializer = DiscountPriceSerializer(data=request.data)

    if serializer.is_valid():

        with transaction.atomic():

            # 1. Eski chegirmani bekor qilish (agar bor bo'lsa)
            today = timezone.now().date()

            old_discounts = StudentPricing.objects.filter(
                student=student,
                course=course,
                end_date__gte=today  # Hali tugamagan
            )

            for old in old_discounts:
                old.end_date = today  # Bekor qilish
                old.save()

            # 2. Yangi chegirma yaratish
            new_discount = StudentPricing.objects.create(
                student=student,
                course=course,
                price_override=serializer.validated_data['price_override'],
                reason=serializer.validated_data.get('reason', ''),
                start_date=serializer.validated_data['start_date'],
                end_date=serializer.validated_data['end_date'],
                created_by=request.user.employee
            )

            # 3. Faollashtirilganmi tekshirish
            is_active = student_group.joined_at <= today <= student_group.left_at

            refunded = 0

            if is_active:
                # Balansni qaytarish
                original_price = course.monthly_price
                new_price = new_discount.price_override

                if new_price < original_price:
                    refund = original_price - new_price

                    # Balance
                    balance, created = StudentBalances.objects.get_or_create(
                        student=student,
                        defaults={'balance': 0}
                    )

                    balance.balance += refund
                    balance.save()

                    # Transaction
                    StudentTarnsactions.objects.create(
                        student=student,
                        student_group=student_group,
                        group=group,
                        transaction_type='refund',
                        amount=refund,
                        payment_type='correction',
                        transaction_date=timezone.now(),
                        accepted_by=request.user.employee,
                        comment=f"Chegirma belgilandi: {original_price} → {new_price}"
                    )

                    refunded = float(refund)

            # Response
            response_serializer = StudentDiscountSerializer(new_discount)

            return Response({
                'success': True,
                'message': 'Chegirmali narx belgilandi.',
                'data': response_serializer.data,
                'refund_info': {
                    'is_active': is_active,
                    'refunded_amount': refunded,
                    'message': f'{refunded} so\'m qaytarildi' if refunded > 0 else 'Hali faollashtrilmagan'
                }
            }, status=status.HTTP_201_CREATED)

        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_student_discount(request, group_pk, student_group_pk):
    """
    Talaba chegirmasini ko'rish

    GET /api/groups/{groupId}/students/{studentGroupId}/discount-price/
    """

    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Aktiv chegirma
    today = timezone.now().date()

    discount = StudentPricing.objects.filter(
        student=student,
        course=course,
        start_date__lte=today,
        end_date__gte=today
    ).first()

    if not discount:
        return Response({
            'success': True,
            'message': 'Chegirma topilmadi.',
            'data': None,
            'original_price': float(course.monthly_price)
        })

    serializer = StudentDiscountSerializer(discount)

    return Response({
        'success': True,
        'data': serializer.data
    })


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def cancel_discount(request, group_pk, student_group_pk):
    """
    Chegirmani bekor qilish

    DELETE /api/groups/{groupId}/students/{studentGroupId}/discount-price/

    DIQQAT: Balans AVTOMATIK qaytarilmaydi!
    """

    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Aktiv chegirma
    today = timezone.now().date()

    discount = StudentPricing.objects.filter(
        student=student,
        course=course,
        start_date__lte=today,
        end_date__gte=today
    ).first()

    if not discount:
        return Response({
            'success': False,
            'message': 'Aktiv chegirma topilmadi.'
        }, status=status.HTTP_404_NOT_FOUND)

    # Bekor qilish
    discount.end_date = today
    discount.save()

    return Response({
        'success': True,
        'message': 'Chegirma bekor qilindi. DIQQAT: Balans avtomatik qaytarilmadi!'
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def discount_history(request, group_pk, student_group_pk):
    """
    Chegirmalar tarixi

    GET /api/groups/{groupId}/students/{studentGroupId}/discount-price/history/
    """

    group = get_object_or_404(Group, pk=group_pk)
    student_group = get_object_or_404(StudentGroup, pk=student_group_pk, group=group)
    student = student_group.student
    course = group.course

    # Barcha chegirmalar
    discounts = StudentPricing.objects.filter(
        student=student,
        course=course
    ).order_by('-created_at')

    serializer = StudentDiscountSerializer(discounts, many=True)

    return Response({
        'success': True,
        'count': discounts.count(),
        'data': serializer.data
    })


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.db.models import Q
from .models import Group, GroupTeacher, StudentGroup
from .models import StudentGroupLeaves, StudentFreezes
from audit.models import AuditLog, AuditEntityType
from .serializers import (
    GroupTeacherHistorySerializer,
    StudentGroupHistorySerializer,
    StudentLeaveHistorySerializer,
    StudentFreezeHistorySerializer,
    AuditLogSerializer
)


class GroupHistoryView(APIView):
    """Guruh to'liq tarixi - barcha harakatlar"""

    def get(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)

        # 1. O'qituvchilar tarixi
        teachers = GroupTeacher.objects.filter(group=group).select_related('teacher').order_by('-created_at')

        # 2. Talabalar qo'shilish tarixi
        students = StudentGroup.objects.filter(group=group).select_related('student').order_by('-created_at')

        # 3. Talabalar ketish tarixi
        leaves = StudentGroupLeaves.objects.filter(
            group=group
        ).select_related('student', 'leave_reason', 'created_by').order_by('-created_at')

        # 4. Muzlatishlar
        freezes = StudentFreezes.objects.filter(
            group=group
        ).select_related('student', 'created_by').order_by('-created_at')

        # 5. Audit logs (guruh o'zgarishlari)
        audit_logs = AuditLog.objects.filter(
            entity_type=AuditEntityType.GROUP,
            entity_id=group.id
        ).select_related('performed_by').order_by('-created_at')

        # Timeline yaratish - barcha harakatlarni chronological tartibda
        timeline = []

        for teacher in teachers:
            timeline.append({
                'type': 'teacher',
                'action': "O'qituvchi tayinlandi" if not teacher.end_date else "O'qituvchi almashtrildi",
                'date': teacher.created_at,
                'data': GroupTeacherHistorySerializer(teacher).data
            })

        for student in students:
            timeline.append({
                'type': 'student_join',
                'action': 'Talaba qo\'shildi',
                'date': student.created_at,
                'data': StudentGroupHistorySerializer(student).data
            })

        for leave in leaves:
            timeline.append({
                'type': 'student_leave',
                'action': 'Talaba ketdi',
                'date': leave.created_at,
                'data': StudentLeaveHistorySerializer(leave).data
            })

        for freeze in freezes:
            timeline.append({
                'type': 'freeze',
                'action': 'Talaba muzlatildi',
                'date': freeze.created_at,
                'data': StudentFreezeHistorySerializer(freeze).data
            })

        for log in audit_logs:
            timeline.append({
                'type': 'audit',
                'action': f"Guruh {log.get_action_display()}",
                'date': log.created_at,
                'data': AuditLogSerializer(log).data
            })

        # Sanasi bo'yicha sort qilish
        timeline.sort(key=lambda x: x['date'], reverse=True)

        return Response({
            'group': {
                'id': str(group.id),
                'name': group.name,
                'status': group.status
            },
            'summary': {
                'total_teachers': teachers.count(),
                'total_students_joined': students.count(),
                'total_students_left': leaves.count(),
                'total_freezes': freezes.count(),
                'total_changes': len(timeline)
            },
            'timeline': timeline
        })


class GroupTeacherHistoryView(APIView):
    """Guruh o'qituvchilari tarixi"""

    def get(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)
        teachers = GroupTeacher.objects.filter(
            group=group
        ).select_related('teacher').order_by('-created_at')

        serializer = GroupTeacherHistorySerializer(teachers, many=True)
        return Response({
            'group_id': str(group.id),
            'group_name': group.name,
            'teachers': serializer.data
        })


class GroupStudentsHistoryView(APIView):
    """Guruh talabalari tarixi (qo'shilish va ketish)"""

    def get(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)

        # Qo'shilgan talabalar
        joined = StudentGroup.objects.filter(
            group=group
        ).select_related('student').order_by('-created_at')

        # Ketgan talabalar
        left = StudentGroupLeaves.objects.filter(
            group=group
        ).select_related('student', 'leave_reason', 'created_by').order_by('-created_at')

        return Response({
            'group_id': str(group.id),
            'group_name': group.name,
            'students_joined': StudentGroupHistorySerializer(joined, many=True).data,
            'students_left': StudentLeaveHistorySerializer(left, many=True).data
        })


class GroupFreezesHistoryView(APIView):
    """Guruh muzlatishlar tarixi"""

    def get(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)
        freezes = StudentFreezes.objects.filter(
            group=group
        ).select_related('student', 'created_by').order_by('-created_at')

        serializer = StudentFreezeHistorySerializer(freezes, many=True)
        return Response({
            'group_id': str(group.id),
            'group_name': group.name,
            'freezes': serializer.data
        })


class GroupAuditLogView(APIView):
    """Guruh audit log - barcha o'zgarishlar"""

    def get(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)
        logs = AuditLog.objects.filter(
            entity_type=AuditEntityType.GROUP,
            entity_id=group.id
        ).select_related('performed_by').order_by('-created_at')

        serializer = AuditLogSerializer(logs, many=True)
        return Response({
            'group_id': str(group.id),
            'group_name': group.name,
            'audit_logs': serializer.data
        })


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from django.utils import timezone
from decimal import Decimal
from .models import (
    Student, StudentGroup, StudentFreezes,
    StudentGroupLeaves, StudentBalances, StudentTarnsactions, LeaveReason
)
from .models import Group
from .serializers import (
    StudentTransferSerializer, StudentFreezeSerializer,
    StudentLeaveSerializer, BalanceRecalculationSerializer,
    StudentGroupDetailSerializer, StudentFreezeDetailSerializer
)


class StudentTransferView(APIView):
    """Talabani boshqa guruhga o'tkazish"""

    @transaction.atomic
    def post(self, request):
        serializer = StudentTransferSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        student = data['student']
        from_group = data['from_group']
        to_group = data['to_group']
        transfer_date = data['transfer_date']
        recalc_balance = data['recalc_balance']

        # 1. Eski guruhdan chiqarish
        old_student_group = StudentGroup.objects.get(
            student=student,
            group=from_group,
            left_at__isnull=True
        )
        old_student_group.left_at = transfer_date
        old_student_group.save()

        # 2. Yangi guruhga qo'shish
        new_student_group = StudentGroup.objects.create(
            student=student,
            group=to_group,
            joined_at=transfer_date,
            end_date=to_group.end_date
        )

        # 3. Balansni qayta hisoblash (agar kerak bo'lsa)
        balance_info = None
        if recalc_balance:
            balance_info = self._recalculate_balance(
                student, from_group, to_group
            )

        # 4. Transaction yaratish (agar balans o'zgardi)
        if balance_info and balance_info.get('difference', 0) != 0:
            StudentTarnsactions.objects.create(
                student=student,
                student_group=new_student_group,
                group=to_group,
                transaction_type='correction',
                amount=balance_info['difference'],
                payment_type='transfer',
                transaction_date=timezone.now(),
                accepted_by=request.user,
                comment=f"Guruhdan o'tkazish: {from_group.name} → {to_group.name}"
            )

        return Response({
            'message': "Talaba muvaffaqiyatli o'tkazildi",
            'old_group': {
                'id': str(from_group.id),
                'name': from_group.name
            },
            'new_group': {
                'id': str(to_group.id),
                'name': to_group.name
            },
            'student': {
                'id': str(student.id),
                'full_name': student.full_name
            },
            'balance_recalculated': recalc_balance,
            'balance_info': balance_info
        }, status=status.HTTP_200_OK)

    def _recalculate_balance(self, student, from_group, to_group):
        """Balansni qayta hisoblash"""
        try:
            balance = StudentBalances.objects.get(student=student)
            old_balance = balance.balance

            # Eski guruh narxi
            old_price = from_group.course.monthly_price
            # Yangi guruh narxi
            new_price = to_group.course.monthly_price

            # Farq
            difference = new_price - old_price

            # Balansni yangilash
            balance.balance += difference
            balance.save()

            return {
                'old_balance': str(old_balance),
                'new_balance': str(balance.balance),
                'difference': str(difference),
                'old_price': str(old_price),
                'new_price': str(new_price)
            }
        except StudentBalances.DoesNotExist:
            return None


class StudentFreezeView(APIView):
    """Talabani muzlatish"""

    @transaction.atomic
    def post(self, request):
        serializer = StudentFreezeSerializer(
            data=request.data,
            context={'request': request}
        )

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        freeze = serializer.save()

        # Balansni qayta hisoblash (agar kerak bo'lsa)
        if freeze.recalc_balance:
            self._recalculate_freeze_balance(freeze)

        return Response({
            'message': "Talaba muvaffaqiyatli muzlatildi",
            'freeze': StudentFreezeDetailSerializer(freeze).data
        }, status=status.HTTP_201_CREATED)

    def get(self, request):
        """Barcha muzlatishlarni ko'rish"""
        student_id = request.query_params.get('student_id')
        group_id = request.query_params.get('group_id')

        freezes = StudentFreezes.objects.all().select_related(
            'student', 'group', 'created_by'
        )

        if student_id:
            freezes = freezes.filter(student_id=student_id)
        if group_id:
            freezes = freezes.filter(group_id=group_id)

        freezes = freezes.order_by('-created_at')
        serializer = StudentFreezeDetailSerializer(freezes, many=True)

        return Response({
            'count': freezes.count(),
            'freezes': serializer.data
        })

    def _recalculate_freeze_balance(self, freeze):
        """Muzlatish uchun balansni hisoblash"""
        try:
            balance = StudentBalances.objects.get(student=freeze.student)

            # Muzlatish kunlari
            freeze_days = (freeze.freeze_end_date - freeze.freeze_start_date).days

            # Bir kunlik narx
            monthly_price = freeze.group.course.monthly_price
            daily_price = monthly_price / 30

            # Qaytariladigan summa
            refund_amount = daily_price * freeze_days

            # Balansga qo'shish
            balance.balance += refund_amount
            balance.save()

            # Transaction yaratish
            StudentTarnsactions.objects.create(
                student=freeze.student,
                group=freeze.group,
                transaction_type='refund',
                amount=refund_amount,
                payment_type='correction',
                transaction_date=timezone.now(),
                comment=f"Muzlatish uchun qaytarildi: {freeze_days} kun"
            )

        except StudentBalances.DoesNotExist:
            pass


class StudentLeaveView(APIView):
    """Talabani guruhdan chiqarish"""

    @transaction.atomic
    def post(self, request):
        serializer = StudentLeaveSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        student = data['student']
        group = data['group']
        student_group = data['student_group']

        # 1. StudentGroup yangilash
        student_group.left_at = data['leave_date']
        student_group.save()

        # 2. Leave yaratish
        leave_reason = None
        if data.get('leave_reason_id'):
            try:
                leave_reason = LeaveReason.objects.get(id=data['leave_reason_id'])
            except LeaveReason.DoesNotExist:
                pass

        leave = StudentGroupLeaves.objects.create(
            student=student,
            group=group,
            student_group=student_group,
            leave_date=data['leave_date'],
            leave_reason=leave_reason,
            comment=data.get('comment', ''),
            recalc_balance=data['recalc_balance'],
            refound_amount=data['refound_amount'],
            created_by=request.user
        )

        # 3. Balansni qayta hisoblash
        if data['recalc_balance'] and data['refound_amount'] > 0:
            self._process_refund(student, group, data['refound_amount'])

        return Response({
            'message': "Talaba guruhdan muvaffaqiyatli chiqarildi",
            'student': {
                'id': str(student.id),
                'full_name': student.full_name
            },
            'group': {
                'id': str(group.id),
                'name': group.name
            },
            'leave_date': leave.leave_date,
            'refound_amount': str(leave.refound_amount)
        }, status=status.HTTP_200_OK)

    def _process_refund(self, student, group, amount):
        """Pul qaytarish"""
        try:
            balance = StudentBalances.objects.get(student=student)
            balance.balance += amount
            balance.save()

            # Transaction
            StudentTarnsactions.objects.create(
                student=student,
                group=group,
                transaction_type='refund',
                amount=amount,
                payment_type='correction',
                transaction_date=timezone.now(),
                comment="Guruhdan chiqish - pul qaytarish"
            )
        except StudentBalances.DoesNotExist:
            pass


class StudentActiveGroupsView(APIView):
    """Talabaning faol guruhlari"""

    def get(self, request, student_id):
        groups = StudentGroup.objects.filter(
            student_id=student_id,
            left_at__isnull=True
        ).select_related('group', 'student')

        serializer = StudentGroupDetailSerializer(groups, many=True)

        return Response({
            'count': groups.count(),
            'groups': serializer.data
        })


class StudentFreezesListView(APIView):
    """Talabaning muzlatishlari"""

    def get(self, request, student_id):
        freezes = StudentFreezes.objects.filter(
            student_id=student_id
        ).select_related('group', 'student', 'created_by').order_by('-created_at')

        serializer = StudentFreezeDetailSerializer(freezes, many=True)

        return Response({
            'count': freezes.count(),
            'freezes': serializer.data
        })


class BalanceRecalculationView(APIView):
    """Balansni qo'lda qayta hisoblash"""

    @transaction.atomic
    def post(self, request):
        serializer = BalanceRecalculationSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        student = data['student']
        recalc_type = data['recalc_type']

        # Balansni hisoblash
        result = self._calculate_balance(student, recalc_type, data)

        return Response({
            'message': "Balans qayta hisoblandi",
            'student': {
                'id': str(student.id),
                'full_name': student.full_name
            },
            'balance_info': result
        })

    def _calculate_balance(self, student, recalc_type, data):
        """Balans hisoblash"""
        try:
            balance = StudentBalances.objects.get(student=student)
            old_balance = balance.balance

            # Hisoblash logikasi
            if recalc_type == 'freeze':
                freeze_days = data.get('freeze_days', 0)
                # Hisoblash...

            # Balansni yangilash
            balance.save()

            return {
                'old_balance': str(old_balance),
                'new_balance': str(balance.balance),
                'recalc_type': recalc_type
            }
        except StudentBalances.DoesNotExist:
            return {'error': 'Balans topilmadi'}


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Q, Count, Prefetch
from django.shortcuts import get_object_or_404
from academics.models import Group, GroupTeacher, Course, Room
from students.models import StudentGroup
from .serializers import (
    GroupListSerializer, GroupCreateSerializer,
    GroupUpdateSerializer, GroupDetailSerializer,
    GroupArchiveSerializer, GroupFilterSerializer
)
from datetime import date, timedelta
import openpyxl
from django.http import HttpResponse


class GroupsListView(APIView):
    """Guruhlar ro'yxati - filtrlash, qidiruv, pagination"""

    def get(self, request):
        # Filter parametrlarini olish
        filter_serializer = GroupFilterSerializer(data=request.query_params)
        filter_serializer.is_valid()
        filters = filter_serializer.validated_data

        # Asosiy queryset
        queryset = Group.objects.all().select_related(
            'course', 'room'
        ).prefetch_related(
            Prefetch('group', queryset=GroupTeacher.objects.select_related('teacher')),
            Prefetch('Sgroup_group', queryset=StudentGroup.objects.select_related('student'))
        )

        # Filtrlash
        queryset = self._apply_filters(queryset, filters)

        # Saralash
        sort_by = request.query_params.get('sort_by', '-created_at')
        queryset = queryset.order_by(sort_by)

        # Pagination
        page = int(request.query_params.get('page', 1))
        page_size = int(request.query_params.get('page_size', 20))
        start = (page - 1) * page_size
        end = start + page_size

        total_count = queryset.count()
        groups = queryset[start:end]

        serializer = GroupListSerializer(groups, many=True)

        return Response({
            'count': total_count,
            'page': page,
            'page_size': page_size,
            'total_pages': (total_count + page_size - 1) // page_size,
            'results': serializer.data
        })

    def _apply_filters(self, queryset, filters):
        """Filtrlashni qo'llash"""
        # Status filter
        if 'status' in filters:
            queryset = queryset.filter(status=filters['status'])

        # Kurs filter
        if 'course_id' in filters:
            queryset = queryset.filter(course_id=filters['course_id'])

        # O'qituvchi filter
        if 'teacher_id' in filters:
            queryset = queryset.filter(
                group__teacher_id=filters['teacher_id'],
                group__end_date__isnull=True
            )

        # Xona filter
        if 'room_id' in filters:
            queryset = queryset.filter(room_id=filters['room_id'])

        # Qidiruv (guruh nomi bo'yicha)
        if 'search' in filters:
            search = filters['search']
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(course__name__icontains=search)
            )

        # Boshlanish sanasi oralig'i
        if 'start_date_from' in filters:
            queryset = queryset.filter(start_date__gte=filters['start_date_from'])
        if 'start_date_to' in filters:
            queryset = queryset.filter(start_date__lte=filters['start_date_to'])

        # Talabalar bor/yo'q
        if 'has_students' in filters:
            if filters['has_students']:
                queryset = queryset.annotate(
                    student_count=Count('Sgroup_group', filter=Q(Sgroup_group__left_at__isnull=True))
                ).filter(student_count__gt=0)
            else:
                queryset = queryset.annotate(
                    student_count=Count('Sgroup_group', filter=Q(Sgroup_group__left_at__isnull=True))
                ).filter(student_count=0)

        # Tugashigacha qolgan kunlar
        if 'days_until_end_lt' in filters:
            target_date = date.today() + timedelta(days=filters['days_until_end_lt'])
            queryset = queryset.filter(end_date__lte=target_date, end_date__gte=date.today())

        return queryset


class GroupCreateView(APIView):
    """Guruh yaratish"""

    def post(self, request):
        serializer = GroupCreateSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        group = serializer.save()

        return Response({
            'message': 'Guruh muvaffaqiyatli yaratildi',
            'group': GroupDetailSerializer(group).data
        }, status=status.HTTP_201_CREATED)


class GroupDetailView(APIView):
    """Guruh batafsil ma'lumot, tahrirlash, o'chirish"""

    def get(self, request, group_id):
        """Guruh ma'lumotlarini olish"""
        group = get_object_or_404(Group, id=group_id)
        serializer = GroupDetailSerializer(group)
        return Response(serializer.data)

    def put(self, request, group_id):
        """Guruhni tahrirlash"""
        group = get_object_or_404(Group, id=group_id)
        serializer = GroupUpdateSerializer(group, data=request.data, partial=True)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        serializer.save()

        return Response({
            'message': 'Guruh muvaffaqiyatli yangilandi',
            'group': GroupDetailSerializer(group).data
        })

    def delete(self, request, group_id):
        """Guruhni o'chirish"""
        group = get_object_or_404(Group, id=group_id)

        # Guruhda talabalar borligini tekshirish
        has_students = StudentGroup.objects.filter(
            group=group,
            left_at__isnull=True
        ).exists()

        if has_students:
            return Response({
                'error': 'Guruhda faol talabalar bor. Avval ularni chiqaring.'
            }, status=status.HTTP_400_BAD_REQUEST)

        group_name = group.name
        group.delete()

        return Response({
            'message': f'{group_name} guruhi o\'chirildi'
        })


class GroupArchiveView(APIView):
    """Guruhni arxivlash"""

    def post(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)
        serializer = GroupArchiveSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Status o'zgartirish
        group.status = 'archived'
        group.save()

        return Response({
            'message': 'Guruh arxivlandi',
            'group': {
                'id': str(group.id),
                'name': group.name,
                'status': group.status
            }
        })


class GroupUnarchiveView(APIView):
    """Guruhni arxivdan qaytarish"""

    def post(self, request, group_id):
        group = get_object_or_404(Group, id=group_id)

        if group.status != 'archived':
            return Response({
                'error': 'Guruh arxivda emas'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Status qaytarish
        group.status = 'active'
        group.save()

        return Response({
            'message': 'Guruh qayta faollashtirildi',
            'group': {
                'id': str(group.id),
                'name': group.name,
                'status': group.status
            }
        })


class GroupExportExcelView(APIView):
    """Guruhlarni Excel ga export qilish"""

    def get(self, request):
        # Filter parametrlarini olish
        filter_serializer = GroupFilterSerializer(data=request.query_params)
        filter_serializer.is_valid()
        filters = filter_serializer.validated_data

        # Guruhlarni olish
        queryset = Group.objects.all().select_related('course', 'room')

        # Filtrlash (GroupsListView dagi metoddan foydalanish)
        list_view = GroupsListView()
        queryset = list_view._apply_filters(queryset, filters)

        # Excel yaratish
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Guruhlar"

        # Header
        headers = [
            'Guruh nomi', 'Kurs', 'Status', 'Xona',
            'Boshlanish', 'Tugash', 'Talabalar soni',
            'O\'qituvchilar', 'Yaratilgan'
        ]
        ws.append(headers)

        # Ma'lumotlar
        for group in queryset:
            # Talabalar soni
            students_count = StudentGroup.objects.filter(
                group=group,
                left_at__isnull=True
            ).count()

            # O'qituvchilar
            teachers = GroupTeacher.objects.filter(
                group=group,
                end_date__isnull=True
            ).select_related('teacher')
            teacher_names = ', '.join([
                f"{t.teacher.first_name} {t.teacher.last_name}"
                for t in teachers
            ])

            ws.append([
                group.name,
                group.course.name if group.course else '',
                group.get_status_display(),
                group.room.name if group.room else '',
                group.start_date.strftime('%d.%m.%Y') if group.start_date else '',
                group.end_date.strftime('%d.%m.%Y') if group.end_date else '',
                students_count,
                teacher_names,
                group.created_at.strftime('%d.%m.%Y %H:%M')
            ])

        # Response
        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename=groups.xlsx'
        wb.save(response)

        return response


class GroupStatisticsView(APIView):
    """Guruhlar statistikasi"""

    def get(self, request):
        total_groups = Group.objects.count()
        active_groups = Group.objects.filter(status='active').count()
        expired_groups = Group.objects.filter(status='expired').count()
        archived_groups = Group.objects.filter(status='archived').count()

        # Tugashi yaqin guruhlar (7 kun ichida)
        ending_soon = Group.objects.filter(
            status='active',
            end_date__lte=date.today() + timedelta(days=7),
            end_date__gte=date.today()
        ).count()

        # Talabalar soni
        total_students = StudentGroup.objects.filter(
            left_at__isnull=True
        ).values('student').distinct().count()

        return Response({
            'total_groups': total_groups,
            'active_groups': active_groups,
            'expired_groups': expired_groups,
            'archived_groups': archived_groups,
            'ending_soon': ending_soon,
            'total_students': total_students
        })


class GroupBulkActionView(APIView):
    """Bir nechta guruhga bir vaqtda amallar bajarish"""

    def post(self, request):
        action = request.data.get('action')  # archive, unarchive, delete
        group_ids = request.data.get('group_ids', [])

        if not action or not group_ids:
            return Response({
                'error': 'action va group_ids majburiy'
            }, status=status.HTTP_400_BAD_REQUEST)

        groups = Group.objects.filter(id__in=group_ids)

        if action == 'archive':
            groups.update(status='archived')
            message = f"{groups.count()} ta guruh arxivlandi"

        elif action == 'unarchive':
            groups.update(status='active')
            message = f"{groups.count()} ta guruh qayta faollashtirildi"

        elif action == 'delete':
            # Faqat talabasiz guruhlarni o'chirish
            count = 0
            for group in groups:
                has_students = StudentGroup.objects.filter(
                    group=group,
                    left_at__isnull=True
                ).exists()
                if not has_students:
                    group.delete()
                    count += 1
            message = f"{count} ta guruh o'chirildi"

        else:
            return Response({
                'error': 'Noto\'g\'ri action'
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({'message': message})


# guruh tarixlarini export qilish

class GroupsExportView(APIView):
    """Guruhlarni Excel ga export qilish"""

    def post(self, request):
        # Filtrlash parametrlarini validatsiya qilish
        filter_serializer = GroupExportFilterSerializer(data=request.data.get('filters', {}))
        if not filter_serializer.is_valid():
            return Response(filter_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Ustunlarni validatsiya qilish
        columns_serializer = GroupExportColumnsSerializer(data=request.data.get('columns', {}))
        if not columns_serializer.is_valid():
            return Response(columns_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        filters = filter_serializer.validated_data
        all_columns = (
                columns_serializer.validated_data.get('default_columns', []) +
                columns_serializer.validated_data.get('additional_columns', [])
        )

        # Guruhlarni olish va filtrlash
        queryset = self._get_filtered_groups(filters)

        # Excel yaratish
        file_name = self._generate_filename('Groups')
        excel_file = self._create_groups_excel(queryset, all_columns)

        # Audit log yaratish
        create_export_audit_log(
            user=request.user,
            export_type='groups',
            file_name=file_name,
            total_records=queryset.count(),
            columns=all_columns,
            filters=filters
        )

        # Response
        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = f'attachment; filename={file_name}'
        excel_file.save(response)

        return response

    def _get_filtered_groups(self, filters):
        """Guruhlarni filtrlash"""
        queryset = Group.objects.all().select_related('course', 'room')

        # Aniq guruhlar
        if filters.get('group_ids'):
            queryset = queryset.filter(id__in=filters['group_ids'])

        # Status filter
        if filters.get('status'):
            queryset = queryset.filter(status=filters['status'])

        # Kurs filter
        if filters.get('course_id'):
            queryset = queryset.filter(course_id=filters['course_id'])

        # O'qituvchi filter
        if filters.get('teacher_id'):
            queryset = queryset.filter(
                group__teacher_id=filters['teacher_id'],
                group__end_date__isnull=True
            )

        # Xona filter
        if filters.get('room_id'):
            queryset = queryset.filter(room_id=filters['room_id'])

        # Sana oralig'i
        if filters.get('start_date_from'):
            queryset = queryset.filter(start_date__gte=filters['start_date_from'])
        if filters.get('start_date_to'):
            queryset = queryset.filter(start_date__lte=filters['start_date_to'])

        return queryset.order_by('name')

    def _create_groups_excel(self, groups, columns):
        """Excel yaratish"""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Guruhlar"

        # Ustunlar nomi map
        serializer = GroupExportDataSerializer(context={'columns': columns})

        # Bitta guruhni serialize qilib, header nomlarini olish
        if groups.exists():
            sample_data = serializer.to_representation(groups.first())
            headers = list(sample_data.keys())
        else:
            headers = ['Ma\'lumot yo\'q']

        # Header styling
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        # Headerni yozish
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border

        # Ma'lumotlarni yozish
        for row_num, group in enumerate(groups, 2):
            data = serializer.to_representation(group)
            for col_num, value in enumerate(data.values(), 1):
                cell = ws.cell(row=row_num, column=col_num, value=value)
                cell.border = border
                cell.alignment = Alignment(vertical="center")

        # Ustunlar kengligini avtomatik sozlash
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        return wb

    def _generate_filename(self, prefix):
        """Fayl nomi generatsiya qilish"""
        timestamp = datetime.now().strftime('%Y-%m-%d_%H%M')
        return f"{prefix}Export_{timestamp}.xlsx"


class StudentsExportView(APIView):
    """Talabalarni Excel ga export qilish"""

    def post(self, request):
        # Filtrlash parametrlarini validatsiya qilish
        filter_serializer = StudentExportFilterSerializer(data=request.data.get('filters', {}))
        if not filter_serializer.is_valid():
            return Response(filter_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Ustunlarni validatsiya qilish
        columns_serializer = StudentExportColumnsSerializer(data=request.data.get('columns', {}))
        if not columns_serializer.is_valid():
            return Response(columns_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        filters = filter_serializer.validated_data
        all_columns = (
                columns_serializer.validated_data.get('default_columns', []) +
                columns_serializer.validated_data.get('additional_columns', [])
        )

        # Talabalarni olish
        queryset = self._get_filtered_students(filters)

        # Excel yaratish
        group_name = queryset.first().group.name if queryset.exists() else 'Students'
        file_name = self._generate_filename(group_name)
        excel_file = self._create_students_excel(queryset, all_columns)

        # Audit log yaratish
        create_export_audit_log(
            user=request.user,
            export_type='students',
            file_name=file_name,
            total_records=queryset.count(),
            columns=all_columns,
            filters=filters
        )

        # Response
        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = f'attachment; filename={file_name}'
        excel_file.save(response)

        return response

    def _get_filtered_students(self, filters):
        """Talabalarni filtrlash"""
        group_id = filters['group_id']
        student_types = filters.get('student_types', ['active'])

        queryset = StudentGroup.objects.filter(
            group_id=group_id
        ).select_related('student', 'group')

        # Talaba turlarini filtrlash
        q_filter = Q()

        if 'active' in student_types:
            # Faol talabalar (ketmagan va muzlatilmagan)
            q_filter |= Q(left_at__isnull=True)

        if 'left' in student_types:
            # Ketgan talabalar
            q_filter |= Q(left_at__isnull=False)

        if 'frozen' in student_types:
            # Muzlatilgan talabalar
            frozen_students = StudentFreezes.objects.filter(
                group_id=group_id,
                freeze_end_date__gte=datetime.now().date()
            ).values_list('student_id', flat=True)
            q_filter |= Q(student_id__in=frozen_students)

        queryset = queryset.filter(q_filter).distinct()

        return queryset.order_by('student__full_name')

    def _create_students_excel(self, students, columns):
        """Excel yaratish"""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Talabalar"

        # Serializer
        serializer = StudentExportDataSerializer(context={'columns': columns})

        # Headers
        if students.exists():
            sample_data = serializer.to_representation(students.first())
            headers = list(sample_data.keys())
        else:
            headers = ['Ma\'lumot yo\'q']

        # Header styling (GroupsExport kabi)
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        # Header
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border

        # Data
        for row_num, student_group in enumerate(students, 2):
            data = serializer.to_representation(student_group)
            for col_num, value in enumerate(data.values(), 1):
                cell = ws.cell(row=row_num, column=col_num, value=value)
                cell.border = border
                cell.alignment = Alignment(vertical="center")

        # Auto-adjust column width
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width

        return wb

    def _generate_filename(self, group_name):
        """Fayl nomi generatsiya qilish"""
        timestamp = datetime.now().strftime('%Y-%m-%d_%H%M')
        # Guruh nomidagi bo'sh joylarni _ ga almashtirish
        safe_name = group_name.replace(' ', '_').replace('/', '-')
        return f"GuruhStudent_{safe_name}_{timestamp}.xlsx"


class ExportHistoryView(APIView):
    """Export tarixi - Audit log dan"""

    def get(self, request):
        # Faqat export actionlarni olish
        logs = AuditLog.objects.filter(
            action=AuditAction.CREATE,
            new_action__isnull=False
        ).select_related('performed_by').order_by('-created_at')

        # Export type filter
        export_type = request.query_params.get('export_type')  # 'groups' yoki 'students'
        if export_type:
            logs = logs.filter(new_action__export_type=export_type)

        # Pagination
        page = int(request.query_params.get('page', 1))
        page_size = int(request.query_params.get('page_size', 20))
        start = (page - 1) * page_size
        end = start + page_size

        total = logs.count()
        logs = logs[start:end]

        serializer = ExportHistorySerializer(logs, many=True)

        return Response({
            'count': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size,
            'results': serializer.data
        })


class ExportStatisticsView(APIView):
    """Export statistikasi"""

    def get(self, request):
        # Jami exportlar
        total_exports = AuditLog.objects.filter(
            action=AuditAction.CREATE,
            new_action__isnull=False
        ).count()

        # Guruhlar export
        groups_exports = AuditLog.objects.filter(
            action=AuditAction.CREATE,
            new_action__export_type='groups'
        ).count()

        # Talabalar export
        students_exports = AuditLog.objects.filter(
            action=AuditAction.CREATE,
            new_action__export_type='students'
        ).count()

        # Oxirgi export
        last_export = AuditLog.objects.filter(
            action=AuditAction.CREATE,
            new_action__isnull=False
        ).order_by('-created_at').first()

        last_export_data = None
        if last_export:
            last_export_data = {
                'type': last_export.new_action.get('export_type'),
                'file_name': last_export.new_action.get('file_name'),
                'date': last_export.created_at,
                'performed_by': f"{last_export.performed_by.first_name} {last_export.performed_by.last_name}"
                if last_export.performed_by else None
            }

        return Response({
            'total_exports': total_exports,
            'groups_exports': groups_exports,
            'students_exports': students_exports,
            'last_export': last_export_data
        })


class ExamsListView(APIView):
    """Imtihonlar ro'yxati"""

    def get(self, request):
        group_id = request.query_params.get('group_id')

        exams = Exams.objects.all().select_related(
            'group', 'created_by'
        ).order_by('-exam_date')

        # Guruh bo'yicha filter
        if group_id:
            exams = exams.filter(group_id=group_id)

        # Pagination
        page = int(request.query_params.get('page', 1))
        page_size = int(request.query_params.get('page_size', 20))
        start = (page - 1) * page_size
        end = start + page_size

        total = exams.count()
        exams = exams[start:end]

        serializer = ExamListSerializer(exams, many=True)

        return Response({
            'count': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size,
            'results': serializer.data
        })


class ExamCreateView(APIView):
    """Yangi imtihon yaratish"""

    def post(self, request):
        serializer = ExamCreateSerializer(
            data=request.data,
            context={'request': request}
        )

        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        exam = serializer.save()

        return Response({
            'message': 'Imtihon muvaffaqiyatli yaratildi',
            'exam': ExamDetailSerializer(exam).data
        }, status=status.HTTP_201_CREATED)


class ExamDetailView(APIView):
    """Imtihon batafsil ma'lumot, tahrirlash, o'chirish"""

    def get(self, request, exam_id):
        """Imtihon ma'lumotlari va talabalar natijalari"""
        exam = get_object_or_404(Exams, id=exam_id)
        serializer = ExamDetailSerializer(exam)
        return Response(serializer.data)

    def put(self, request, exam_id):
        """Imtihonni tahrirlash"""
        exam = get_object_or_404(Exams, id=exam_id)
        serializer = ExamUpdateSerializer(
            exam,
            data=request.data,
            partial=True
        )

        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer.save()

        return Response({
            'message': 'Imtihon muvaffaqiyatli yangilandi',
            'exam': ExamDetailSerializer(exam).data
        })

    def delete(self, request, exam_id):
        """Imtihonni o'chirish"""
        exam = get_object_or_404(Exams, id=exam_id)

        # Natijalar bormi tekshirish
        has_results = ExamResults.objects.filter(exam=exam).exists()

        if has_results:
            return Response({
                'error': 'Imtihonda natijalar mavjud. Avval natijalarni o\'chiring.'
            }, status=status.HTTP_400_BAD_REQUEST)

        exam_title = exam.title
        exam.delete()

        return Response({
            'message': f'"{exam_title}" imtihoni o\'chirildi'
        })


class ExamGradingView(APIView):
    """Imtihon natijalarini kiritish/yangilash"""

    def post(self, request):
        """Bir yoki bir nechta talabaga ball kiritish"""
        # Single grading
        if 'student_id' in request.data:
            return self._grade_single_student(request)

        # Bulk grading
        elif 'grades' in request.data:
            return self._grade_multiple_students(request)

        else:
            return Response({
                'error': 'student_id yoki grades parametri kerak'
            }, status=status.HTTP_400_BAD_REQUEST)

    def _grade_single_student(self, request):
        """Bitta talabani baholash"""
        serializer = ExamResultSerializer(
            data=request.data,
            context={'request': request}
        )

        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        result = serializer.save()

        return Response({
            'message': 'Ball muvaffaqiyatli kiritildi',
            'result': {
                'id': str(result.id),
                'score': result.score,
                'status': 'passed' if result.score >= result.exam.min_score else 'failed'
            }
        })

    def _grade_multiple_students(self, request):
        """Ko'p talabani bir vaqtda baholash"""
        grades = request.data.get('grades', [])
        exam_id = request.data.get('exam_id')

        if not exam_id:
            return Response({
                'error': 'exam_id parametri kerak'
            }, status=status.HTTP_400_BAD_REQUEST)

        results = []
        errors = []

        for grade in grades:
            grade['exam_id'] = exam_id
            serializer = ExamResultSerializer(
                data=grade,
                context={'request': request}
            )

            if serializer.is_valid():
                result = serializer.save()
                results.append({
                    'student_id': grade['student_id'],
                    'score': result.score,
                    'status': 'success'
                })
            else:
                errors.append({
                    'student_id': grade.get('student_id'),
                    'errors': serializer.errors
                })

        return Response({
            'message': f'{len(results)} ta natija kiritildi',
            'results': results,
            'errors': errors if errors else None
        })


class ExamResultsView(APIView):
    """Imtihon natijalari ro'yxati"""

    def get(self, request, exam_id):
        """Imtihon barcha natijalari"""
        exam = get_object_or_404(Exams, id=exam_id)

        # Barcha haqli talabalarni olish
        eligible_students = StudentGroup.objects.filter(
            group=exam.group,
            left_at__isnull=True
        ).select_related('student')

        results = []
        for student_group in eligible_students:
            student = student_group.student

            # Natija bormi tekshirish
            exam_result = ExamResults.objects.filter(
                exam=exam,
                student=student
            ).first()

            if exam_result:
                results.append({
                    'student_id': str(student.id),
                    'full_name': student.full_name,
                    'phone_number': student.phone_number,
                    'score': exam_result.score,
                    'comment': exam_result.comment,
                    'status': 'passed' if exam_result.score >= exam.min_score else 'failed',
                    'status_color': 'green' if exam_result.score >= exam.min_score else 'red',
                    'graded': True,
                    'graded_at': exam_result.created_at
                })
            else:
                results.append({
                    'student_id': str(student.id),
                    'full_name': student.full_name,
                    'phone_number': student.phone_number,
                    'score': None,
                    'comment': '',
                    'status': 'not_graded',
                    'status_color': 'gray',
                    'graded': False,
                    'graded_at': None
                })

        return Response({
            'exam': {
                'id': str(exam.id),
                'title': exam.title,
                'exam_date': exam.exam_date,
                'min_score': exam.min_score,
                'max_score': exam.max_score
            },
            'results': results
        })


class ExamStatisticsView(APIView):
    """Imtihon statistikasi"""

    def get(self, request, exam_id):
        """Imtihon uchun batafsil statistika"""
        exam = get_object_or_404(Exams, id=exam_id)

        # Barcha natijalar
        results = ExamResults.objects.filter(exam=exam)

        # Asosiy statistika
        total_students = StudentGroup.objects.filter(
            group=exam.group,
            left_at__isnull=True
        ).count()

        graded = results.count()
        not_graded = total_students - graded

        passed = results.filter(score__gte=exam.min_score).count()
        failed = results.filter(score__lt=exam.min_score).count()

        # O'rtacha ball
        avg_score = results.aggregate(avg=Avg('score'))['avg'] or 0

        # Eng yuqori va past ballar
        if results.exists():
            max_result = results.order_by('-score').first()
            min_result = results.order_by('score').first()

            highest_score = {
                'score': max_result.score,
                'student': max_result.student.full_name
            }
            lowest_score = {
                'score': min_result.score,
                'student': min_result.student.full_name
            }
        else:
            highest_score = None
            lowest_score = None

        # Ball bo'yicha taqsimot
        score_distribution = []
        step = exam.max_score / 5  # 5 ta oraliq
        for i in range(5):
            min_range = i * step
            max_range = (i + 1) * step
            count = results.filter(
                score__gte=min_range,
                score__lt=max_range
            ).count()
            score_distribution.append({
                'range': f'{int(min_range)}-{int(max_range)}',
                'count': count
            })

        return Response({
            'total_students': total_students,
            'graded': graded,
            'not_graded': not_graded,
            'passed': passed,
            'failed': failed,
            'pass_rate': round((passed / graded * 100), 1) if graded > 0 else 0,
            'average_score': round(float(avg_score), 2),
            'highest_score': highest_score,
            'lowest_score': lowest_score,
            'score_distribution': score_distribution
        })


class ExamParticipantsSettingsView(APIView):
    """Imtihon qatnashuvchilar sozlamalari (CEO uchun)"""

    def get(self, request):
        """Joriy sozlamalarni olish"""
        # Bu sozlamalar database/cache da saqlanadi
        # Hozircha default qiymatlar
        return Response({
            'include_active': True,
            'include_trial': False,
            'include_frozen': False,
            'include_left': False
        })

    def post(self, request):
        """Sozlamalarni yangilash"""
        # Faqat CEO (rahbar) uchun
        if not hasattr(request.user, 'role') or request.user.role != 'ceo':
            return Response({
                'error': 'Faqat CEO sozlamalarga kirish huquqiga ega'
            }, status=status.HTTP_403_FORBIDDEN)

        serializer = ExamParticipantsSettingsSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST
            )

        # Sozlamalarni saqlash (database/cache)
        # Hozircha faqat response qaytaramiz

        return Response({
            'message': 'Sozlamalar yangilandi',
            'settings': serializer.validated_data
        })