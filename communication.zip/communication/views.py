from .models import SmsTemplates, SmsSchedules, SMSMessages
from .serializers import (
    SmsTemplatesSerializer,
    SmsSchedulesSerializer,
    SMSMessagesSerializer,
)
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.utils import extend_schema
from .models import SmsProvider
from .serializers import SmsProviderSerializer, SmsProviderListSerializer
from rest_framework import filters

@extend_schema(tags=["SmsTemplates - sms templatelar yaratish"])
class SmsTemplatesViewSet(ModelViewSet):
    queryset = SmsTemplates.objects.all()
    serializer_class = SmsTemplatesSerializer


@extend_schema(tags=["SmsSchedules - Sms larni rejalash"])
class SmsSchedulesViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = SmsSchedules.objects.select_related('template', 'created_by').all()
    serializer_class = SmsSchedulesSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['is_active', 'target_type']
    search_fields = ['name']
    ordering_fields = ['created_at', 'send_at', 'name']
    ordering = ['-created_at']




@extend_schema(tags=["SmsProvider - SMS provayderlarni sozlash"])
class SmsProviderViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
    queryset = SmsProvider.objects.select_related('created_by').all()
    serializer_class = SmsProviderSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['is_active', 'provider']
    search_fields = ['email', 'nickname']
    ordering_fields = ['created_at', 'balance']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'list':
            return SmsProviderListSerializer
        return SmsProviderSerializer

@extend_schema(tags=["SMSMessages - Sms xabarlarni ko'rish"])
class SMSMessagesViewSet(ModelViewSet):
    queryset = SMSMessages.objects.all()
    serializer_class = SMSMessagesSerializer

