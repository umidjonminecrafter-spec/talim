from .models import Organizations, OrganizationSettings, Subscriptions, Branch, ExamSettings
from .serializers import (
    OrganizationSerializer,
    OrganizationCreateSerializer,
    OrganizationSettingsSerializer,
    SubscriptionSerializer,
    BranchSerializer, ExamSettingsSerializer, BillingSubscriptionSerializer, BillingCreateSerializer
)
from rest_framework import generics
from .models import Tag
from .serializers import TagSerializer
from datetime import datetime
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import Organizations, LandingPage, LandingPageSubmission
from .serializers import (
    LandingPageSerializer,
    LandingPageCreateSerializer,
    LandingPageSubmissionSerializer,
    LandingPageSubmissionCreateSerializer
)
from django.db.models import Sum, Count


# ==================== ORGANIZATIONS ====================

@api_view(['GET', 'POST'])
def organization_list_create(request):
    """Organizations ro'yxati va yaratish"""
    if request.method == 'GET':
        status_filter = request.query_params.get('status')
        orgs = Organizations.objects.all()
        if status_filter:
            orgs = orgs.filter(status=status_filter)
        serializer = OrganizationSerializer(orgs, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = OrganizationCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def organization_detail(request, pk):
    """Organization detail, update, delete"""
    org = get_object_or_404(Organizations, pk=pk)

    if request.method == 'GET':
        serializer = OrganizationSerializer(org)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = OrganizationSerializer(org, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        org.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# ==================== ORGANIZATION SETTINGS ====================

@api_view(['GET', 'PUT'])
def organization_settings(request, org_pk):
    """Tashkilot sozlamalarini olish va yangilash"""
    org = get_object_or_404(Organizations, pk=org_pk)
    settings, created = OrganizationSettings.objects.get_or_create(organization=org)

    if request.method == 'GET':
        serializer = OrganizationSettingsSerializer(settings)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = OrganizationSettingsSerializer(settings, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# ==================== SUBSCRIPTIONS ====================

@api_view(['GET', 'POST'])
def subscription_list_create(request, org_pk):
    """Tashkilot obunalari ro'yxati va yaratish"""
    org = get_object_or_404(Organizations, pk=org_pk)

    if request.method == 'GET':
        subs = Subscriptions.objects.filter(organization_id=org)
        serializer = SubscriptionSerializer(subs, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = SubscriptionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(organization_id=org)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def subscription_detail(request, org_pk, pk):
    """Obuna detail, update, delete"""
    sub = get_object_or_404(Subscriptions, pk=pk, organization_id__pk=org_pk)

    if request.method == 'GET':
        serializer = SubscriptionSerializer(sub)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = SubscriptionSerializer(sub, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        sub.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# ==================== BRANCHES ====================

@api_view(['GET', 'POST'])
def branch_list_create(request, org_pk):
    """Tashkilot filiallari ro'yxati va yaratish"""
    org = get_object_or_404(Organizations, pk=org_pk)

    if request.method == 'GET':
        is_active = request.query_params.get('is_active')
        branches = Branch.objects.filter(organization_id=org)
        if is_active is not None:
            branches = branches.filter(is_active=is_active.lower() == 'true')
        serializer = BranchSerializer(branches, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = BranchSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(organization_id=org)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def branch_detail(request, org_pk, pk):
    """Filial detail, update, delete"""
    branch = get_object_or_404(Branch, pk=pk, organization_id__pk=org_pk)

    if request.method == 'GET':
        serializer = BranchSerializer(branch)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = BranchSerializer(branch, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        branch.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(['GET', 'PUT'])
def exam_settings(request, org_pk):
    """Imtihon sozlamalarini olish va yangilash"""
    org = get_object_or_404(Organizations, pk=org_pk)
    settings, created = ExamSettings.objects.get_or_create(organization=org)

    if request.method == 'GET':
        serializer = ExamSettingsSerializer(settings)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ExamSettingsSerializer(settings, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




# ==================== LANDING PAGES ====================

@api_view(['GET', 'POST'])
def landing_page_list_create(request, org_pk):
    """Landing Page ro'yxati va yaratish"""
    org = get_object_or_404(Organizations, pk=org_pk)

    if request.method == 'GET':
        is_active = request.query_params.get('is_active')
        source = request.query_params.get('source')

        pages = LandingPage.objects.filter(organization=org)
        if is_active is not None:
            pages = pages.filter(is_active=is_active.lower() == 'true')
        if source:
            pages = pages.filter(source=source)

        serializer = LandingPageSerializer(pages, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = LandingPageCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(organization=org)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def landing_page_detail(request, org_pk, pk):
    """Landing Page detail, update, delete"""
    page = get_object_or_404(LandingPage, pk=pk, organization__pk=org_pk)

    if request.method == 'GET':
        serializer = LandingPageSerializer(page)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = LandingPageSerializer(page, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        page.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


@api_view(['GET'])
def landing_page_by_slug(request, slug):
    """Slug orqali Landing Page ma'lumotlarini olish (Public endpoint)"""
    page = get_object_or_404(LandingPage, slug=slug, is_active=True)
    serializer = LandingPageSerializer(page)
    return Response(serializer.data)


# ==================== LANDING PAGE SUBMISSIONS ====================

@api_view(['GET', 'POST'])
def submission_list_create(request, org_pk, page_pk):
    """Landing Page ariza ro'yxati va yaratish"""
    page = get_object_or_404(LandingPage, pk=page_pk, organization__pk=org_pk)

    if request.method == 'GET':
        submissions = LandingPageSubmission.objects.filter(landing_page=page)
        serializer = LandingPageSubmissionSerializer(submissions, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = LandingPageSubmissionCreateSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(landing_page=page)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def public_submission_create(request, slug):
    """Public endpoint - talabalar ro'yxatdan o'tishi"""
    page = get_object_or_404(LandingPage, slug=slug, is_active=True)

    serializer = LandingPageSubmissionCreateSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save(landing_page=page)
        return Response({
            "message": "Arizangiz qabul qilindi! Tez orada siz bilan bog'lanamiz.",
            "data": serializer.data
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'DELETE'])
def submission_detail(request, org_pk, page_pk, pk):
    """Ariza detail va o'chirish"""
    submission = get_object_or_404(
        LandingPageSubmission,
        pk=pk,
        landing_page__pk=page_pk,
        landing_page__organization__pk=org_pk
    )

    if request.method == 'GET':
        serializer = LandingPageSubmissionSerializer(submission)
        return Response(serializer.data)

    elif request.method == 'DELETE':
        submission.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


# ==================== STATISTIKA ====================

@api_view(['GET'])
def landing_statistics(request, org_pk):
    """Landing Page statistikasi (source bo'yicha)"""
    org = get_object_or_404(Organizations, pk=org_pk)
    pages = LandingPage.objects.filter(organization=org)

    stats = []
    for page in pages:
        stats.append({
            "id": page.id,
            "name": page.name,
            "slug": page.slug,
            "source": page.source,
            "submissions_count": page.submissions.count(),
            "is_active": page.is_active
        })

    return Response(stats)


@api_view(['GET'])
def billing_dashboard(request, org_pk):
    """Billing dashboard - asosiy ma'lumotlar va statistika"""
    org = get_object_or_404(Organizations, pk=org_pk)

    # Joriy faol obuna
    current_sub = Subscriptions.objects.filter(
        organization_id=org,
        status='active'
    ).order_by('-end_date').first()

    # Statistika
    all_subs = Subscriptions.objects.filter(organization_id=org)
    total_subs = all_subs.count()
    total_spent = all_subs.aggregate(total=Sum('price'))['total'] or 0

    # Qolgan kunlar
    days_remaining = 0
    if current_sub and current_sub.end_date:
        delta = current_sub.end_date.date() - datetime.now().date()
        days_remaining = delta.days if delta.days > 0 else 0

    # Status aniqlash
    org_status = org.status
    if days_remaining == 0:
        org_status = "expired"
    elif 0 < days_remaining <= 7:
        org_status = "expires"

    data = {
        "current_subscription": BillingSubscriptionSerializer(current_sub).data if current_sub else None,
        "total_subscriptions": total_subs,
        "total_spent": total_spent,
        "next_payment_date": current_sub.end_date if current_sub else None,
        "days_remaining": days_remaining,
        "status": org_status
    }

    return Response(data)


@api_view(['GET'])
def billing_history(request, org_pk):
    """To'lov tarixi - barcha obunalar"""
    org = get_object_or_404(Organizations, pk=org_pk)

    subscriptions = Subscriptions.objects.filter(organization_id=org).order_by('-created_at')
    serializer = BillingSubscriptionSerializer(subscriptions, many=True)

    return Response(serializer.data)


@api_view(['POST'])
def billing_pay(request, org_pk):
    """To'lov qilish - yangi obuna yaratish"""
    org = get_object_or_404(Organizations, pk=org_pk)

    serializer = BillingCreateSerializer(data=request.data)
    if serializer.is_valid():
        subscription = serializer.save(organization_id=org)

        # Organization statusini yangilash
        org.status = 'active'
        org.save()

        return Response({
            "message": "To'lov muvaffaqiyatli amalga oshirildi!",
            "subscription": BillingSubscriptionSerializer(subscription).data
        }, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def billing_plans(request):
    """Mavjud tariflar ro'yxati"""
    plans = [
        {
            "plan_type": "basic",
            "name": "Asosiy",
            "price_1month": 500000,
            "price_3months": 1350000,
            "price_6months": 2400000,
            "price_12months": 4500000,
            "features": [
                "50 tagacha guruh",
                "200 tagacha talaba",
                "5 ta filial",
                "Asosiy hisobotlar"
            ]
        },
        {
            "plan_type": "premium",
            "name": "Premium",
            "price_1month": 1000000,
            "price_3months": 2700000,
            "price_6months": 4800000,
            "price_12months": 9000000,
            "features": [
                "Cheksiz guruh",
                "Cheksiz talaba",
                "Cheksiz filial",
                "Barcha hisobotlar",
                "SMS xizmati",
                "Prioritet qo'llab-quvvatlash"
            ]
        },
        {
            "plan_type": "enterprise",
            "name": "Korporativ",
            "price_1month": 2000000,
            "price_3months": 5400000,
            "price_6months": 9600000,
            "price_12months": 18000000,
            "features": [
                "Premium barcha imkoniyatlari",
                "Maxsus integratsiyalar",
                "Shaxsiy menejer",
                "API kirish",
                "White-label imkoniyati"
            ]
        }
    ]

    return Response(plans)


@api_view(['GET'])
def billing_current(request, org_pk):
    """Joriy faol obuna"""
    org = get_object_or_404(Organizations, pk=org_pk)

    current_sub = Subscriptions.objects.filter(
        organization_id=org,
        status='active'
    ).order_by('-end_date').first()

    if not current_sub:
        return Response({
            "message": "Faol obuna topilmadi"
        }, status=status.HTTP_404_NOT_FOUND)

    serializer = BillingSubscriptionSerializer(current_sub)
    return Response(serializer.data)

class TagListCreateView(generics.ListCreateAPIView):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer

    def get_queryset(self):
        object_type = self.request.query_params.get("object_type")
        if object_type:
            return self.queryset.filter(object_type=object_type)
        return self.queryset


class TagRetrieveUpdateDeleteView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Tag.objects.all()
    serializer_class = TagSerializer


